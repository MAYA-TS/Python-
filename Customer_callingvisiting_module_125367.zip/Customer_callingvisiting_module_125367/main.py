from msilib.schema import Font
import xlsxwriter
import os
import cx_Oracle
import openpyxl
from openpyxl import Workbook
from email.message import EmailMessage
from email.utils import make_msgid
import mimetypes
from tableau_api_lib import TableauServerConnection
from tableau_api_lib.utils import querying
from tableau_api_lib.utils.common import flatten_dict_column
import pandas as pd
import xlrd
from pandas import ExcelWriter
from openpyxl import load_workbook
from openpyxl.styles import PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side
import smtplib
import datetime
import schedule
import time
import tableauserverclient as TSC

# def task():

# while True:
# tableau_server_config = {
#                 'my_env': {
#                         'server': 'https://reports.manappuram.com',
#                         'api_version': "3.17",
#                         'username': 'tableauadministrator',
#                         'password': 'M@fil@123',
#                         'site_name': 'Default',
#                         'site_url': ''
#                 }
#         }
# conn = TableauServerConnection(tableau_server_config, env='my_env',ssl_verify=False)
# conn.sign_in()
# print("Tableau server connected")
# view_img = conn.query_view_image(view_id=fzm_data)
# print(view_img)
# with open(r"D:\\CRF\\crf10\\119339-CRF_FOR_SHOP_VISIT_REPORT_AUTOMATION\\Shopvisit_report1.png","wb") as f:
   
#     f.write(view_img.content)
print("Third section completed................")
conn = cx_Oracle.connect("kpmg", "Asd$1234", "HISTDB")
print("Oracle database connected")

df1=pd.read_sql( """select branch_name,sum(billing_count) billing_count,sum(called_count)called_count,
sum(calling_pending)calling_pending,sum(emi_paid_count)emi_paid_count,sum(emi_pending_count)emi_pending_count
from tab_newngl_yd_call group by branch_name""",con=conn)
print("df1 completed---------------------------------------------------")


df2=pd.read_sql("""select branch_name,sum(billing_count) billing_count,sum(called_count)called_count,
sum(calling_pending)calling_pending,sum(emi_paid_count)emi_paid_count,sum(emi_pending_count)emi_pending_count
from tab_newngl_mtd_call group by branch_name """,con=conn)
        
print("df2 completed---------------------------------------------------")

df3=pd.read_sql("""select branch_name,sum(billing_count) billing_count,sum(called_count)called_count,
sum(calling_pending)calling_pending,sum(emi_paid_count)emi_paid_count,sum(emi_pending_count)emi_pending_count
from tab_newngl_Mtly_call group by branch_name""",con=conn)
   
print("df3 completed---------------------------------------------------") 
df4=pd.read_sql("""select branch_name,count(distinct(emp_name))Assigned_Emp_Count,sum(billing_count) billing_count,sum(visited_customer_count)Visited_Customer_count,
sum(Visiting_Pending_Count)Visiting_Pending_Count,sum(Paid_Customer_Count)Paid_Customer_Count,sum(Payment_pending_count)Payment_pending_count
from tab_newngl_yd_Vst where emp_name is not null group by branch_name""",con=conn)    
print("df4 completed---------------------------------------------------")

df5=pd.read_sql("""select branch_name,count(distinct(emp_name))Assigned_Emp_Count,sum(billing_count) billing_count,sum(visited_customer_count)Visited_Customer_count,
sum(Visiting_Pending_Count)Visiting_Pending_Count,sum(Paid_Customer_Count)Paid_Customer_Count,sum(Payment_pending_count)Payment_pending_count
from tab_newngl_mtd_vst where emp_name is not null group by branch_name
""",con=conn)
print("df5 completed---------------------------------------------------")

df6=pd.read_sql("""select branch_name,count(distinct(emp_name))Assigned_Emp_Count,sum(billing_count) billing_count,sum(visited_customer_count)Visited_Customer_count,
sum(Visiting_Pending_Count)Visiting_Pending_Count,sum(Paid_Customer_Count)Paid_Customer_Count,sum(Payment_pending_count)Payment_pending_count
from tab_newngl_Mtly_vst where emp_name is not null group by branch_name

""",con=conn)
print("df6 completed---------------------------------------------------")

df7=pd.read_sql("""select emp_name,sum(billing_count)  Assigned_count,sum(called_count)called_count,
sum(calling_pending)calling_pending,sum(emi_paid_count)emi_paid_count,sum(emi_pending_count)emi_pending_count
from tab_newngl_yd_call group by emp_name
 """,con=conn)
print("df7 completed---------------------------------------------------")
df8=pd.read_sql("""select emp_name,sum(billing_count)  Assigned_count,sum(called_count)called_count,
sum(calling_pending)calling_pending,sum(emi_paid_count)emi_paid_count,sum(emi_pending_count)emi_pending_count
from tab_newngl_mtd_call group by emp_name
""",con=conn)
print("df8 completed---------------------------------------------------")
df9=pd.read_sql("""select emp_name,sum(billing_count) Assigned_count,sum(called_count)called_count,
sum(calling_pending)calling_pending,sum(emi_paid_count)emi_paid_count,sum(emi_pending_count)emi_pending_count
from tab_newngl_Mtly_call group by emp_name
""",con=conn)
print("df9 completed---------------------------------------------------")
df10=pd.read_sql("""select emp_name,sum(billing_count) Assigned_count,sum(visited_customer_count)Visited_Customer_count,
sum(Visiting_Pending_Count)Visiting_Pending_Count,sum(Paid_Customer_Count)Paid_Customer_Count,sum(Payment_pending_count)Payment_pending_count
from tab_newngl_yd_Vst where emp_name is not null group by emp_name
""",con=conn)
print("df10 completed---------------------------------------------------")
df11=pd.read_sql("""select emp_name,sum(billing_count) Assigned_count,sum(visited_customer_count)Visited_Customer_count,
sum(Visiting_Pending_Count)Visiting_Pending_Count,sum(Paid_Customer_Count)Paid_Customer_Count,sum(Payment_pending_count)Payment_pending_count
from tab_newngl_mtd_vst where emp_name is not null group by emp_name
 
""",con=conn)
print("df11 completed---------------------------------------------------")
df12=pd.read_sql(""" select emp_name,sum(billing_count) Assigned_count,sum(visited_customer_count)Visited_Customer_count,
sum(Visiting_Pending_Count)Visiting_Pending_Count,sum(Paid_Customer_Count)Paid_Customer_Count,sum(Payment_pending_count)Payment_pending_count
from tab_newngl_Mtly_vst where emp_name is not null group by emp_name
""",con=conn)
print("df12 completed---------------------------------------------------")
df13=pd.read_sql("""select * from tab_newngl_call_rpt
""",con=conn)
print("df13 completed---------------------------------------------------")
print("Query section completed...........")


writer=pd.ExcelWriter("D:\\CRF\\Customer_callingvisiting_module_125367\\Customer_callingvisit_report.xlsx",engine="openpyxl")
df1.to_excel(writer, sheet_name="Yesterday", index=False)
df2.to_excel(writer, sheet_name="MTD", index=False)
df3.to_excel(writer,sheet_name="Monthly",index=False)
df4.to_excel(writer,sheet_name="BV_Yesterday",index=False)
df5.to_excel(writer,sheet_name="BV_MTD",index=False)
df6.to_excel(writer,sheet_name="BV_Monthly",index=False)
df7.to_excel(writer,sheet_name="SO_C_Yesterday",index=False)
df8.to_excel(writer,sheet_name="SO_C_MTD",index=False)
df9.to_excel(writer,sheet_name="SO_C_Monthly",index=False)
df10.to_excel(writer,sheet_name="SO_V_Yesterday",index=False)
df11.to_excel(writer,sheet_name="SO_V_MTD",index=False)
df12.to_excel(writer,sheet_name="SO_V_Monthly",index=False)
df13.to_excel(writer,sheet_name="Report",index=False)





print("saved as excel")
writer.save()
print("Excel downloading section completed............")

#---------------------------------BRANCH CALLING-------------------------------
# --------------------------------Yesterday------------------------------------

workbook = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\blank.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING']
for sheet_name in sheet_names:
    if sheet_name == 'BRANCH CALLING':
        sheet = workbook[sheet_name]
        merge_range6 = f"A1:F1"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=1, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=1, column=1)
        merged_cell6.value = "Yesterday"
        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 6):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        
workbook.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")


source_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['Yesterday']
dest_sheet = dest_wb['BRANCH CALLING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# -------------------------------MTD--------------

workbook = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING']
for sheet_name in sheet_names:
    if sheet_name == 'BRANCH CALLING':
        sheet = workbook[sheet_name]
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
        merge_range6 = f"A{total_row_number+2}:F{total_row_number+2}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cell6.value = "MTD"
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 6):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
workbook.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
source_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['MTD']
dest_sheet = dest_wb['BRANCH CALLING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# -------------------------------Monthly--------------

workbook = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING']
for sheet_name in sheet_names:
    if sheet_name == 'BRANCH CALLING':
        sheet = workbook[sheet_name]
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
        merge_range6 = f"A{total_row_number+2}:F{total_row_number+2}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cell6.value = "Monthly"
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 6):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
workbook.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
source_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['Monthly']
dest_sheet = dest_wb['BRANCH CALLING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

#-------------------------------BRANCH CALLING--completed----------------------------------



#--------------------------------BRANCH VISITING----------------------------
# ---------------------------BV_Yesterday--------------------------------

workbook = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING']
for sheet_name in sheet_names:
    if sheet_name == 'BRANCH VISITING':
        sheet = workbook[sheet_name]
        merge_range6 = f"A1:G1"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=1, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=1, column=1)
        merged_cell6.value = "BV_Yesterday"
        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 8):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        
workbook.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")


source_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['BV_Yesterday']
dest_sheet = dest_wb['BRANCH VISITING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# -------------------------------BV_MTD--------------

workbook = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING']
for sheet_name in sheet_names:
    if sheet_name == 'BRANCH VISITING':
        sheet = workbook[sheet_name]
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
        merge_range6 = f"A{total_row_number+2}:G{total_row_number+2}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cell6.value = "BV_MTD"
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 8):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
workbook.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
source_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['BV_MTD']
dest_sheet = dest_wb['BRANCH VISITING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# -------------------------------BV_Monthly--------------

workbook = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING']
for sheet_name in sheet_names:
    if sheet_name == 'BRANCH VISITING':
        sheet = workbook[sheet_name]
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
        merge_range6 = f"A{total_row_number+2}:G{total_row_number+2}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cell6.value = "BV_Monthly"
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 8):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
workbook.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
source_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['BV_Monthly']
dest_sheet = dest_wb['BRANCH VISITING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")





#---------------------------------SO CALLING-----------------------------
# ---------------------------SO_C_Yesterday--------------

workbook = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING']
for sheet_name in sheet_names:
    if sheet_name == 'SO CALLING':
        sheet = workbook[sheet_name]
        merge_range6 = f"A1:F1"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=1, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=1, column=1)
        merged_cell6.value = "SO_C_Yesterday"
        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 6):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        
workbook.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")


source_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['SO_C_Yesterday']
dest_sheet = dest_wb['SO CALLING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# -------------------------------SO_MTD--------------

workbook = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING']
for sheet_name in sheet_names:
    if sheet_name == 'SO CALLING':
        sheet = workbook[sheet_name]
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
        merge_range6 = f"A{total_row_number+2}:F{total_row_number+2}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cell6.value = "SO_C_MTD"
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 6):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
workbook.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
source_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['SO_C_MTD']
dest_sheet = dest_wb['SO CALLING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# -------------------------------SO_Monthly------------

workbook = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING']
for sheet_name in sheet_names:
    if sheet_name == 'SO CALLING':
        sheet = workbook[sheet_name]
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
        merge_range6 = f"A{total_row_number+2}:F{total_row_number+2}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cell6.value = "SO_C_Monthly"
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 6):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
workbook.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
source_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['SO_C_Monthly']
dest_sheet = dest_wb['SO CALLING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")



#--------------------------------SO VISITING----------------------------
# --------------------------SO_V_Yesterday-------------

workbook = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING']
for sheet_name in sheet_names:
    if sheet_name == 'SO VISITING':
        sheet = workbook[sheet_name]
        merge_range6 = f"A1:F1"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=1, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=1, column=1)
        merged_cell6.value = "SO_V_Yesterday"
        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 7):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        
workbook.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")


source_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['SO_V_Yesterday']
dest_sheet = dest_wb['SO VISITING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# -------------------------------SO_V_MTD-------------

workbook = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING']
for sheet_name in sheet_names:
    if sheet_name == 'SO VISITING':
        sheet = workbook[sheet_name]
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
        merge_range6 = f"A{total_row_number+2}:F{total_row_number+2}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cell6.value = "SO_V_MTD"
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 7):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
workbook.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
source_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['SO_V_MTD']
dest_sheet = dest_wb['SO VISITING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# -------------------------------SO_V_Monthly--------------

workbook = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING']
for sheet_name in sheet_names:
    if sheet_name == 'SO VISITING':
        sheet = workbook[sheet_name]
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
        merge_range6 = f"A{total_row_number+2}:F{total_row_number+2}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cell6.value = "SO_V_Monthly"
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 7):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
workbook.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
source_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['SO_V_Monthly']
dest_sheet = dest_wb['SO VISITING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")


#--------------------------------Report---------------------------------------

source_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['Report']
dest_sheet = dest_wb['REPORT']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

workbook = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING','REPORT']
for sheet_name in sheet_names:
    if sheet_name =='REPORT':
        sheet = workbook[sheet_name]

        for row in sheet.iter_rows(min_row=1, max_row=1):
                    for cell in row:
                        cell.alignment = Alignment(horizontal='center', vertical='center')
                        for col in range(1, 20):  # Specify the range of columns (A to I)
                            cell = sheet.cell(row=cell.row, column=col)
                            cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")

        
workbook.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")

#---------------------completed-----------------------------------------------------

workbook = load_workbook(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")
for sheet_name in sheet_names:
    # if sheet_name in sh_names1:
        sheet = workbook[sheet_name]
        for column in sheet.columns:
            non_empty_values = [cell.value for cell in column if cell.value]
            if non_empty_values:
                max_length = max(len(str(value)) for value in non_empty_values)
                column_letter = get_column_letter(column[0].column)
                adjusted_width = (max_length + 2) * 1.1
                sheet.column_dimensions[column_letter].width = adjusted_width
        for row in sheet.iter_rows():
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
        for row in sheet.iter_rows():
            for cell in row:
                cell.border = border_style
workbook.save(r"D:\CRF\Customer_callingvisiting_module_125367\Customer_callingvisit_report_final.xlsx")


s = smtplib.SMTP(host='smtp.office365.com', port=587)
s.starttls()
# print("aaa")
s.login('iotautomation@manappuram.com', 'ybjmxbfdyzkdnjtw')
print("xx")
msg = EmailMessage()
print("Ready for mailing")

msg['Subject'] = 'CUSTOMER CALLING VISITING REPORT'
msg['From'] = 'iot <iotautomation@manappuram.com>'
# msg['To'] = 'Sudeep <ssifhead@manappuram.com>','sreenivasan<ssifnho@manappuram.com>'
# msg['To']='sravan <iotsupport12@manappuram.com>'
msg['To']='saneesh <dataservice32@manappuram.com>'

# msg['Cc'] = 'sravan <iotsupport12@manappuram.com>','milka<dataservice31@manappuram.com>'

with open(r"D:\\CRF\\Customer_callingvisiting_module_125367\\Customer_callingvisit_report_final.xlsx", 'rb') as ra:
    attachment = ra.read()
msg.add_related(attachment, maintype='application', subtype='xlsx', filename='Customer_callingvisit_report_final.xlsx')
# image_cid = make_msgid(domain='mandala.com')
msg.add_alternative("""\
<html>
    <body>
        <p>Dear Sir,<br><p/>
                    
                
        <p>
        Kindly  find the report.
            </p>
<p>
        </p
        <br>                
        <p> Thanks & Regards,<br>
            R & D New age technology <br>
            ( This is an autogenerated mail )
        </p>
    </body>
</html>
""",subtype='html')    


# with open(r"D:\\CRF\\crf10\\119339-CRF_FOR_SHOP_VISIT_REPORT_AUTOMATION\\Shopvisit_report1.png", 'rb') as img:
#     maintype, subtype = mimetypes.guess_type(img.name)[0].split('/')
#     msg.get_payload()[1].add_related(img.read(),
#                                         maintype=maintype,
#                                         subtype=subtype,
#                                         cid=image_cid)

s.send_message(msg)
print("Mail send")
print("final section completed sucessfully.............")
# os.remove(r"D:\\CRF\\crf10\\119339-CRF_FOR_SHOP_VISIT_REPORT_AUTOMATION\\Shopvisit_report1.png")
# print("Image removed")

