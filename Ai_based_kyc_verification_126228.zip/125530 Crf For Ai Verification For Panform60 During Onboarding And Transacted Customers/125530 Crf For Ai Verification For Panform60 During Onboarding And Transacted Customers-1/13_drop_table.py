import cx_Oracle

# Database connection (update with your credentials)
try:
    connection = cx_Oracle.connect("", "", "")
    cursor = connection.cursor()

    # SQL command to drop the table
    drop_table_query = "DROP TABLE Kyc_checking_dec_21"

    # Execute the query
    cursor.execute(drop_table_query)
    print("Table dropped successfully.")

except cx_Oracle.DatabaseError as e:
    error, = e.args
    print(f"Error Code: {error.code}")
    print(f"Error Message: {error.message}")

finally:
    # Commit the changes and close the connection
    if cursor:
        cursor.close()
    if connection:
        connection.commit()
        connection.close()
