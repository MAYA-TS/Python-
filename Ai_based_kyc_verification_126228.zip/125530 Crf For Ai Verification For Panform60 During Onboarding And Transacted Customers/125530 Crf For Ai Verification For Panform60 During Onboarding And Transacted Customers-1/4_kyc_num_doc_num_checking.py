import cx_Oracle

connection = cx_Oracle.connect("", "", "")

try:
    cursor = connection.cursor()

    # Query to select cust_id, extracted_data, id_number, and identity_name
    query = """
    SELECT * FROM (SELECT a.cust_id, a.extracted_data, b.id_number, b.identity_name
  FROM Kyc_checking_dec_21 b
  LEFT OUTER JOIN tbl_kycverification_dec_21 a
    ON a.cust_id = b.cust_id
   and trunc(created_date) = trunc(sysdate))
   where cust_id is not null
   and extracted_data is not null
    """
    
    cursor.execute(query)  # Execute the query

    # Fetch all results
    results = cursor.fetchall()

    # Prepare the update statement
    update_query = """UPDATE tbl_kycverification_dec_21
    SET KYC_NUM_NOTMATCHING = :kyc_num_notmatching
    WHERE cust_id = :cust_id
    AND trunc(created_date)=trunc(sysdate)
"""
    
    for row in results:  # Iterate over the fetched results
        cust_id, extracted_data, id_number, identity_name = row  # Unpack the row
        
        print(f"Checking cust_id: {cust_id}")  # Print the current cust_id being checked
        
        # Initialize flags for matching and not matching
        match_found = False
        not_match_found = False
        
        if id_number is not None:
            if identity_name and ("COPY OF VOTERSID" in identity_name or "DRIVING LICENCE" in identity_name):
                # Check all digits in id_number against extracted_data
                if extracted_data is not None:
                    extracted_data_str = extracted_data.read()  # Convert CLOB to string
                    for digit in id_number:
                        if digit in extracted_data_str:
                            match_found = True
                            print(f"Digit {digit} found in extracted_data for cust_id: {cust_id}")
                        else:
                            not_match_found = True
                            print(f"Digit {digit} not found in extracted_data for cust_id: {cust_id}")
            else:
                # Check last four digits for UIDAI CARD (AADHAR)
                last_four_digits = id_number[-4:]  # Get the last 4 digits of id_number
                print(f"Last four digits of id_number: {last_four_digits}")  # Print last four digits
                
                if extracted_data is not None:
                    extracted_data_str = extracted_data.read()  # Convert CLOB to string
                    if last_four_digits not in extracted_data_str:
                        not_match_found = True  # Set flag to not match
                        print(f"Last four digits {last_four_digits} not found in extracted_data for cust_id: {cust_id}")
                    else:
                        match_found = True  # Set flag to match
                        print(f"Last four digits {last_four_digits} found in extracted_data for cust_id: {cust_id}")
                else:
                    print(f"No extracted_data for cust_id: {cust_id}")
                    not_match_found = True  # Set flag to not match due to missing extracted_data
        else:
            print(f"No id_number for cust_id: {cust_id}")
            not_match_found = True  # Set flag to not match due to missing id_number

        # Insert results into kyc_num_notmatching column
        if match_found:
            cursor.execute(update_query, kyc_num_notmatching="matched", cust_id=cust_id)
            print(f"Inserted cust_id: {cust_id} with status 'matched'")
        if not_match_found:
            cursor.execute(update_query, kyc_num_notmatching="not matched", cust_id=cust_id)
            print(f"Inserted cust_id: {cust_id} with status 'not matched'")

    # Commit the transaction
    connection.commit()
    print("Transaction committed.")

except cx_Oracle.DatabaseError as e:
    print("There was a problem with the database:", e)
finally:
    cursor.close()
    connection.close()
