from google.cloud import vision
import os
import shutil
import cx_Oracle

os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = r""
client = vision.ImageAnnotatorClient()

def extract_text(image_path):
    with open(image_path, "rb") as image_file:
        content = image_file.read() 
    image = vision.Image(content=content)
    response = client.text_detection(image=image)
    texts = response.text_annotations
    if texts:
        return texts[0].description
    else:
        return None

def search_keywords(text, keywords):
    matched_keywords = [keyword for keyword in keywords if keyword.lower() in text.lower()]
    return len(matched_keywords) >= 1


import cx_Oracle
from datetime import datetime

def store_in_database(filename, text):
    # Establish a database connection
    connection = cx_Oracle.connect("", "", "")
    cursor = connection.cursor()
    
    cust_id, kyc_number_with_extension = filename.split('=')
    kyc_number = kyc_number_with_extension.split('.')[0]  # Remove the file extension
    print(cust_id)
    print(kyc_number)
    
    # Insert data into the database including created_date
    cursor.execute("""
        INSERT INTO tbl_kycverification_dec_21 (cust_id, kyc_number, extracted_data, created_date)
        VALUES (:cust_id, :kyc_number, :text, :created_date)""",
        cust_id=cust_id, kyc_number=kyc_number, text=text, created_date=datetime.now())
    
    # Commit the transaction
    connection.commit()
    cursor.close()
    connection.close()

def process_images(image_folder, kyc_folder, fake_folder, keywords):
    for image_name in os.listdir(image_folder):
        
        image_path = os.path.join(image_folder, image_name)
       
        text = extract_text(image_path)
        filename_without_ext = os.path.splitext(image_name)[0]

        if text:
            # Store filename and extracted text in the database
            store_in_database(filename_without_ext, text)

            if search_keywords(text, keywords):
                if os.path.exists(os.path.join(kyc_folder, image_name)):
                    os.remove(os.path.join(kyc_folder, image_name))
                
                shutil.copy(image_path, kyc_folder)
                print(f"Image '{image_name}' moved to real folder.")
            else:
                if os.path.exists(os.path.join(fake_folder, image_name)):
                    os.remove(os.path.join(fake_folder, image_name))
             
                shutil.copy(image_path, fake_folder)
                print(f"Image '{image_name}' moved to fake folder.")
        else:
            if os.path.exists(os.path.join(fake_folder, image_name)):
                os.remove(os.path.join(fake_folder, image_name))
         
            shutil.copy(image_path, fake_folder)
            print(f"Image '{image_name}' moved to fake folder.")
        
        os.remove(image_path)
        print(f"Removed image from downloaded_images: {image_name}")
          

if __name__ == "__main__":
    image_folder = r'C:\Users\405231\Downloads\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers-1\KYC-img'
    kyc_folder = r'C:\Users\405231\Downloads\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers-1\real'
    fake_folder = r'C:\Users\405231\Downloads\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers-1\fake'
    aadhar_keywords = ["Government of India", "unique identification", "authority of india","vid","Mobile no:","Dob:"]
    aadhar_keywords1 = ["Government of india", "Address","Year of birth","Unique","identification","Authority of india"]
    adhar_keywords2 = [ "Government of india","unique","identification","Authority of india","Aadhaar","to","Enrollment No","Dob"]
    adhar_keywords3 = [ "Driving","licence","union of india","name","lmv","trans","date of issue"]
    adhar_keywords4 = [ "indian union","driving","licence","name","date of birth","organ donor","address"]
    adhar_keywords5 = ["Government of india","Date of Birth","DOB","vid","address","unique","identification","authority of india"]
    adhar_keywords6 = ["election","commission","of india","identity card","name","elector's","age","address"]
    adhar_keywords6 = ["indian union","motor","driving licence","transport","address","lmv","mcwg"]
    adhar_keywords6 = ["election","commission","of india","photo","name","father's name","date of birth","age"]
    adhar_keywords6 = ["indian union","name","date of birth","address","issue date","blood group","Dl no:","validity"]

    process_images(image_folder, kyc_folder, fake_folder, aadhar_keywords + aadhar_keywords1 + adhar_keywords2 + adhar_keywords3+adhar_keywords4+adhar_keywords5) 