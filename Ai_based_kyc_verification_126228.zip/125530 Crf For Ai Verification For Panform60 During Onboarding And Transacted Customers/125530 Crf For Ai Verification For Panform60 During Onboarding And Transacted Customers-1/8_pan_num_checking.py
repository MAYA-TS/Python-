import pandas as pd
import cx_Oracle

# Database connection (update with your credentials)
connection = cx_Oracle.connect("", "", "")

# Query to fetch data from the table
query = "SELECT PAN_NUMBER, EXTRACTED_DATA FROM tbl_kycverification_dec_21 where trunc(created_date)=trunc(sysdate) AND PAN_NUMBER IS NOT NULL"
df = pd.read_sql(query, connection)

def check_pan_number(row):
    pan_number = row['PAN_NUMBER']
    extracted_data = row['EXTRACTED_DATA']
    
    # Convert CLOB to string if it's a LOB object
    if isinstance(extracted_data, cx_Oracle.LOB):
        extracted_data = extracted_data.read()  # Read the CLOB data
    # Ensure extracted_data is a string
    extracted_data = str(extracted_data) if extracted_data is not None else ""

    # Check if the PAN number is present in the extracted data
    if pan_number is not None:
        return pan_number.lower() in extracted_data.lower()
    return False

# Apply the function to the DataFrame
df['pan_number_found'] = df.apply(check_pan_number, axis=1)

# Update the results back into the database
for index, row in df.iterrows():
    pan_number_found = row['pan_number_found']
    pan_number = row['PAN_NUMBER']
    
    # Update the result into the table
    update_query = """
    UPDATE tbl_kycverification_dec_21
    SET pan_number_found = :pan_number_found
    WHERE PAN_NUMBER = :pan_number AND trunc(created_date)=trunc(sysdate)
    """
    with connection.cursor() as cursor:
        cursor.execute(update_query, pan_number_found=str(pan_number_found), pan_number=pan_number)

# Commit the changes
connection.commit()

# Display results
print(df[['PAN_NUMBER', 'pan_number_found']])

# Close the database connection
connection.close()
