import pandas as pd
import cx_Oracle

# Database connection (update with your credentials)
connection = cx_Oracle.connect("", "", "")

# Query to fetch data from the table
query = """
SELECT KYC_NUMBER, CUST_ID, EXTRACTED_DATA 
FROM tbl_kycverification_dec_21 
WHERE kyc_number IS NOT NULL AND trunc(created_date) = trunc(sysdate)
"""
df = pd.read_sql(query, connection)

# Define keywords for each KYC type
keywords = {
    'UIDAI CARD (AADHAR)': ["Government of India", "unique identification", "authority of india", "vid", "Mobile no:", "Dob:", "Address", "Year of birth", "Unique", "Aadhaar", "Enrollment No"],
    'DRIVING LICENCE': ["Driving", "licence", "union of india", "name", "lmv", "trans", "date of issue", "indian union", "date of birth", "organ donor", "address"],
    'COPY OF VOTERSID': ["election", "commission", "of india", "identity card", "name", "elector's", "age", "address", "photo", "father's name", "date of birth", "issue date", "blood group", "Dl no:", "validity"]
}

def check_keywords(row):
    extracted_data = row['EXTRACTED_DATA']
    
    # Convert CLOB to string if it's a LOB object
    if isinstance(extracted_data, cx_Oracle.LOB):
        extracted_data = extracted_data.read()  # Read the LOB data
    # Ensure extracted_data is a string
    extracted_data = str(extracted_data)  # Convert to string if not already

    # Check for any keyword in the extracted data
    for kyc_type, keyword_list in keywords.items():
        if any(keyword.lower() in extracted_data.lower() for keyword in keyword_list):
            return True  # Found a keyword for this KYC type
    return False  # No keywords found

# Apply the function to the DataFrame
df['keyword_found'] = df.apply(check_keywords, axis=1)

# Insert results back into the database
for index, row in df.iterrows():
    keyword_found = row['keyword_found']
    kyc_number = row['KYC_NUMBER']
    
    # Corrected SQL statement
    update_query = """
       UPDATE tbl_kycverification_dec_21
    SET keyword_found = :keyword_found
    WHERE KYC_NUMBER = :kyc_number AND trunc(created_date) = trunc(sysdate)
    """
    with connection.cursor() as cursor:
        cursor.execute(update_query, keyword_found=str(keyword_found), kyc_number=kyc_number)

# Commit the changes
connection.commit()

# Display results
print(df[['KYC_NUMBER', 'keyword_found']])

# Close the database connection
connection.close()
