from email.mime.text import MIMEText
import cx_Oracle
import openpyxl
import pandas as pd
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Alignment
from openpyxl.styles import Border,Side,Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter



# Database connection parameters
connection = cx_Oracle.connect("", "", "")

# # Query to get distinct segment names
# seg_query = "SELECT DISTINCT SEG_NAME FROM Kyc_checking_dec_21"
# seg_names = pd.read_sql(seg_query, connection)['SEG_NAME'].tolist()

seg_names = {'TW':['twops18@manappuram.com','twopshead@manappuram.com'],'CV':['cvcheques@manappuram.com','opsheadcvce@manappuram.com'],'CE':['cvcheques@manappuram.com','opsheadcvce@manappuram.com'],'AUTO':['cvops8@manappuram.com','headopsauto@manappuram.com'],'FE':['fekycteamlead@manappuram.com','feopshead@manappuram.com']}


# Loop through each segment name
for seg_name,value in seg_names.items():
    # Query to get customer IDs and remarks
    report_query = f"""
    select * from (SELECT DISTINCT TRIM(a.cust_id) AS cust_id, a.remarks
    FROM TBL_AI_VERIFICATION_REPORT_CV a
    LEFT OUTER JOIN Kyc_checking_dec_21 b ON lpad(TRIM(a.cust_id),14,0) = lpad(TRIM(b.cust_id),14,0)
    WHERE b.seg_name = '{seg_name}'
    AND trunc(a.created_date) = trunc(sysdate)
    ORDER BY a.remarks ASC)
    """
    report_df = pd.read_sql(report_query, connection)

    # Create a new Excel workbook and select the active worksheet
    wb = Workbook()
    ws = wb.active

    # Set the header
    headers = ['Customer ID', 'Remarks']
    ws.append(headers)

    # Apply header styling
    header_fill = PatternFill(start_color='FFFF00', end_color='FFFF00', fill_type='solid')  # Yellow color
    for cell in ws[1]:
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')

    # Write data to the worksheet
    for row in report_df.itertuples(index=False):
        ws.append(row)

    # Center align all data
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=1, max_col=len(headers)):
        for cell in row:
            cell.alignment = Alignment(horizontal='center')

    # Save the report to an Excel file
    excel_file = f"{seg_name}_fake_verification_report.xlsx"
    wb.save(excel_file)

    # Check if there is any data other than headers
    if ws.max_row > 1:  # More than just the header row
        workbook = openpyxl.load_workbook(excel_file)
        sheet_names = workbook.sheetnames
        heading_color = '070F2B'  # Header color
        body_color = 'FFFFFF'  # Body color
        border_style = Border(
            left=Side(border_style='thin'),
            right=Side(border_style='thin'),
            top=Side(border_style='thin'),
            bottom=Side(border_style='thin'))

        for sheet_name in sheet_names:
            sheet = workbook[sheet_name]
            header_font = Font(color="ffffff", bold=True)
            header_fill = PatternFill(start_color='070F2B', end_color='070F2B', fill_type='solid')
            for cell in sheet[1]:
                cell.fill = header_fill
                cell.font = header_font
            body_fill = PatternFill(start_color=body_color, end_color=body_color, fill_type='solid')
            for row in sheet.iter_rows(min_row=2):
                for cell in row:
                    cell.fill = body_fill

            for column in sheet.columns:
                non_empty_values = [cell.value for cell in column if cell.value]
                if non_empty_values:
                    max_length = max(len(str(value)) for value in non_empty_values)
                    column_letter = get_column_letter(column[0].column)
                    adjusted_width = (max_length + 2) * 1.1  # Adjust the width as desired
                    sheet.column_dimensions[column_letter].width = adjusted_width

            for row in sheet.rows:
                max_height = max(str(cell.value).count('\n') + 1 for cell in row if cell.value)
                row_number = row[0].row
                adjusted_height = max_height * 17  # Adjust the height as desired
                sheet.row_dimensions[row_number].height = adjusted_height

            for row in sheet.iter_rows():
                for cell in row:
                    cell.alignment = Alignment(horizontal='center', vertical='center')
            for row in sheet.iter_rows():
                for cell in row:
                    cell.border = border_style

        workbook.save(excel_file)
        print("Excel designed 'OK'")

        # Prepare to send the email
        msg = MIMEMultipart()
        msg['From'] = 'iotautomation@manappuram.com'  # Replace with your email
        msg['To'] = value[0]
        msg['Cc'] = value[1]  # Recipient's email
        msg['Bcc'] = '405231@manappuram.com'  # Replace with BCC email if needed
        msg['Subject'] = f"Test Report for Fake KYC Verification of {seg_name}"

        # Email body content
        body = (
            "Dear Sir,\n\n"
            "Please find the attachment.\n\n"
            "Thanks & Regards,\n"
            "(This is an autogenerated mail)\n"
            "R&D"
        )
        msg.attach(MIMEText(body, 'plain'))

        # Attach the Excel file
        with open(excel_file, 'rb') as attachment:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(attachment.read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f'attachment; filename={excel_file}')
            msg.attach(part)

        # Send the email
        try:
            with smtplib.SMTP('smtp.office365.com', 587) as server:
                server.starttls()
                server.login('iotautomation@manappuram.com', 'ybjmxbfdyzkdnjtw')  # Replace with your credentials
                server.send_message(msg)
            print(f"Email sent to {value} for segment {seg_name}.")
        except Exception as e:
            print(f"Failed to send email to {value}: {e}")
    else:
        print("No data to send in the report. Email will not be sent.")

    # Close the database connection
connection.close()


