import os
import cx_Oracle

def save_document(cust_id, id_no, document, download_dir_pdf, download_dir_word, download_dir_images):
    document_content = document.read() 
    file_extension = None
    download_dir = None
    
    if document_content.startswith(b'%PDF'):
        file_extension = 'pdf'  
        download_dir = download_dir_pdf
    elif b'Word.Document' in document_content or b'word/document.xml' in document_content:
        file_extension = 'docx'
        download_dir = download_dir_word
    elif document_content.startswith(b'PNG'):
        file_extension = 'png'
        download_dir = download_dir_images
    elif document_content.startswith(b'tiff'):
        file_extension = 'tiff'
        download_dir = download_dir_images
    elif document_content.startswith(b'bmp'):
        file_extension = 'bmp'
        download_dir = download_dir_images
    elif document_content.startswith(b'GIF'):
        file_extension = 'gif'
        download_dir = download_dir_images
    elif document_content.startswith(b'JPEG'):
        file_extension = 'jpeg'
        download_dir = download_dir_images
    else:
        file_extension = 'jpg'
        download_dir = download_dir_images

    filename = f"{cust_id}={id_no}.{file_extension}"
    file_path = os.path.join(download_dir, filename)

    counter = 1
    while os.path.exists(file_path):
        filename = f"{cust_id}={id_no}({counter}).{file_extension}"
        file_path = os.path.join(download_dir, filename)
        counter += 1

    with open(file_path, 'wb') as document_file:
        document_file.write(document_content)

    print(f"Downloaded: {file_path}")

def download_all_documents():
    sql = """SELECT a.seg_name, a.customer_id, a.mafil_cust_id, b.pan, b.pan_copy
              FROM tw_cv_cus_yesterday_seg a
              LEFT OUTER JOIN dms.deposit_pan_detail@uatr_backup2 b
              ON a.mafil_cust_id = b.cust_id
              WHERE TRUNC(a.pr_date) = TRUNC(SYSDATE - 1) and pan_copy is not null"""  
    
    conn = cx_Oracle.connect("", "", "")  
    cursor = conn.cursor()
    cursor.execute(sql)

    download_dir_pdf = r'C:\Users\405231\Downloads\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers-1\PAN-pdf' 
    download_dir_word = r'C:\Users\405231\Downloads\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers-1\PAN-pdf'  
    download_dir_images = r'C:\Users\405231\Downloads\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers-1\PAN-img' 

    os.makedirs(download_dir_pdf, exist_ok=True)
    os.makedirs(download_dir_word, exist_ok=True)
    os.makedirs(download_dir_images, exist_ok=True)

    for row in cursor.fetchall():
        cust_id = row[2]  # mafil_cust_id
        id_no = row[3]    # Assuming 'pan' is at index 3
        document = row[4] # Assuming 'pan_copy' is at index 4

        if document is not None:
            save_document(cust_id, id_no, document, download_dir_pdf, download_dir_word, download_dir_images)
        else:
            print(f"No document found for cust_id: {cust_id}")

    cursor.close()
    conn.close()

download_all_documents()