import fitz
import os

def pdf_to_image(pdf_folder, image_folder):
    pdf_files = sorted([filename for filename in os.listdir(pdf_folder) if filename.lower().endswith(".pdf")])
    
    for filename in pdf_files:
        pdf_path = os.path.join(pdf_folder, filename)
        pdf_document = fitz.open(pdf_path)
        
        for page_number in range(pdf_document.page_count):
            page = pdf_document.load_page(page_number)
            image = page.get_pixmap()
            image_path = os.path.join(image_folder, f"{filename}_{page_number}.png")
            image.save(image_path, "png")
            print(f"Converted {filename} page {page_number + 1} to image.")
        
        pdf_document.close()
        os.remove(pdf_path)

pdf_folder =  r"C:\Users\405231\Downloads\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers-1\KYC-pdf"
image_folder = r"C:\Users\405231\Downloads\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers-1\KYC-img" 
pdf_to_image(pdf_folder, image_folder)


def pdf_to_image_pan(pdf_folder, image_folder):
    pdf_files = sorted([filename for filename in os.listdir(pdf_folder) if filename.lower().endswith(".pdf")])
    
    for filename in pdf_files:
        pdf_path = os.path.join(pdf_folder, filename)
        pdf_document = fitz.open(pdf_path)
        
        for page_number in range(pdf_document.page_count):
            page = pdf_document.load_page(page_number)
            image = page.get_pixmap()
            image_path = os.path.join(image_folder, f"{filename}_{page_number}.png")
            image.save(image_path, "png")
            print(f"Converted {filename} page {page_number + 1} to image.")
        
        pdf_document.close()
        os.remove(pdf_path)

pdf_folder =  r"C:\Users\405231\Downloads\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers-1\PAN-pdf"
image_folder = r"C:\Users\405231\Downloads\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers-1\PAN-img" 
pdf_to_image_pan(pdf_folder, image_folder)
