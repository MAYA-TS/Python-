import cx_Oracle
from datetime import datetime

connection = cx_Oracle.connect("", "", "")

try:
    cursor = connection.cursor()

    # SQL query to select customer_id where pan_copy is NULL
    select_query = """
    select * from(SELECT a.seg_name, a.customer_id, a.mafil_cust_id, b.pan, b.pan_copy
              FROM tw_cv_cus_yesterday_seg a
              LEFT OUTER JOIN dms.deposit_pan_detail@uatr_backup2 b
              ON a.mafil_cust_id = b.cust_id
              WHERE TRUNC(a.pr_date) = TRUNC(SYSDATE - 1) and pan_copy is  null)
              where mafil_cust_id not in(select   a.mafil_cust_id
from tw_cv_cus_yesterday_seg a
      left outer join mana0809.customer_photo@uatr_backup2 c
 on  a.mafil_cust_id =c.cust_id
 left outer join mana0809.identity_dtl@uatr_backup2 d
 on  a.mafil_cust_id =d.cust_id
 left outer join mana0809.identity@uatr_backup2 e
 on d.identity_id = e.identity_id
      where trunc(a.pr_date) =trunc(sysdate-1)
      and id_number is not  null and kyc_photo is not null)
    """
    
    cursor.execute(select_query)
    
    # Fetch all customer_ids that meet the criteria
    customer_ids = cursor.fetchall()

    # Insert each customer_id into the target table with remark and created_date
    insert_query = """
    INSERT INTO TBL_AI_VERIFICATION_REPORT_CV (cust_id, remarks, created_date) 
    VALUES (:1, :2, :3)
    """
    
    for customer_id in customer_ids:
        cursor.execute(insert_query, (customer_id[1], "Document null case", datetime.now()))

    # Commit the transaction
    connection.commit()

except cx_Oracle.DatabaseError as e:
    print("There was a problem with the database:", e)
finally:
    # Close the cursor and connection
    cursor.close()
    connection.close()
