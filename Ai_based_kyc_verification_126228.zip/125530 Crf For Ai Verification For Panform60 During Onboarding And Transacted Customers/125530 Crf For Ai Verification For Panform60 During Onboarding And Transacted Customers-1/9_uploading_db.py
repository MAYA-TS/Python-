import pandas as pd
import cx_Oracle
from openpyxl.styles import Font, PatternFill

# Database connection (update with your credentials)
connection = cx_Oracle.connect("", "", "")

# Define your queries with remarks
queries = {
    'null_image': ("SELECT cust_id FROM tbl_kycverification_dec_21 WHERE REMARKS = 'null image' and trunc(created_date)=trunc(sysdate)", "Document null case"),
    'kyc_number_not_matching': ("SELECT cust_id FROM tbl_kycverification_dec_21 WHERE KYC_NUM_NOTMATCHING = 'not matched'and trunc(created_date)=trunc(sysdate)", "KYC number and uploaded image number not matching case"),
    'kyc_type_checking': ("SELECT cust_id FROM tbl_kycverification_dec_21 WHERE KEYWORD_FOUND = 'False'and trunc(created_date)=trunc(sysdate)", "KYC type not matched case"),
    'pan_number_not_matching': ("SELECT cust_id FROM tbl_kycverification_dec_21 WHERE PAN_NUMBER_FOUND = 'False'and trunc(created_date)=trunc(sysdate)", "PAN number not matching case"),
    'fake_images':("select cust_id from customer_kyc_verification_fake  where remark = 'Fake' and trunc(upload_date)=trunc(sysdate)","Fake customer photo"),
    'null_images':("select cust_id from customer_kyc_verification_fake  where remark = 'Image None' and trunc(upload_date)=trunc(sysdate)","Customer photo is null")

}

# Fetch data for each query and store in a list
dataframes = []
for key, (query, remark) in queries.items():
    df = pd.read_sql(query, connection)
    df['Remarks'] = remark  # Add remarks column
    dataframes.append(df)

# Close the database connection
connection.close()

# Combine DataFrames into one
combined_data = pd.concat(dataframes, ignore_index=True)

# Export to Excel with styling
output_file = 'kyc_verification_results.xlsx'
with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
    combined_data.to_excel(writer, index=False, sheet_name='KYC Results')

    # Access the workbook and the sheet
    workbook = writer.book
    worksheet = writer.sheets['KYC Results']

    # Set the column widths
    worksheet.column_dimensions['A'].width = 20  # cust_id
    worksheet.column_dimensions['B'].width = 50  # Remarks

    # Add a header style
    header_font = Font(bold=True, color='FFFFFF')
    header_fill = PatternFill(start_color='4F81BD', end_color='4F81BD', fill_type='solid')

    for cell in worksheet[1]:  # First row for headers
        cell.font = header_font
        cell.fill = header_fill

print(f'Data exported successfully to {output_file}')


import pandas as pd
import cx_Oracle
from datetime import datetime

# Step 1: Read the Excel file
excel_file_path = r'C:\Users\405231\Downloads\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers-1\kyc_verification_results.xlsx'
df = pd.read_excel(excel_file_path)

# Step 2: Connect to Oracle Database
connection = cx_Oracle.connect("KPMG", "Asd$1234", "HISTDB")
cursor = connection.cursor()

# Step 3: Insert data into the table
for index, row in df.iterrows():
    created_date = datetime.now()  # Get the current date and time
    cursor.execute("""
        INSERT INTO TBL_AI_VERIFICATION_REPORT_CV (CUST_ID, Remarks, created_date) 
        VALUES (:1, :2, :3)
    """, (row['CUST_ID'], row['Remarks'], created_date))

# Step 4: Commit the transaction and close the connection
connection.commit()
cursor.close()
connection.close()
