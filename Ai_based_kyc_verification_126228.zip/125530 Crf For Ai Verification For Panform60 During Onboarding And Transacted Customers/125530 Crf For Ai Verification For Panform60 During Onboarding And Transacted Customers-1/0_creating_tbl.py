import cx_Oracle

# Database connection (update with your credentials)
connection = cx_Oracle.connect("", "", "")

# SQL query to create the table
create_table_query = """
create table Kyc_checking_dec_21 as (select * from (select   a.seg_name,a.customer_id,a.mafil_cust_id,nvl(c.cust_id,a.mafil_cust_id) cust_id,d.id_number,
e.identity_name,d.identity_id,c.dep_head||'@manappuram.com.com' head_mail
from tw_cv_cus_yesterday_seg a
      left outer join mana0809.customer_photo@uatr_backup2 c
 on  a.mafil_cust_id =c.cust_id
 left outer join mana0809.identity_dtl@uatr_backup2 d
 on  a.mafil_cust_id =d.cust_id
 left outer join mana0809.identity@uatr_backup2 e
 on d.identity_id = e.identity_id
 left outer join (
      select case when dep_name ='COMMERCIAL VEHICLE FINANCE' then 'CV'
      when  dep_name ='FARM EQUIPMENT DEPARTMENT' then 'FE'
        when dep_name ='CAR LOAN DEPARTMENT' then 'AUTO'
          when dep_name ='TWO WHEELER FINANCE-TWF' then 'TW' end dep_name,dep_head
            from  mana0809.department_mst@uatr_backup2
            where dep_id in (654,578,653,652))c
            on (case when a.seg_name ='CE' then 'CV' else a.seg_name end) =c.dep_name
      where trunc(a.pr_date) =trunc(sysdate-1)))"""

# Execute the query
try:
    cursor = connection.cursor()
    cursor.execute(create_table_query)
    print("Table Kyc_checking_dec_21 created successfully.")
except cx_Oracle.DatabaseError as e:
    print(f"An error occurred: {e}")
finally:
    cursor.close()
    connection.close()
