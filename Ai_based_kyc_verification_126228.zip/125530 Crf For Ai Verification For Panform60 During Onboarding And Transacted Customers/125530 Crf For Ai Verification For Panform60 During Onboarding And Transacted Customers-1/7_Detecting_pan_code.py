from google.cloud import vision
import os
import shutil
import cx_Oracle

os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = r""
client = vision.ImageAnnotatorClient()

def extract_text(image_path):
    with open(image_path, "rb") as image_file:
        content = image_file.read() 
    image = vision.Image(content=content)
    response = client.text_detection(image=image)
    texts = response.text_annotations
    if texts:
        return texts[0].description
    else:
        return None

def search_keywords(text, keywords):
    matched_keywords = [keyword for keyword in keywords if keyword.lower() in text.lower()]
    return len(matched_keywords) >= 1


import cx_Oracle
from datetime import datetime

def store_in_database(filename, text):
    # Establish a database connection
    connection = cx_Oracle.connect("", "", "")
    cursor = connection.cursor()
    
    cust_id, PAN_NUMBER_with_extension = filename.split('=')
    PAN_NUMBER = PAN_NUMBER_with_extension.split('.')[0]  # Remove the file extension
    print(cust_id)
    print(PAN_NUMBER)
    
    # Insert data into the database including created_date
    cursor.execute("""
        INSERT INTO tbl_kycverification_dec_21 (cust_id, PAN_NUMBER, extracted_data, created_date)
        VALUES (:cust_id, :PAN_NUMBER, :text, :created_date)""",
        cust_id=cust_id, PAN_NUMBER=PAN_NUMBER, text=text, created_date=datetime.now())
    
    # Commit the transaction
    connection.commit()
    cursor.close()
    connection.close()


def process_images(image_folder, kyc_folder, fake_folder, keywords):
    for image_name in os.listdir(image_folder):
        
        image_path = os.path.join(image_folder, image_name)
       
        text = extract_text(image_path)
        filename_without_ext = os.path.splitext(image_name)[0]

        if text:
            # Store filename and extracted text in the database
            store_in_database(filename_without_ext, text)

            if search_keywords(text, keywords):
                if os.path.exists(os.path.join(kyc_folder, image_name)):
                    os.remove(os.path.join(kyc_folder, image_name))
                # print('                                                    ')
                # print('----------------------------------------------------')
                # print(text, "111111111111111111111")
                # print('----------------------------------------------------')
                # print('                                                    ')
                shutil.copy(image_path, kyc_folder)
                print(f"Image '{image_name}' moved to real folder.")
            else:
                if os.path.exists(os.path.join(fake_folder, image_name)):
                    os.remove(os.path.join(fake_folder, image_name))
                # print('                                                    ')
                # print('----------------------------------------------------')
                # print(text, "22222222222222222222222")
                # print('----------------------------------------------------')
                # print('                                                    ')
                shutil.copy(image_path, fake_folder)
                print(f"Image '{image_name}' moved to fake folder.")
        else:
            if os.path.exists(os.path.join(fake_folder, image_name)):
                os.remove(os.path.join(fake_folder, image_name))
            # print('                                                    ')
            # print('----------------------------------------------------')
            # print("No text found", "33333333333333333333333333333")
            # print('----------------------------------------------------')
            # print('                                                    ')
            shutil.copy(image_path, fake_folder)
            print(f"Image '{image_name}' moved to fake folder.")
        
        os.remove(image_path)
        print(f"Removed image from downloaded_images: {image_name}")
          


# pdf_folder = r"D:\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers\download_pdf"
# image_folder = r"D:\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers\download" 


if __name__ == "__main__":
    image_folder = r'C:\Users\405231\Downloads\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers-1\PAN-img'
    kyc_folder = r'C:\Users\405231\Downloads\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers-1\pan_real'
    fake_folder = r'C:\Users\405231\Downloads\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers\125530 Crf For Ai Verification For Panform60 During Onboarding And Transacted Customers-1\pan_fake'
    pan_keyword = ["Government of India", "Permanent account number", "income tax department"]
  

    process_images(image_folder, kyc_folder, fake_folder, pan_keyword) 