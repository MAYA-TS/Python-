import pandas as pd
import cx_Oracle
from openpyxl import load_workbook
import pandas as pd
import cx_Oracle
import openpyxl
from email.message import EmailMessage
import pandas as pd
from openpyxl.styles import PatternFill,Font
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side


df = pd.read_excel(r'D:\\CRF\\Area_splitting_northern_states_124303\\from_branch_name1 - Copy.xlsx')


branch_names = df['branch_name'].tolist()


conn = cx_Oracle.connect("mana0809", "mana0809", "MAFILUAT")


cursor = conn.cursor()


output_data = []  # Create an empty list to store the output data


for branch_name in branch_names:
    query = f"SELECT distinct from_branch_name, to_branch_name, round(distance,2) distance FROM nearest_branch_mapping WHERE from_branch_name = '{branch_name}' AND distance > 0 ORDER BY TO_NUMBER(distance) asc FETCH FIRST 3 ROWS ONLY"


    cursor.execute(query)


    results = cursor.fetchall()


    for row in results:
        print(row)
        output_data.append(row) 


    query_last_row = f"SELECT from_branch_name, to_branch_name, distance FROM nearest_branch_mapping WHERE from_branch_name = '{branch_name}' AND to_branch_name = '{branch_name}' AND distance = 0 ORDER BY TO_NUMBER(distance) desc FETCH FIRST 1 ROW ONLY"
    cursor.execute(query_last_row)
    last_row = cursor.fetchone()
    if last_row:
        print(last_row)
        output_data.append(last_row)


cursor.close()
conn.close()




output_df = pd.DataFrame(output_data, columns=['From Branch Name', 'To Branch Name', 'Distance'])


output_df['Distance'] = pd.to_numeric(output_df['Distance'], errors='coerce')


# Calculate the average distance for each group of 4 rows
output_df['average'] = output_df.groupby(output_df.index // 4)['Distance'].transform('mean')


# Remove the first row (heading) from the DataFrame
# output_df = output_df.iloc[1:]


# Rename the average column
output_df.rename(columns={'average': 'Average Distance'}, inplace=True)  # Modify the heading name here


# Write the DataFrame to an Excel file with the average column name
output_df.to_excel('Report.xlsx', index=False, header=True)




workbook = load_workbook('Report.xlsx')
# worksheet = workbook.active


# # Merge cells D2:D5
# worksheet.merge_cells('D2:D5')


# # Merge cells D6:D10
# worksheet.merge_cells('D6:D9')


# # Merge cells D11:D14
# worksheet.merge_cells('D10:D13')


# # Save the modified workbook
# workbook.save('output.xlsx')




worksheet = workbook.active


# Get the maximum row number in the worksheet
max_row = worksheet.max_row


# Merge cells in the desired pattern
for i in range(2, max_row + 1, 4):
    worksheet.merge_cells(f'D{i}:D{i+3}')


# Save the modified workbook
workbook.save('Report.xlsx')










workbook = openpyxl.load_workbook(r"D:\\CRF\\Area_splitting_northern_states_124303\\Report.xlsx")
sheet_names = workbook.sheetnames
heading_color =  'CD5C5C'    #'73BCC5'#'8080ff'  # Red color
body_color = 'f7f7f7'  # Green color
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))








for sheet_name in sheet_names:
    sheet = workbook[sheet_name]
    header_font = Font(color="FFFFFF", bold=True)
    header_fill = PatternFill(start_color='CD5C5C', end_color='CD5C5C', fill_type='solid')
    for cell in sheet[1]:
        cell.fill = header_fill
        cell.font = header_font
    body_fill = PatternFill(start_color=body_color, end_color=body_color, fill_type='solid')
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            cell.fill = body_fill
            
    for column in sheet.columns:
        non_empty_values = [cell.value for cell in column if cell.value]
        if non_empty_values:
            max_length = max(len(str(value)) for value in non_empty_values)
            column_letter = get_column_letter(column[0].column)
            adjusted_width = (max_length + 2) * 1.2  # Adjust the width as desired
            sheet.column_dimensions[column_letter].width = adjusted_width
    for row in sheet.rows:
        max_height = max(str(cell.value).count('\n') + 1 for cell in row if cell.value)
        row_number = row[0].row
        adjusted_height = max_height * 17 # Adjust the height as desired
        sheet.row_dimensions[row_number].height = adjusted_height
    for row in sheet.iter_rows():
        for cell in row:
            cell.alignment = Alignment(horizontal='center', vertical='center')
    for row in sheet.iter_rows():
        for cell in row:
            cell.border = border_style
workbook.save(r"D:\\CRF\\Area_splitting_northern_states_124303\\Report.xlsx")


from openpyxl.styles import PatternFill


# Select the worksheet
worksheet = workbook.active


# Define the range of cells to color
start_row = 2  # Start from the 4th row
end_row = worksheet.max_row  # End at the last row
# start_col = 2 # Start from the 1st column
end_col = worksheet.max_column  # End at the last column


# Color every 4th cell in the range
for row in worksheet.iter_rows(min_row=start_row, max_row=end_row):
    for cell in row:
        if (cell.row - start_row + 1) % 4 == 0:
            cell.fill = PatternFill(start_color='fae1dc', end_color='fae1dc', fill_type='solid')
        else:
            cell.fill = PatternFill(start_color='FFFFFF', end_color='FFFFFF', fill_type='solid')


# Save the modified workbook
workbook.save('Report.xlsx')