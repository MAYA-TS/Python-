from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from msilib.schema import Font
import xlsxwriter
import os
import cx_Oracle
import openpyxl
from openpyxl import Workbook
from email.message import EmailMessage
from email.utils import make_msgid
import mimetypes
from tableau_api_lib import TableauServerConnection
from tableau_api_lib.utils import querying
from tableau_api_lib.utils.common import flatten_dict_column
import pandas as pd
import xlrd
from pandas import ExcelWriter
from openpyxl import load_workbook
from openpyxl.styles import PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side
import smtplib
import schedule
import tableauserverclient as TSC
from datetime import datetime


conn = cx_Oracle.connect("kpmg", "Asd$1234", "HISTDB")
print("Oracle database connected")

df1=pd.read_sql( """select Branch_name,
       count(distinct(loan_id)) Billing_Count,
       count(distinct(case when called_date is not null then cust_name end)) Called_Count,
       count(distinct(case when called_date is null then cust_name end)) Calling_pending,
       count(distinct(case when monthly_paid_status = 'PAID' then cust_name end)) EMI_paid_count,
       count(distinct(case when monthly_paid_status = 'NOT PAID' then cust_name end)) EMI_pending_count
  from tab_newngl_call_rpt
 where trunc(emi_date) = trunc(sysdate + 1)
   and calling_or_visiting = 'VISITING'
   and loan_overdue > 0
 group by Branch_name""",con=conn)
print("df1 completed---------------------------------------------------")


df2=pd.read_sql("""select Branch_name,
       count(distinct(loan_id)) Billing_Count,
       count(distinct(case when called_date is not null then cust_name end)) Called_Count,
       count(distinct(case when called_date is null then cust_name end)) Calling_pending,
       count(distinct(case when monthly_paid_status = 'PAID' then cust_name end)) EMI_paid_count,
       count(distinct(case when monthly_paid_status = 'NOT PAID' then cust_name end)) EMI_pending_count
  from tab_newngl_call_rpt
 where trunc(emi_date) >= trunc(sysdate, 'mm')
   and trunc(emi_date) <= trunc(sysdate)
   and calling_or_visiting = 'VISITING'
   and loan_overdue > 0
 group by Branch_name""",con=conn)
        
print("df2 completed---------------------------------------------------")

df3=pd.read_sql("""select Branch_name,
       count(distinct(loan_id)) Billing_Count,
       count(distinct(case when called_date is not null then cust_name end)) Called_Count,
       count(distinct(case when called_date is null then cust_name end)) Calling_pending,
       count(distinct(case when monthly_paid_status = 'PAID' then cust_name end)) EMI_paid_count,
       count(distinct(case when monthly_paid_status = 'NOT PAID' then cust_name end)) EMI_pending_count
  from tab_newngl_call_rpt
 where trunc(emi_date) >= trunc(sysdate, 'mm')
   and trunc(emi_date) <= last_day(trunc(sysdate))
   and calling_or_visiting = 'VISITING'
   and loan_overdue > 0
 group by Branch_name""",con=conn)
   
print("df3 completed---------------------------------------------------") 

df4=pd.read_sql("""select assigned_employee,
       Branch_name,
       count(distinct(loan_id)) Assigned_count,
       count(distinct(case when called_date is not null then cust_name end)) Called_Count,
       count(distinct(case when called_date is null then cust_name end)) Calling_pending,
       count(distinct(case when monthly_paid_status = 'PAID' then cust_name end)) EMI_paid_count,
       count(distinct(case when monthly_paid_status = 'NOT PAID' then cust_name end)) EMI_pending_count
  from tab_newngl_call_rpt
 where trunc(emi_date) = trunc(sysdate + 1)
   and calling_or_visiting = 'VISITING'
   and loan_overdue > 0
 group by Branch_name, assigned_employee""",con=conn)

print("df4 completed---------------------------------------------------")

df5=pd.read_sql("""select assigned_employee,
       Branch_name,
       count(distinct(loan_id)) Assigned_count,
       count(distinct(case when called_date is not null then cust_name end)) Called_Count,
       count(distinct(case when called_date is null then cust_name end)) Calling_pending,
       count(distinct(case when monthly_paid_status = 'PAID' then cust_name end)) EMI_paid_count,
       count(distinct(case when monthly_paid_status = 'NOT PAID' then cust_name end)) EMI_pending_count
  from tab_newngl_call_rpt
 where trunc(emi_date) >= trunc(sysdate, 'mm')
   and trunc(emi_date) <= trunc(sysdate)
   and calling_or_visiting = 'VISITING'
   and loan_overdue > 0
 group by Branch_name, assigned_employee""",con=conn)
print("df5 completed---------------------------------------------------")

df6=pd.read_sql("""select assigned_employee,
       Branch_name,
       count(distinct(loan_id)) Assigned_count,
       count(distinct(case when called_date is not null then cust_name end)) Called_Count,
       count(distinct(case when called_date is null then cust_name end)) Calling_pending,
       count(distinct(case when monthly_paid_status = 'PAID' then cust_name end)) EMI_paid_count,
       count(distinct(case when monthly_paid_status = 'NOT PAID' then cust_name end)) EMI_pending_count
  from tab_newngl_call_rpt
 where trunc(emi_date) >= trunc(sysdate, 'mm')
   and trunc(emi_date) <= last_day(trunc(sysdate))
   and calling_or_visiting = 'VISITING'
   and loan_overdue > 0
 group by Branch_name, assigned_employee""",con=conn)
print("df6 completed---------------------------------------------------")

df7=pd.read_sql("""select branch_name,
       count(distinct(assigned_employee)) Home_Visit_Assigned_Emp_Count,
       count(distinct(case when visited_date is not null then cust_name end)) Total_Home_Visited_Customer_count,
       count(distinct(case when trunc(committed_date_of_payment_vst) = trunc(sysdate) then cust_name end)) 
             Today_Payment_committed_customer_count,
       count(distinct(case when trunc(committed_date_of_payment_vst) = trunc(sysdate) and visited_date = trunc(sysdate) 
             then cust_name end)) Today_Visited_Customer_count_from_committed_customers,
       count(distinct(case when monthly_paid_status = 'PAID' then cust_name end)) 
             EMI_collected_count_from_assigned_customers,
       sum((select mm from (select loan_id,avg(monthly_paid_amount) mm from tab_newngl_call_rpt group by loan_id) ww
             where ww.loan_id = q.loan_id)) EMI_collected_amount_from_assigned_customers
  from tab_newngl_call_rpt q
 where trunc(emi_date) = trunc(sysdate) 
   and calling_or_visiting = 'VISITING'
   and loan_overdue > 0
  group by branch_name""",con=conn)
print("df7 completed---------------------------------------------------")
df8=pd.read_sql("""select Branch_name,
       count(distinct(assigned_employee))  Home_Visit_Assigned_Emp_Count,
       count(distinct(cust_name)) Home_Visit_Assigned_Customer_Count,
       count(distinct(case when visited_date is not null then cust_name end)) Total_Home_Visited_Customer_count,
       count(distinct(case when visited_date is null then cust_name end)) Visiting_Pending_Customer_count,
       count(distinct(case when monthly_paid_status = 'PAID' then cust_name end)) 
             EMI_collected_count_from_assigned_customers,
       sum((select mm from (select loan_id,avg(monthly_paid_amount) mm from tab_newngl_call_rpt group by loan_id) ww 
             where ww.loan_id = q.loan_id)) EMI_collected_amount_from_assigned_customers,
       count(distinct(case when trunc(visited_date) is null then cust_name end)) Zero_Visit_customer_Count,
       count((select dd from(select loan_id,count(visited_date) dd from tab_newngl_call_rpt group by loan_id) ww 
             where dd=1 and ww.loan_id = q.loan_id)) one_Time_Visit_customer_count,
       count((select dd from(select loan_id,count(visited_date) dd from tab_newngl_call_rpt group by loan_id) ww 
             where dd=2 and ww.loan_id = q.loan_id)) two_Time_Visit_customer_count,
       count((select dd from(select loan_id,count(visited_date) dd from tab_newngl_call_rpt group by loan_id) ww 
             where dd=3 and ww.loan_id = q.loan_id)) three_Time_Visit_customer_count,
       count((select dd from(select loan_id,count(visited_date) dd from tab_newngl_call_rpt group by loan_id) ww 
             where dd>3 and ww.loan_id = q.loan_id)) above_three_Time_Visit_customer_count
  from tab_newngl_call_rpt q
 where trunc(emi_date) >= trunc(sysdate, 'mm') 
  and trunc(visited_date) <= trunc(sysdate)
 group by branch_name
""",con=conn)
print("df8 completed---------------------------------------------------")
df9=pd.read_sql("""select Branch_name,
        count(distinct(case when MONTHLY_PAID_STATUS = 'NOT PAID' and trunc(EMI_DATE) < trunc(SYSDATE) then CUST_NAME
                 end)) Overdue_Customer_Count,
        sum(case when monthly_paid_status = 'NOT_PAID' and trunc(EMI_DATE) < trunc(SYSDATE) then (select mm
                 from (select loan_id, avg(EMI_AMOUNT) mm from tab_newngl_call_rpt group by loan_id) ww
                 where ww.loan_id = q.loan_id) end) Overdue_Customer_Amount,
        count(distinct(case when visited_date is not null then cust_name end)) Visited_Customer_count,
        count(distinct(case when CUSTOMER_RESPONSE = 'Ready to pay' then cust_name end)) Ready_to_pay_Count,
        sum(case when CUSTOMER_RESPONSE = 'Ready to pay' then (select mm from (select loan_id, avg(outstanding) mm
                 from tab_newngl_call_rpt group by loan_id) ww where ww.loan_id = q.loan_id) end) Ready_to_pay_loan_balance,
        count(distinct(case when CUSTOMER_RESPONSE = 'Not willing to pay' then cust_name end)) not_willing_to_pay_Count,
        sum(case when CUSTOMER_RESPONSE = 'Not willing to pay' then (select mm from (select loan_id, avg(outstanding) mm
                 from tab_newngl_call_rpt group by loan_id ) ww where ww.loan_id = q.loan_id) end) not_willing_to_pay_loan_balance, 
        count(distinct(case when CUSTOMER_RESPONSE = 'Income loss' then cust_name end)) Income_Loss_Count, 
        sum(case when CUSTOMER_RESPONSE = 'Income loss' then (select mm from (select loan_id, avg(outstanding) mm
                 from tab_newngl_call_rpt group by loan_id) ww where ww.loan_id = q.loan_id) end) Income_Loss_Loan_Balance, 
        count(distinct(case when CUSTOMER_RESPONSE = 'Fraudulent loan' then cust_name end)) Fraudulent_loan_Count, 
        sum(case when CUSTOMER_RESPONSE = 'Fraudulent loan' then (select mm from (select loan_id,avg(outstanding) mm
                 from tab_newngl_call_rpt group by loan_id) ww where ww.loan_id = q.loan_id) end) Fraudulent_loan_balance, 
        count(distinct(case when CUSTOMER_RESPONSE = 'Customer absconding' then cust_name end)) Customer_Absconding_Count, 
        sum(case when CUSTOMER_RESPONSE = 'Customer absconding' then (select mm from (select loan_id, avg(outstanding) mm
                 from tab_newngl_call_rpt group by loan_id) ww where ww.loan_id = q.loan_id) end) Customer_Absconding_loan_balance, 
        count(distinct(case when CUSTOMER_RESPONSE in('Customer not in home','Customer not in office','Shop closed') 
                 then cust_name end)) Customer_not_in_home_office_shop_Count, 
        sum(case when CUSTOMER_RESPONSE in('Customer not in home','Customer not in office','Shop closed') then (select mm
                 from (select loan_id,avg(outstanding) mm from tab_newngl_call_rpt group by loan_id) ww
                 where ww.loan_id = q.loan_id) end) Customer_not_in_home_office_shop_loan_balance, 
        count(distinct(case when CUSTOMER_RESPONSE = 'Shop closed' then cust_name end)) shop_closed_Count, 
        sum(case when CUSTOMER_RESPONSE = 'Shop closed' then (select mm from (select loan_id,avg(outstanding) mm
                 from tab_newngl_call_rpt group by loan_id) ww where ww.loan_id = q.loan_id) end) shop_closed_balance
  from tab_newngl_call_rpt q
 where trunc(emi_date) >= trunc(sysdate, 'mm')
   and trunc(emi_date) <= last_day(trunc(sysdate))
   and calling_or_visiting = 'VISITING'
 group by Branch_name""",con=conn)
print("df9 completed---------------------------------------------------")
df10=pd.read_sql("""select assigned_employee, Branch_name,
       count(distinct(assigned_employee)) Assigned_Emp_Count,
       count(distinct(case when visited_date is not null then cust_name end)) Visited_count,
       count(distinct(case when visited_date is null then cust_name end)) Visiting_pending_count,                              
       count(distinct(case when trunc(committed_date_of_payment_vst) = trunc(sysdate) then cust_name end)) 
             Today_Payment_committed_customer,                
       count(distinct(case when trunc(committed_date_of_payment_vst) = trunc(sysdate) and visited_date = trunc(sysdate) 
             then cust_name end)) Visited_from_today_payment_committed_customers,                      
       count(distinct(case when monthly_paid_status = 'PAID' then cust_name end)) EMI_paid_count, 
       sum((select mm from (select loan_id,avg(monthly_paid_amount) mm from tab_newngl_call_rpt group by loan_id) ww
             where ww.loan_id = q.loan_id)) EMI_paid_amount
  from tab_newngl_call_rpt q 
 where trunc(emi_date) = trunc(sysdate) 
   and calling_or_visiting = 'VISITING'
   and loan_overdue > 0
 group by assigned_employee,branch_name""",con=conn)
print("df10 completed---------------------------------------------------")
df11=pd.read_sql("""select assigned_employee,Branch_name,
       count(distinct(cust_name)) Home_Visit_Assigned_Customer_Count,
       count(distinct(case when visited_date is not null then cust_name end)) Home_Visited_Customer_count,
       count(distinct(case when visited_date is null then assigned_employee end)) 
             Visiting_Pending_assigned_Customer_count,
       count(distinct(case when monthly_paid_status = 'PAID' then cust_name end)) 
             EMI_collected_count_from_assigned_customers,
       sum((select mm from (select loan_id, avg(monthly_paid_amount) mm from tab_newngl_call_rpt group by loan_id) ww 
             where ww.loan_id = q.loan_id)) EMI_collected_amount_from_assigned_customers,
       count(distinct(case when visited_date is null then cust_name end)) Zero_Visit_customer_Count,
       count((select loan_id from (select loan_id, count(visited_date) dd from tab_newngl_call_rpt group by loan_id) ww 
              where dd = 1 and ww.loan_id = q.loan_id)) one_Time_Visit_customer_count,
       count((select loan_id from (select loan_id, count(visited_date) dd from tab_newngl_call_rpt group by loan_id) ww 
              where dd = 2 and ww.loan_id = q.loan_id)) two_Time_Visit_customer_count,
       count((select loan_id from (select loan_id, count(visited_date) dd from tab_newngl_call_rpt group by loan_id) ww 
              where dd = 3 and ww.loan_id = q.loan_id)) three_Time_Visit_customer_count,
       count((select loan_id from (select loan_id, count(visited_date) dd from tab_newngl_call_rpt group by loan_id) ww 
      where dd > 3 and ww.loan_id = q.loan_id)) above_three_Time_Visit_customer_count
  from tab_newngl_call_rpt q
 where trunc(emi_date) >= trunc(sysdate, 'mm')
   and trunc(emi_date) <= trunc(sysdate)
   and calling_or_visiting = 'VISITING'
   and loan_overdue > 0
  group by assigned_employee, Branch_name
""",con=conn)
print("df11 completed---------------------------------------------------")
df12=pd.read_sql("""select assigned_employee,Branch_name,
      count(distinct(case when MONTHLY_PAID_STATUS = 'NOT PAID' and trunc(EMI_DATE)<trunc(sysdate) then cust_name end)) 
            Overdue_Customer_Count,
      sum(case when MONTHLY_PAID_STATUS = 'NOT PAID' and trunc(EMI_DATE) <trunc(SYSDATE) then(select mm from
            (select loan_id, avg(emi_amount) mm from tab_newngl_call_rpt group by loan_id) ww
            where ww.loan_id = q.loan_id) end) Overdue_Customer_Amount,       
      count(distinct(case when visited_date is not null then cust_name end)) Visited_Customer_count,
      count(distinct(case when customer_response = 'Ready to pay' then cust_name end)) Ready_to_pay_count,
      sum(case when customer_response = 'Ready to pay' then (select mm from 
            (select loan_id,avg(outstanding) mm from tab_newngl_call_rpt group by loan_id) ww
            where ww.loan_id = q.loan_id) end ) Ready_to_pay_loan_balance,
      count(distinct(case when customer_response = 'Not willing to pay' then cust_name end)) not_willing_to_pay_count,
      sum(case when customer_response = 'Not willing to pay' then (select mm from 
            (select loan_id, avg(outstanding) mm from tab_newngl_call_rpt group by loan_id) ww
            where ww.loan_id = q.loan_id) end) not_willing_to_pay_loan_balance,
      count(distinct(case when customer_response = 'Income loss' then cust_name end)) Income_loss_count,
      sum(case when customer_response = 'Income loss' then (select mm from (select loan_id,avg(outstanding) mm 
            from tab_newngl_call_rpt group by loan_id) ww where ww.loan_id = q.loan_id) end) Income_loss_loan_balance,
      count(distinct(case when customer_response = 'Fraudulent loan' then cust_name end)) Fraudulent_loan_count,
      sum(case when customer_response = 'Fraudulent loan' then (select mm from (select loan_id,avg(outstanding) mm
            from tab_newngl_call_rpt group by loan_id) ww where ww.loan_id = q.loan_id) end) Fraudulent_loan_balance,
      count(distinct(case when customer_response = 'Customer absconding' then cust_name end)) Customer_Absconding_count,
      sum(case when customer_response = 'Customer absconding' then (select mm from (select loan_id,avg(outstanding) mm 
            from tab_newngl_call_rpt group by loan_id) ww where ww.loan_id = q.loan_id) end) 
            Customer_absconding_loan_balance,
      count(distinct(case when customer_response in ('Customer not in home','Customer not in office','Shop closed') 
            then cust_name end)) Customer_not_in_home_office_shop_count,
      sum(case when customer_response in ('Customer not in home','Customer not in office','Shop closed') then (select mm
            from (select loan_id,avg(outstanding) mm from tab_newngl_call_rpt group by loan_id)ww where 
            ww.loan_id = q.loan_id) end) Customer_not_in_home_office_shop_loan_balance,
      count(distinct(case when customer_response = 'Shop closed' then cust_name end)),
      sum(case when customer_response = 'Shop closed' then (select mm from (select loan_id,avg(outstanding) mm 
            from tab_newngl_call_rpt group by loan_id) ww where ww.loan_id = q.loan_id) end) shop_closed_balance
  from tab_newngl_call_rpt q
 where trunc(visited_date) >= trunc(sysdate, 'mm')
   and trunc(visited_date) <= last_day(trunc(sysdate))
   and calling_or_visiting = 'VISITING'
   and loan_overdue > 0
 group by assigned_employee,branch_name""",con=conn)
print("df12 completed---------------------------------------------------")
df13=pd.read_sql("""select * from branch_mapping
""",con=conn)
print("df13 completed---------------------------------------------------")

df14=pd.read_sql(""" select LOAN_ID,
       CUST_NAME,
       LOAN_AMOUNT,
       OUTSTANDING,
       LOAN_OVERDUE,
       EMI_DATE, 
       EMI_AMOUNT, 
       BRANCH_NAME,
       ASSIGNED_EMPLOYEE,
       MONTHLY_PAID_AMOUNT,
       MONTHLY_PAID_STATUS,
       min(visited_date) as first_visited_date,
       SMA_CATEGORY AS overdue_category,
       case when activity_type = 2 and CALLING_OR_VISITING = 'VISITING' then 'Home Visit'
            when activity_type = 3 and CALLING_OR_VISITING = 'VISITING' then 'Shop Visit'
       end as Home_visit_Shop_Visit,
       count(visited_date) as Number_of_times_visited_in_this_month,
       max(visited_date) as last_visited_date,
       MEET_PERSON,
       VISITED_RESPONSE customer_response,
       CUSTOMER_RESPONSE customer_response_category,
       COMMITTED_DATE_OF_PAYMENT,
       case
         when activity_type = 2 and activity_type = 3 and open_status = 2 and
              CALLING_OR_VISITING = 'VISITING' then remarks
       end as Reason_for_non_availability,
       case 
         when activity_type = 2 and activity_type = 3 and open_status = 2 and
              CALLING_OR_VISITING = 'VISITING' then closed_days
       end as days,
       CHANGE_ADDRESS,
       CHANGE_PH_NO,
       min(visited_date) as first_visited_date,
       case
         when visited_date = min(visited_date) then
          customer_response
       end first_feedback,
       case
         when VISITED_DATE >
              (select min(VISITED_DATE) from tab_newngl_call_rpt) then
          visited_date
       end second_visited_date,
       case
         when VISITED_DATE >
              (select min(VISITED_DATE) from tab_newngl_call_rpt) then
          VISITED_RESPONSE
       end second_feedback,
       case
         when visited_date >
              (select min(visited_date)
                 from tab_newngl_call_rpt
                where visited_date >
                      (select min(visited_date) from tab_newngl_call_rpt)) then
          visited_date
       end third_visited_date,
       case
         when visited_date >
              (select min(visited_date)
                 from tab_newngl_call_rpt
                where visited_date >
                      (select min(visited_date) from tab_newngl_call_rpt)) then
          VISITED_RESPONSE
       end third_feedback
  from tab_newngl_call_rpt q
 group by LOAN_ID,
          CUST_NAME,
          LOAN_AMOUNT,
          OUTSTANDING,
          LOAN_OVERDUE,
          EMI_DATE,
          EMI_AMOUNT,
          BRANCH_NAME,
          ASSIGNED_EMPLOYEE,
          MONTHLY_PAID_AMOUNT,
          MONTHLY_PAID_STATUS,
          SMA_CATEGORY,
          case
            when activity_type = 2 and CALLING_OR_VISITING = 'VISITING' then
             'Home Visit'
            when activity_type = 3 and CALLING_OR_VISITING = 'VISITING' then
             'Shop Visit'
          end,
          MEET_PERSON,
          VISITED_RESPONSE,
          CUSTOMER_RESPONSE,
          COMMITTED_DATE_OF_PAYMENT,
          VISITED_DATE,
          activity_type,
          open_status,
          remarks,
          CALLING_OR_VISITING,
          closed_days,
          CHANGE_ADDRESS,
          CHANGE_PH_NO""",con=conn)
print("df14 completed---------------------------------------------------")
df15=pd.read_sql(""" select LOAN_ID,
       CUST_NAME,
       LOAN_AMOUNT,
       OUTSTANDING,
       LOAN_OVERDUE,
       EMI_DATE,
       EMI_AMOUNT,
       BRANCH_NAME, 
       ASSIGNED_EMPLOYEE,
       MONTHLY_PAID_AMOUNT,
       MONTHLY_PAID_STATUS,
       case when called_date is null then 'PENDING' else 'CALLED' end as CALLED_STATUS,
       CALLED_DATE,
       case when call_status = 1 then 'Attended'
            when call_status = 2 then 'Not attended'
            when call_status = 3 then 'Not rechable'
            when call_status = 4 then 'Switch off'
            when call_status = 5 then 'Wrong number'
       end attended_status,
       case when call_status = 1 then 'Attended'
            when call_status = 2 then 'Not attended'
            when call_status = 3 then 'Not rechable'
            when call_status = 4 then 'Switch off'
            when call_status = 5 then 'Wrong number' 
       end CALLING_RESPONSE,
       COMMITTED_DATE_OF_PAYMENT,
       CUSTOMER_RESPONSE customer_response_category,
       count(called_date) as called_count,
       min(called_date) as first_called_date,
       case
         when called_date = min(called_date) then
          CUSTOMER_RESPONSE
       end first_feedback,
       case
         when called_date >
              (select min(called_date) from tab_newngl_call_rpt) then
          called_date
       end second_called_date,
       case
         when called_date >
              (select min(called_date) from tab_newngl_call_rpt) then
          CUSTOMER_RESPONSE
       end second_feedback,
       case
         when called_date >
              (select min(called_date)
                 from tab_newngl_call_rpt
                where called_date >
                      (select min(called_date) from tab_newngl_call_rpt)) then
          called_date
       end third_visited_date,
       case
         when called_date >
              (select min(called_date)
                 from tab_newngl_call_rpt
                where called_date >
                      (select min(called_date) from tab_newngl_call_rpt)) then
          CUSTOMER_RESPONSE
       end third_feedback  
FROM tab_newngl_call_rpt
where calling_or_visiting = 'CALLING'
group by LOAN_ID,
         CUST_NAME,
         LOAN_AMOUNT,
         OUTSTANDING,
         LOAN_OVERDUE,
         EMI_DATE,
         EMI_AMOUNT,
         BRANCH_NAME, 
         ASSIGNED_EMPLOYEE,
         MONTHLY_PAID_AMOUNT,
         MONTHLY_PAID_STATUS,
         called_date,
         call_status,
         COMMITTED_DATE_OF_PAYMENT,
         CUSTOMER_RESPONSE""",con=conn)
print("Query section completed...........")


writer=pd.ExcelWriter("D:\\CRF\\Modification_in_collectioncustomer_ESSAPP_126094\\collection_report.xlsx",engine="openpyxl")
df1.to_excel(writer, sheet_name="Today Calling Report", index=False)
df2.to_excel(writer, sheet_name="MTD Calling Report", index=False)
df3.to_excel(writer,sheet_name="Monthly Calling Report",index=False)
df4.to_excel(writer,sheet_name="tomorrow So calling Dashboard",index=False)
df5.to_excel(writer,sheet_name="MTD So calling Dashboard",index=False)
df6.to_excel(writer,sheet_name="Monthly So calling Dashboard",index=False)
df7.to_excel(writer,sheet_name="Today home visit Summary",index=False)
df8.to_excel(writer,sheet_name="Monthly home visit Summary",index=False)
df9.to_excel(writer,sheet_name="Monthly feedback Summary",index=False)
df10.to_excel(writer,sheet_name="Today Overdue Summary",index=False)
df11.to_excel(writer,sheet_name="Monthly Overdue Summary",index=False)
df12.to_excel(writer,sheet_name="SO wise Monthly Summary",index=False)
df14.to_excel(writer,sheet_name="HOME VISIT DATA",index=False)
df15.to_excel(writer,sheet_name="CALLING DATA",index=False)


# df13.to_excel(writer,sheet_name="Report",index=False)





print("saved as excel")
writer.save()

# Load the Excel file
file_path = r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report.xlsx" 
 # Replace with your file path

# Read all sheets into a dictionary of DataFrames
sheets = pd.read_excel(file_path, sheet_name=None)

# Create a writer object to save the updated sheets
with pd.ExcelWriter('D:\\CRF\\Modification_in_collectioncustomer_ESSAPP_126094\\collection_report.xlsx') as writer:  # Replace with your desired output file name
    # Assuming 'sheets' is a dictionary of DataFrames
    for sheet_name, df in sheets.items():
        # Write the DataFrame back to the Excel file without any modifications
        df.to_excel(writer, sheet_name=sheet_name, index=False)

print("Sheets saved successfully!")

# Append the 'Report' sheet to the Excel file
writer1 = pd.ExcelWriter("D:\\CRF\\Modification_in_collectioncustomer_ESSAPP_126094\\collection_report.xlsx", engine="openpyxl", mode='a')
df13.to_excel(writer1, sheet_name="Report", index=False)
writer1.save()
print("Report Excel Added!!!!!!!!")
print("Excel downloading section completed............")#---------------------------------BRANCH CALLING-------------------------------
# --------------------------------Yesterday------------------------------------

workbook = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\blank.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING','HOME VISIT DATA','CALLING DATA']
for sheet_name in sheet_names:
    if sheet_name == 'BRANCH CALLING':
        sheet = workbook[sheet_name]
        merge_range6 = f"A1:F1"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=1, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=1, column=1)
        merged_cell6.value = "Today Calling Report"
        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 6):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        
workbook.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")


source_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['Today Calling Report']
dest_sheet = dest_wb['BRANCH CALLING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# -------------------------------MTD--------------

workbook = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING','HOME VISIT DATA','CALLING DATA']
for sheet_name in sheet_names:
    if sheet_name == 'BRANCH CALLING':
        sheet = workbook[sheet_name]
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
        merge_range6 = f"A{total_row_number+2}:F{total_row_number+2}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cell6.value = "MTD Calling Report"
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 6):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
workbook.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
source_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['MTD Calling Report']
dest_sheet = dest_wb['BRANCH CALLING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# -------------------------------Monthly--------------

workbook = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING','HOME VISIT DATA','CALLING DATA']
for sheet_name in sheet_names:
    if sheet_name == 'BRANCH CALLING':
        sheet = workbook[sheet_name]
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
        merge_range6 = f"A{total_row_number+2}:F{total_row_number+2}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cell6.value = "Monthly Calling Report"
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 6):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
workbook.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
source_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['Monthly Calling Report']
dest_sheet = dest_wb['BRANCH CALLING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

#-------------------------------BRANCH CALLING--completed----------------------------------



#--------------------------------BRANCH VISITING----------------------------
# ---------------------------BV_Yesterday--------------------------------

workbook = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING','HOME VISIT DATA','CALLING DATA']
for sheet_name in sheet_names:
    if sheet_name == 'BRANCH VISITING':
        sheet = workbook[sheet_name]
        merge_range6 = f"A1:G1"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=1, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=1, column=1)
        merged_cell6.value = "tomorrow So calling Dashboard"
        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 8):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        
workbook.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")


source_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['tomorrow So calling Dashboard']
dest_sheet = dest_wb['BRANCH VISITING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# -------------------------------BV_MTD--------------

workbook = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING','HOME VISIT DATA','CALLING DATA']
for sheet_name in sheet_names:
    if sheet_name == 'BRANCH VISITING':
        sheet = workbook[sheet_name]
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
        merge_range6 = f"A{total_row_number+2}:G{total_row_number+2}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cell6.value = "MTD So calling Dashboard"
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 8):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
workbook.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
source_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['MTD So calling Dashboard']
dest_sheet = dest_wb['BRANCH VISITING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# -------------------------------BV_Monthly--------------

workbook = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING','HOME VISIT DATA','CALLING DATA']
for sheet_name in sheet_names:
    if sheet_name == 'BRANCH VISITING':
        sheet = workbook[sheet_name]
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
        merge_range6 = f"A{total_row_number+2}:G{total_row_number+2}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cell6.value = "Monthly So calling Dashboard"
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 8):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
workbook.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
source_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['Monthly So calling Dashboard']
dest_sheet = dest_wb['BRANCH VISITING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")





#---------------------------------SO CALLING-----------------------------
# ---------------------------SO_C_Yesterday--------------

workbook = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING','HOME VISIT DATA','CALLING DATA']
for sheet_name in sheet_names:
    if sheet_name == 'SO CALLING':
        sheet = workbook[sheet_name]
        merge_range6 = f"A1:F1"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=1, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=1, column=1)
        merged_cell6.value = "Today home visit Summary"
        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 6):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        
workbook.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")


source_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['Today home visit Summary']
dest_sheet = dest_wb['SO CALLING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# -------------------------------SO_MTD--------------

workbook = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING','HOME VISIT DATA','CALLING DATA']
for sheet_name in sheet_names:
    if sheet_name == 'SO CALLING':
        sheet = workbook[sheet_name]
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
        merge_range6 = f"A{total_row_number+2}:F{total_row_number+2}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cell6.value = "Monthly home visit Summary"
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 6):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
workbook.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
source_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['Monthly home visit Summary']
dest_sheet = dest_wb['SO CALLING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# -------------------------------SO_Monthly------------

workbook = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING','HOME VISIT DATA','CALLING DATA']
for sheet_name in sheet_names:
    if sheet_name == 'SO CALLING':
        sheet = workbook[sheet_name]
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
        merge_range6 = f"A{total_row_number+2}:F{total_row_number+2}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cell6.value = "Monthly feedback Summary"
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 6):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
workbook.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
source_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['Monthly feedback Summary']
dest_sheet = dest_wb['SO CALLING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")



#--------------------------------SO VISITING----------------------------
# --------------------------SO_V_Yesterday-------------

workbook = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING','HOME VISIT DATA','CALLING DATA']
for sheet_name in sheet_names:
    if sheet_name == 'SO VISITING':
        sheet = workbook[sheet_name]
        merge_range6 = f"A1:F1"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=1, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=1, column=1)
        merged_cell6.value = "Today Overdue Summary"
        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 7):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        
workbook.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")


source_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['Today Overdue Summary']
dest_sheet = dest_wb['SO VISITING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# -------------------------------SO_V_MTD-------------

workbook = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING','HOME VISIT DATA','CALLING DATA']
for sheet_name in sheet_names:
    if sheet_name == 'SO VISITING':
        sheet = workbook[sheet_name]
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
        merge_range6 = f"A{total_row_number+2}:F{total_row_number+2}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cell6.value = "Monthly Overdue Summary"
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 7):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
workbook.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
source_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['Monthly Overdue Summary']
dest_sheet = dest_wb['SO VISITING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# -------------------------------SO_V_Monthly--------------

workbook = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING','SO CALLING','BRANCH VISITING','SO VISITING','HOME VISIT DATA','CALLING DATA']
for sheet_name in sheet_names:
    if sheet_name == 'SO VISITING':
        sheet = workbook[sheet_name]
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
        merge_range6 = f"A{total_row_number+2}:F{total_row_number+2}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cell6.value = "SO wise Monthly Summary"
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
        # font = Font(color="000000", bold=True)  # Set the font color to white
        # merged_cells6.font = font
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 7):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
workbook.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
source_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['SO wise Monthly Summary']
dest_sheet = dest_wb['SO VISITING']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")


#--------------------------------Report---------------------------------------

source_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['Report']
dest_sheet = dest_wb['REPORT']

# Copy the data from the source sheet
for row in source_sheet.iter_rows(values_only=True):
    dest_sheet.append(row)

dest_wb.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# Load your workbook and sheets
workbook = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING', 'SO CALLING', 'BRANCH VISITING', 'SO VISITING', 'REPORT', 'HOME VISIT DATA', 'CALLING DATA']

for sheet_name in sheet_names:
    if sheet_name == 'REPORT':
        sheet = workbook[sheet_name]

        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                cell.fill = PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")

        # Adjust column widths
        for column in sheet.columns:
            non_empty_values = [cell.value for cell in column if cell.value]
            if non_empty_values:
                max_length = max(len(str(value)) for value in non_empty_values)
                column_letter = get_column_letter(column[0].column)
                adjusted_width = (max_length + 2) * 1.1
                sheet.column_dimensions[column_letter].width = adjusted_width

workbook.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")#------------------------------------------------------------------------------------

# Load the workbooks

# Load your workbook and sheets
workbook = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
source_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report.xlsx")

border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))

sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING', 'SO CALLING', 'BRANCH VISITING', 'SO VISITING', 'HOME VISIT DATA', 'CALLING DATA']

for sheet_name in sheet_names:
    if sheet_name == 'HOME VISIT DATA':
        sheet = workbook[sheet_name]
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
        total_row_number = 30  # Example row number
        start_col = 1  # Column A
        end_col = 30  # Column AD (30th column)

        start_col_letter = get_column_letter(start_col)
        end_col_letter = get_column_letter(end_col)

        merge_range6 = f"{start_col_letter}{total_row_number+2}:{end_col_letter}{total_row_number+2}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cells6.alignment = Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cell6.value = "HOME VISIT DATA"
        # Add heading color
        heading_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
                cell.fill = heading_fill

        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 31):  # Specify the range of columns (A to AD)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")

# Get the source and destination sheets
source_sheet = source_wb['HOME VISIT DATA']
dest_sheet = workbook['HOME VISIT DATA']

# Copy the data from the source sheet including headers
for row_idx, row in enumerate(source_sheet.iter_rows(values_only=True), start=1):
    for col_idx, value in enumerate(row, start=1):
        cell = dest_sheet.cell(row=row_idx, column=col_idx)
        if not isinstance(cell, openpyxl.cell.cell.MergedCell):
            cell.value = value

# Add color to all headings (first row)
heading_fill_all = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
for cell in dest_sheet[1]:
    cell.fill = heading_fill_all

workbook.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
#----------------------------------------------------------------------------------

# Load your workbook and sheets
workbook = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
sheet_names = workbook.sheetnames
sh_names1 = ['BRANCH CALLING', 'SO CALLING', 'BRANCH VISITING', 'SO VISITING', 'HOME VISIT DATA', 'CALLING DATA']

for sheet_name in sheet_names:
    if sheet_name == 'CALLING DATA':
        sheet = workbook[sheet_name]
        total_row_number = None

        rows = list(sheet.iter_rows())

        # Iterate through the rows in reverse order
        for row in reversed(rows):
            # Check if any cell in the row has a value
            if any(cell.value is not None for cell in row):
                total_row_number = row[0].row  # Get the row number of the first cell in the row
                break
        total_row_number = 24  # Example row number
        start_col = 1  # Column A
        end_col = 24  # Column AF (32nd column)

        start_col_letter = get_column_letter(start_col)
        end_col_letter = get_column_letter(end_col)

        merge_range6 = f"{start_col_letter}{total_row_number+2}:{end_col_letter}{total_row_number+2}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+2, column=1)
        merged_cell6.value = "CALLING DATA"
        
        # Add heading color
        heading_fill = PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
                cell.fill = heading_fill

        for row in sheet.iter_rows(min_row=total_row_number+2, max_row=total_row_number+2):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 31):  # Specify the range of columns (A to AD)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")

workbook.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

source_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report.xlsx")
dest_wb = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# Get the source and destination sheets
source_sheet = source_wb['CALLING DATA']
dest_sheet = dest_wb['CALLING DATA']

# Copy the data from the source sheet including headers
for row_idx, row in enumerate(source_sheet.iter_rows(values_only=True), start=1):
    for col_idx, value in enumerate(row, start=1):
        cell = dest_sheet.cell(row=row_idx, column=col_idx)
        if not isinstance(cell, openpyxl.cell.cell.MergedCell):
            cell.value = value

dest_wb.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

#---------------------completed-----------------------------------------------------

workbook = load_workbook(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")
for sheet_name in sheet_names:
    if sheet_name in sh_names1:
        sheet = workbook[sheet_name]
        
        # Add heading color to all headings (first row)
        heading_fill_all = PatternFill(start_color="86abc2", end_color="86abc2", fill_type="solid")
        for cell in sheet[1]:
            cell.fill = heading_fill_all
        
        for column in sheet.columns:
            non_empty_values = [cell.value for cell in column if cell.value]
            if non_empty_values:
                max_length = max(len(str(value)) for value in non_empty_values)
                column_letter = get_column_letter(column[0].column)
                adjusted_width = (max_length + 2) * 1.1
                sheet.column_dimensions[column_letter].width = adjusted_width
        
        for row in sheet.iter_rows():
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
        
        for row in sheet.iter_rows():
            for cell in row:
                cell.border = border_style

workbook.save(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx")

# Define your queries with their titles
# queries = {
#     "Branch calling - Yesterday": """SELECT branch_name, sum(billing_count) billing_count, sum(called_count) called_count,
#                                  sum(calling_pending) calling_pending, sum(emi_paid_count) emi_paid_count,
#                                  sum(emi_pending_count) emi_pending_count FROM tab_newngl_yd_call GROUP BY branch_name""",
#     "Branch calling-MTD": """select branch_name,sum(billing_count) billing_count,sum(called_count)called_count,
#                                     sum(calling_pending)calling_pending,sum(emi_paid_count)emi_paid_count,sum(emi_pending_count)emi_pending_count
#                                     from tab_newngl_mtd_call group by branch_name""",
#     "Branch calling-Monthly": """select branch_name,sum(billing_count) billing_count,sum(called_count)called_count,
#                                     sum(calling_pending)calling_pending,sum(emi_paid_count)emi_paid_count,sum(emi_pending_count)emi_pending_count
#                                     from tab_newngl_Mtly_call group by branch_name""",

    
#     # Add more queries with descriptive titles as needed
#     "Branch Visiting-Yesterday": """select branch_name,count(distinct(emp_name))Assigned_Emp_Count,sum(billing_count) billing_count,sum(visited_customer_count)Visited_Customer_count,
#                                         sum(Visiting_Pending_Count)Visiting_Pending_Count,sum(Paid_Customer_Count)Paid_Customer_Count,sum(Payment_pending_count)Payment_pending_count
#                                         from tab_newngl_yd_Vst where emp_name is not null group by branch_name""",
#     "Branch Visiting-MTD": """select branch_name,count(distinct(emp_name))Assigned_Emp_Count,sum(billing_count) billing_count,sum(visited_customer_count)Visited_Customer_count,
#                                         sum(Visiting_Pending_Count)Visiting_Pending_Count,sum(Paid_Customer_Count)Paid_Customer_Count,sum(Payment_pending_count)Payment_pending_count
#                                         from tab_newngl_mtd_vst where emp_name is not null group by branch_name""",
#     "Branch Visiting-Monthly": """select branch_name,count(distinct(emp_name))Assigned_Emp_Count,sum(billing_count) billing_count,sum(visited_customer_count)Visited_Customer_count,
#                                         sum(Visiting_Pending_Count)Visiting_Pending_Count,sum(Paid_Customer_Count)Paid_Customer_Count,sum(Payment_pending_count)Payment_pending_count
#                                         from tab_newngl_Mtly_vst where emp_name is not null group by branch_name""",
# }

# Initialize the HTML content for email body
html_content = """
<html>
    <body>
        <p>Dear sir,<br><br>Kindly find the reports below.</p>
"""

# Execute each query, convert to DataFrame, and add to email body as HTML table with a heading
# for report_title, sql in queries.items():
#     cursor = conn.cursor()
#     cursor.execute(sql)
#     records = cursor.fetchall()
#     columns = [desc[0] for desc in cursor.description]
   
#     # Create DataFrame and convert to HTML
#     df = pd.DataFrame(records, columns=columns)
#     html_table = df.to_html(index=False, float_format='{:,.2f}'.format)
   
    # Append heading and table to email content
    # html_content += f"<h3>{report_title}</h3>{html_table}<br><br>"

# Close the HTML content for email
html_content += """
        <p>Thanks & Regards,<br>
           R & D New age technology<br>
           (This is an autogenerated mail)</p>
    </body>
</html>
"""

# Setup SMTP server
s = smtplib.SMTP(host='smtp.office365.com', port=587)
s.starttls()
s.login('iotautomation@manappuram.com', '')

# Create the multipart email
msg = MIMEMultipart("mixed")
msg['Subject'] = f"Collection follow up through ESS Report {datetime.now().strftime('%H:%M:%S')}"
msg['From'] = 'iot <iotautomation@manappuram.com>'
msg['To'] = 'sudeep kv <ssifhead@manappuram.com>'
msg['Cc'] = 'sravan<iotsupport12@manappuram.com>,anjana mohanan<dataservice27@manappuram.com>'

# Attach Excel file
with open(r"D:\CRF\Modification_in_collectioncustomer_ESSAPP_126094\collection_report_final.xlsx", 'rb') as ra:
    attachment = MIMEApplication(ra.read(), _subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    attachment.add_header('Content-Disposition', 'attachment', filename='collection_report_final.xlsx')
    msg.attach(attachment)

# Add HTML body with all tables and headings
msg.attach(MIMEText(html_content, "html"))
# with open(r"D:\\CRF\\crf10\\119339-CRF_FOR_SHOP_VISIT_REPORT_AUTOMATION\\Shopvisit_report1.png", 'rb') as img:
#     maintype, subtype = mimetypes.guess_type(img.name)[0].split('/')
#     msg.get_payload()[1].add_related(img.read(),
#                                         maintype=maintype,
#                                         subtype=subtype,
#                                         cid=image_cid)

s.send_message(msg)
print("Mail send")
print("final section completed sucessfully.............")
# os.remove(r"D:\\CRF\\crf10\\119339-CRF_FOR_SHOP_VISIT_REPORT_AUTOMATION\\Shopvisit_report1.png")
# print("Image removed")

