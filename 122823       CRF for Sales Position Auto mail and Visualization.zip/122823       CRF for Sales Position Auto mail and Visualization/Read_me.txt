CRF ID:122823  
CRF NAME:CRF for Sales Position Auto mail and Visualization
USER:MANU 
DIPLOYED IN SERVER:10.0.0.112 
TIME:8.30 AM,7.30 PM
Running code :mail.py