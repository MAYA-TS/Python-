
    
def report_bms():
    from tableau_api_lib import TableauServerConnection
    from tableau_api_lib.utils import querying
    from tableau_api_lib.utils.common import flatten_dict_column
    import pandas as pd
    import xlrd
    from pandas import ExcelWriter
    import openpyxl
    from openpyxl.styles import PatternFill
    tableau_server_config = {
                    'my_env': {
                            'server': 'http://reports.manappuram.com',
                            'api_version': "3.17",
                            'username': 'tableauadministrator',
                            'password': 'M@fil@123',
                            'site_name': 'Default',
                            'site_url': ''
                    }
            }
    conn = TableauServerConnection(tableau_server_config, env='my_env',ssl_verify=False)
    conn.sign_in()
    site_views_df = querying.get_views_dataframe(conn)
    site_views_df
    site_views_detailed_df = flatten_dict_column(site_views_df, keys=['name', 'id'],col_name='workbook')
    relevant_views_df = site_views_detailed_df[site_views_detailed_df['workbook_name'] == "Loan Disbursement Daily Report"]
    relevant_views_df
    BM='521b02cf-00e2-4a25-a0b4-9cff3f0f2557'
    view_data_BM= querying.get_view_data_dataframe(conn,BM)
    print(view_data_BM)
    Q=list(view_data_BM.columns)
    Q
    view_data_BM_a = view_data_BM.pivot(index=('BRANCH_NAME','BM NGL'), columns=['Measure Names'], values='Measure Values')
    print(view_data_BM_a)
    titles=list(view_data_BM_a.columns)
    titles
    new_column_order  =['Daily Target','Today achieved','Today achieved per', 'MTD Target','Mtd Achieved','Mtd Achieved Percentage','MTD Variance', 'Avg. Target','Monthly achieved','Monthly per','Monthly Variance','Count of Loan Count','LOAN_ID','Amount in Cr','AUM in Cr']

    new_column_order 
    view_data_BM_a = view_data_BM_a[new_column_order]
    view_data_BM_a
    view_data_BM_a = view_data_BM_a.apply(lambda x: round(x, 1) if isinstance(x, float) else x)
    view_data_BM_a
    # Sort the DataFrame based on "Avg. Target" column in descending order
    view_data_BM_a_sorted = view_data_BM_a.sort_values(by='Daily Target', ascending=False)

    # Specify the path where you want to save the Excel file
    excel_file_path = 'view_data_BM_sorted.xlsx'

    # Write the sorted DataFrame to an Excel file
    with pd.ExcelWriter(excel_file_path, engine='openpyxl') as writer:
        view_data_BM_a_sorted.to_excel(writer, index=True, sheet_name='BMs')
    
        # Adjust column widths
        worksheet = writer.sheets['BMs']
        for column in worksheet.columns:
            max_length = 0
            column = [cell for cell in column if cell.value is not None]
            if column:
                max_length = max((len(str(cell.value)) for cell in column))
            adjusted_width = (max_length + 2) * 1.2
            worksheet.column_dimensions[column[0].column_letter].width = adjusted_width

    # Print a message indicating that the file has been saved
    print(f"Data sorted by 'Avg. Target' in descending order and saved to '{excel_file_path}'.")
report_bms()
###for rounding the values##############
def round_bms():
    print("round")
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\rounded_data_BM.xlsx')
    import pandas as pd
    df=pd.read_excel('view_data_BM_sorted.xlsx')
    df_rounded=df.round(1)
    df_rounded=df_rounded.fillna(df)
    df_rounded.to_excel('rounded_data_BM.xlsx',index=False)

round_bms()
########### sortin
def sorted_bms():
    import pandas as pd
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\sorted_data_BM.xlsx')

    # Read the Excel file into a pandas DataFrame
    df = pd.read_excel('rounded_data_BM.xlsx')

    # Sort the DataFrame based on the 'Sales Mtd Achieved' column in descending order
    df_sorted = df.sort_values(by='Daily Target', ascending=False)

    # Save the sorted DataFrame back to an Excel file
    df_sorted.to_excel('sorted_data_BM.xlsx', index=False)
sorted_bms()
#############
def rename():
    import pandas as pd
    import os
    import pandas as pd
    import openpyxl
    # os.remove(r'D:\MYCODE\power bi\powerbi\renamedBM_file.xlsx')
    # Read the Excel file
    df = pd.read_excel('sorted_data_BM.xlsx')

    # Rename the column names
    new_column_names = {'Avg. Target': 'Monthly Target',
                    'Monthly achieved': 'Achieved',
                    'Monthly per': 'Achieved %',
                    'Monthly Variance':'Variance',
                   'Count of Loan Count':'Loan count',
                    'LOAN_ID':'Loan Count' ,
                    'LOAN_ID':'YTD Loan count',
                    'Amount':'YTD loan amount',
                    'AUM':'AUM in CR',
                    'Today achieved per':'Today achieved %',
                    'Mtd Achieved Percentage':'Mtd Achieved %'}

    df.rename(columns=new_column_names, inplace=True)
    df.to_excel('renamedBM_file.xlsx',sheet_name='BMS',index=False)
   
rename()
##################SUM
def sum_bms():

    import pandas as pd
    import os

    # Specify the correct file path for the Excel file
    file_path = 'renamedBM_file.xlsx'

    # Read the Excel file into a DataFrame
    df = pd.read_excel(file_path)

    # Convert 'YTD Loan count' column to numeric data type
    df['YTD Loan count'] = pd.to_numeric(df['YTD Loan count'], errors='coerce')

    # Check the data types of the columns
    print(df.dtypes)

    # Select the columns for which you want to calculate the sum
    columns_to_sum = ['Daily Target', 'Today achieved', 'Today achieved %', 'MTD Target', 'Mtd Achieved', 'Mtd Achieved %', 'MTD Variance', 'Monthly Target', 'Achieved', 'Achieved %', 'Variance', 'Loan count', 'YTD Loan count', 'Amount in Cr', 'AUM in Cr']

    # Verify that the column names in columns_to_sum match the DataFrame
    print(set(columns_to_sum) - set(df.columns))

    # Handle missing or invalid values if needed
    df.fillna(0, inplace=True)

    # Calculate the column-wise sum for the selected columns
    column_sums = df[columns_to_sum].sum()

    # Add the column sums as the last row with a name 'Grand Total'
    df.loc['Grand Total'] = column_sums

    # Add a new column 'RANK' with values starting from 1
    df.insert(0, 'RANK', range(1, len(df) + 1))

    # Remove the existing 'sumBM.xlsx' file before writing the new DataFrame to the Excel file
    if os.path.exists('sumBM.xlsx'):
        os.remove('sumBM.xlsx')

    # Write the DataFrame to the Excel file
    df.to_excel(r'D:\MYCODE\power bi\powerbi\OUTPUT\new\sumBM.xlsx',sheet_name='BMS', index=False)


sum_bms()
def report_so():
   
    from tableau_api_lib import TableauServerConnection
    from tableau_api_lib.utils import querying
    from tableau_api_lib.utils.common import flatten_dict_column
    import pandas as pd
    from pandas import ExcelWriter

    tableau_server_config = {
        'my_env': {
            'server': 'http://reports.manappuram.com',
            'api_version': "3.17",
            'username': 'tableauadministrator',
            'password': 'M@fil@123',
            'site_name': 'Default',
            'site_url': ''
        }
    }

    conn = TableauServerConnection(tableau_server_config, env='my_env', ssl_verify=False)
    conn.sign_in()

    site_views_df = querying.get_views_dataframe(conn)
    site_views_detailed_df = flatten_dict_column(site_views_df, keys=['name', 'id'], col_name='workbook')

    relevant_views_df = site_views_detailed_df[site_views_detailed_df['workbook_name'] == "Loan Disbursement Daily Report"]

    SO = '1496205a-5f4a-4626-8060-4295b457b825'
    view_data_SO = querying.get_view_data_dataframe(conn, SO)

    view_data_SO.rename(columns={'HEADING': 'PARTICULARS'}, inplace=True)

    view_data_SO_sorted = view_data_SO.sort_values(by=['Year of PAID_DATE'])

    month_order = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']

    def sort_key(row):
        year = row['Year of PAID_DATE']
        month = row['Month of PAID_DATE']
        return (year, month_order.index(month))

    view_data_SO_sorted['sort_key'] = view_data_SO_sorted.apply(sort_key, axis=1)
    view_data_SO_sorted = view_data_SO_sorted.sort_values(by=['sort_key'])

    view_data_SO_sorted.drop('sort_key', axis=1, inplace=True)
    # view_data_SO_a = view_data_SO_sorted.pivot_table(index=['EXECUTIVE_NAME', 'EXECUTIVE_CODE', 'BRANCH_NAME', 'POST_NAME', 'DESIGNATION', 'Employee_live_status', 'JOIN_DT', 'EXP', 'DISCONT_DT', 'STATE_NAME'],
    #                                                 columns=['Month of PAID_DATE', 'Year of PAID_DATE', 'Measure Names'],
    #                                                 values='Measure Values',
    #                                                 aggfunc='sum')
    # view_data_SO_a = view_data_SO_sorted.pivot(index=['EXECUTIVE_NAME','EXECUTIVE_CODE','BRANCH_NAME','POST_NAME','DESIGNATION','Employee_live_status','JOIN_DT','EXP','DISCONT_DT','STATE_NAME'], columns=['Month of PAID_DATE','Year of PAID_DATE','Measure Names'], values='Measure Values')
    # view_data_SO_a 
    view_data_SO_a = view_data_SO_sorted.pivot(index=['EXECUTIVE_NAME', 'EXECUTIVE_CODE', 'BRANCH_NAME', 'POST_NAME', 'DESIGNATION', 'Employee_live_status','JOIN_DT','EXP','DISCONT_DT', 'STATE_NAME'],
                                            columns=['Month of PAID_DATE', 'Year of PAID_DATE', 'Measure Names'],
                                            values='Measure Values')

    with pd.ExcelWriter('REPORT_SO.xlsx') as writer:
        view_data_SO_a.to_excel(writer, sheet_name='SO')
report_so()
# # ################
def merging_so():
    from openpyxl import load_workbook

# Load the Excel file
    wb = load_workbook('REPORT_SO.xlsx')

    # Access the active worksheet
    ws = wb.active

    # Loop through all cells in the worksheet
    for row in ws.iter_rows():
        for cell in row:
            # Check if the cell contains 'Measure Names' or 'Month of LOAN_DT'
            if cell.value == 'Measure Names' or cell.value == 'Month of PAID_DATE' or cell.value == 'Year of PAID_DATE':
                # Clear the cell content
                cell.value = None

    # Save the modified Excel file
    wb.save(r'D:\MYCODE\power bi\powerbi\OUTPUT\new\Merged_SO.xlsx')


merging_so()
###################BRANCH
def report_BRANCH():
    from tableau_api_lib import TableauServerConnection
    from tableau_api_lib.utils import querying
    from tableau_api_lib.utils.common import flatten_dict_column
    import pandas as pd
    import xlrd
    from pandas import ExcelWriter
    import openpyxl
    from openpyxl.styles import PatternFill
    tableau_server_config = {
                    'my_env': {
                            'server': 'http://reports.manappuram.com',
                            'api_version': "3.17",
                            'username': 'tableauadministrator',
                            'password': 'M@fil@123',
                            'site_name': 'Default',
                            'site_url': ''
                    }
            }
    conn = TableauServerConnection(tableau_server_config, env='my_env',ssl_verify=False)
    conn.sign_in()
    site_views_df = querying.get_views_dataframe(conn)
    site_views_df
    site_views_detailed_df = flatten_dict_column(site_views_df, keys=['name', 'id'],col_name='workbook')
    site_views_detailed_df
    relevant_views_df = site_views_detailed_df[site_views_detailed_df['workbook_name'] == "Loan Disbursement Daily Report"]
    relevant_views_df
    BRANCH='84634fa5-4bc6-4329-8ab7-467f8dd5a0fd'
    view_data_BRANCH= querying.get_view_data_dataframe(conn,BRANCH)
    print(view_data_BRANCH)
    Q=list(view_data_BRANCH.columns)
    Q
    a5=view_data_BRANCH.rename(columns={'HEADING':'PARTICULARS'},inplace=True)
    a5
    view_data_BM_a = view_data_BRANCH.pivot(index=('EXECUTIVE_NAME','EXECUTIVE_CODE','POST_NAME'), columns=['Measure Names'], values='Measure Values')
    print(view_data_BM_a)
    titles=list(view_data_BM_a.columns)
    titles
    # new_column_order  =['Mtd Achieved', 'Avg. Branch Manager Target', 'BRANCH MANAGER VARIANCE', 'BM PER']

    new_column_order  =['Avg. Branch Manager Target', 'Mtd Achieved','BRANCH MANAGER VARIANCE', 'BM PER']
    new_column_order 
    view_data_BM_a = view_data_BM_a[new_column_order]
    view_data_BM_a
    view_data_BM_a = view_data_BM_a[new_column_order]
    view_data_BM_a
    # Sort the DataFrame based on "Avg. Target" column in descending order
    view_data_BM_a_sorted = view_data_BM_a.sort_values(by='Mtd Achieved', ascending=False)

    # Specify the path where you want to save the Excel file
    excel_file_path = 'REPORT_BRANCH.xlsx'

    # Write the sorted DataFrame to an Excel file
    with pd.ExcelWriter(excel_file_path, engine='openpyxl') as writer:
        view_data_BM_a_sorted.to_excel(writer, index=True, sheet_name='BRANCH')
    
        # Adjust column widths
        worksheet = writer.sheets['BRANCH']
        for column in worksheet.columns:
            max_length = 0
            column = [cell for cell in column if cell.value is not None]
            if column:
                max_length = max((len(str(cell.value)) for cell in column))
            adjusted_width = (max_length + 2) * 1.2
            worksheet.column_dimensions[column[0].column_letter].width = adjusted_width

    # Print a message indicating that the file has been saved
    print(f"Data sorted by 'Avg. Target' in descending order and saved to '{excel_file_path}'.")

report_BRANCH()
def rename_BRANCH():
    import pandas as pd
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\renamedBRANCH_file.xlsx')
    # Read the Excel file
    df = pd.read_excel('REPORT_BRANCH.xlsx')

    # Rename the column names
    new_column_names = {'EXECUTIVE_NAME': 'Name',
                    'EXECUTIVE_CODE': 'code',
                    'Avg. Branch Manager Target': 'Target',
                    'Mtd Achieved':' Achieved',
                   'BRANCH MANAGER VARIANCE':'Variance',
                    'BM PER':'Achieved %' ,
                    # 'Avg. Sales Emp Target':'Monthly Target',
                    # 'Sales Emp  Percentage':'Monthly achived %',
                    # # 'AUM':'AUM in CR',
                    # 'Sales emp Variance':'Monthly Variance',
                    # 'LOAN_ID':'Count',





}

    df.rename(columns=new_column_names, inplace=True)

    # Save the modified DataFrame to a new Excel file
    df.to_excel(r'D:\MYCODE\power bi\powerbi\OUTPUT\new\renamedBRANCH_file.xlsx', sheet_name='BRANCH' ,index=False)

rename_BRANCH()
def report_bm():
    from tableau_api_lib import TableauServerConnection
    from tableau_api_lib.utils import querying
    from tableau_api_lib.utils.common import flatten_dict_column
    import pandas as pd
    import xlrd
    from pandas import ExcelWriter
    import openpyxl
    from openpyxl.styles import PatternFill
    tableau_server_config = {
                    'my_env': {
                            'server': 'http://reports.manappuram.com',
                            'api_version': "3.17",
                            'username': 'tableauadministrator',
                            'password': 'M@fil@123',
                            'site_name': 'Default',
                            'site_url': ''
                    }
            }
    conn = TableauServerConnection(tableau_server_config, env='my_env',ssl_verify=False)
    conn.sign_in()
    site_views_df = querying.get_views_dataframe(conn)
    site_views_df
    site_views_detailed_df = flatten_dict_column(site_views_df, keys=['name', 'id'],col_name='workbook')
    site_views_detailed_df
    relevant_views_df = site_views_detailed_df[site_views_detailed_df['workbook_name'] == "Loan Disbursement Daily Report"]
    relevant_views_df
    BM='dea45e4c-930d-4df5-bcc2-26d707f39d2e'
    view_data_BRANCH= querying.get_view_data_dataframe(conn,BM)
    print(view_data_BRANCH)
    Q=list(view_data_BRANCH.columns)
    Q
    a5=view_data_BRANCH.rename(columns={'HEADING':'PARTICULARS'},inplace=True)
    a5
    titles=list(view_data_BRANCH.columns)
    titles
    view_data_BM_a = view_data_BRANCH.pivot(index=['BRANCH_NAME','BM NGL'], columns=['Month of PAID_DATE','Measure Names'], values='Measure Values')
    view_data_BM_a 
    def shift_row_to_bottom(df,index_to_shift):
        idx = [i for i in df.index if i!= index_to_shift]
        return df.loc[idx+[index_to_shift]]
    ist = shift_row_to_bottom(view_data_BM_a,('All','All'))
    ist
    e=ist.rename(index={'All':'Grand Total'})
    e
    excel_file_path = 'Report_bm.xlsx'
    with pd.ExcelWriter(excel_file_path, engine='openpyxl') as writer:
        e.to_excel(writer, sheet_name='bm', index=True)
        worksheet = writer.sheets['bm']

        # Apply color to the first row
        fill = PatternFill(start_color="87CEEB", end_color="87CEEB", fill_type="solid")
        for row in worksheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.fill = fill

        # Adjust column width
        for merged_range in worksheet.merged_cells.ranges:
            min_col, min_row, max_col, max_row = merged_range.bounds
            max_length = max(len(str(cell.value)) for row in worksheet.iter_rows(min_row=min_row, max_row=max_row)
                            for cell in row[min_col - 1:max_col])
            adjusted_width = (max_length + 2) * 1.2  # Adjust multiplier as needed
            column_letter = worksheet.cell(min_row, min_col).column_letter
            worksheet.column_dimensions[column_letter].width = adjusted_width

    print(f"Data has been written to {excel_file_path}")
report_bm()
def removing_bm():
    from openpyxl import load_workbook

    # Load the Excel file
    wb = load_workbook('Report_bm.xlsx')

    # Access the active worksheet
    ws = wb.active

    # Loop through all cells in the worksheet
    for row in ws.iter_rows():
        for cell in row:
            # Check if the cell contains 'Measure Names' or 'Month of PAID_DATE'
            if cell.value == 'Measure Names':
                # Rename 'LOAN_ID' as 'Count'
                cell.value = ' '
            elif cell.value == 'LOAN_AMOUNT':
                # Rename 'LOAN_AMOUNT' as 'Amount'
                cell.value = 'Amount'
            elif cell.value == 'LOAN_ID':  
                 cell.value = 'Count'
            elif cell.value == 'Month of PAID_DATE':
                # Rename 'LOAN_ID' as 'Count'
                cell.value = ' '
    # Set A2 as 'BRANCH_NAME'
    ws['A2'] = 'BRANCH_NAME'
    ws['B2'] ='BM NGL'

    # Remove the A3 row
    ws.delete_rows(3)
    ws['A1'] = 'BRANCH_NAME'
    ws.merge_cells('A1:A2')

    # Save the modified Excel file
    wb.save(r'D:\MYCODE\power bi\powerbi\OUTPUT\new\removed_bm.xlsx')

    # from openpyxl import load_workbook

    # # Load the Excel file
    # wb = load_workbook('Report_bm.xlsx')

    # # Access the active worksheet
    # ws = wb.active

    # # Loop through all cells in the worksheet
    # for row in ws.iter_rows():
    #     for cell in row:
    #         # Check if the cell contains 'Measure Names' or 'Month of LOAN_DT'
    #         if cell.value == 'Measure Names' or cell.value == 'Month of PAID_DATE':
    #             # Clear the cell content
    #             cell.value = None

    # # Set A2 as 'BRANCH_NAME'
    # ws['A2'] = 'BRANCH_NAME'
    # ws['B2'] ='BM NGL'

    # # Remove the A3 row
    # ws.delete_rows(3)
    # ws['A1'] = 'BRANCH_NAME'
    # ws.merge_cells('A1:A2')
    # # Save the modified Excel file
    # wb.save('removed_bm.xlsx')
    # # from openpyxl import load_workbook
removing_bm()

def report_MTD():
    from tableau_api_lib import TableauServerConnection
    from tableau_api_lib.utils import querying
    from tableau_api_lib.utils.common import flatten_dict_column
    import pandas as pd
    import xlrd
    from pandas import ExcelWriter
    import openpyxl
    from openpyxl.styles import PatternFill
    tableau_server_config = {
                    'my_env': {
                            'server': 'http://reports.manappuram.com',
                            'api_version': "3.17",
                            'username': 'tableauadministrator',
                            'password': 'M@fil@123',
                            'site_name': 'Default',
                            'site_url': ''
                    }
            }
    conn = TableauServerConnection(tableau_server_config, env='my_env',ssl_verify=False)
    conn.sign_in()
    site_views_df = querying.get_views_dataframe(conn)
    site_views_df
    site_views_detailed_df = flatten_dict_column(site_views_df, keys=['name', 'id'],col_name='workbook')
    site_views_detailed_df
    relevant_views_df = site_views_detailed_df[site_views_detailed_df['workbook_name'] == "Loan Disbursement Daily Report"]
    relevant_views_df
    MTD='f1cd089d-cd78-4188-ba9c-3f0e14b87f63'
    view_data_MTD= querying.get_view_data_dataframe(conn,MTD)
    print(view_data_MTD)
    Q=list(view_data_MTD.columns)
    Q
    a5=view_data_MTD.rename(columns={'HEADING':'PARTICULARS'},inplace=True)
    a5
    titles=list(view_data_MTD.columns)
    titles
    view_data_MTD_a = view_data_MTD.pivot(index=('EXECUTIVE_NAME','EXECUTIVE_CODE','BRANCH_NAME'), columns=['Measure Names'], values='Measure Values')
    print(view_data_MTD_a)
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\REPORT_MTD.xlsx')

    writer = pd.ExcelWriter('REPORT_MTD.xlsx', engine="openpyxl")
            
    view_data_MTD_a.to_excel(writer,sheet_name="MTD", index=True)
    for sheet_name, df in zip(["MTD"], [view_data_MTD_a]):
        worksheet = writer.book[sheet_name]
        
        # Apply color to the first row
        fill = PatternFill(start_color="87CEEB", end_color="87CEEB", fill_type="solid")
        for col in worksheet.iter_cols(min_row=1, max_row=1):
                for cell in col:
                 cell.fill = fill
        
        # Adjust column width
        for col in worksheet.columns:
            max_length = 0
            column = col[0].column_letter  # Get the column name
            for cell in col:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = (max_length + 2) * 1.2  # Adjust multiplier as needed
            worksheet.column_dimensions[column].width = adjusted_width



    writer.close()
report_MTD()
def round_MTD():
    # print("round")
    # import pandas as pd
    # import os
    # # os.remove(r'D:\MYCODE\power bi\powerbi\rounded_data_MTD.xlsx')

    # df=pd.read_excel('REPORT_MTD.xlsx')
    # df_rounded=df.round(2)
    # df_rounded=df_rounded.fillna(df)
    # df_rounded.to_excel('rounded_data_MTD.xlsx',index=False)
    import pandas as pd
    import os

    # os.remove(r'D:\MYCODE\power bi\powerbi\rounded_data_MTD.xlsx')

    df = pd.read_excel('REPORT_MTD.xlsx')

    print(df.columns)
    # df['Sales Emp  Percentage'] = df['Sales Emp  Percentage'].round(2) * 100
    # df.to_excel('rounded_data_MTD.xlsx', index=False)

    # Check if the specified column names exist in the DataFrame
    if 'Sales Emp  Percentage' in df.columns:
        # Round columns Sales Emp MTD per, Sales Emp Percentage to 2 decimal places and multiply by 100
        df['Sales Emp  Percentage'] = df['Sales Emp  Percentage'].round(2) * 100
        df.to_excel('rounded_data_MTD.xlsx', index=False)
    if 'Sales Emp MTD per' in df.columns:
        df['Sales Emp MTD per'] = df['Sales Emp MTD per'].round(2) * 100
        df.to_excel('rounded_data_MTD.xlsx', index=False)
    # Round other columns to 1 decimal place

    y = ['Amount in Cr','Aum in lakhs','Mtd Achieved','Sales Emp Daily Target','Sales Emp MTD Target','Sales Emp MTD Variance','Sales Mtd Achieved','Sales emp Variance','Today achieved']
    for i in y:
        if i in df.columns:
            df_rounded = df.round(1)

            # Fill NaN values with original values
            df_rounded = df_rounded.fillna(df)

            # Save the rounded data to a new Excel file
            df_rounded.to_excel('rounded_data_MTD.xlsx', index=False)

round_MTD()
def order_MTD():
    import pandas as pd
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\Ordered_MTD.xlsx')

    # Read the Excel file
    excel_file_path = 'rounded_data_MTD.xlsx'
    df = pd.read_excel(excel_file_path)

    # Define the desired order of columns
    desired_order = ['EXECUTIVE_NAME','EXECUTIVE_CODE','BRANCH_NAME','Sales Emp Daily Target', 'Today achieved', 'Sales Emp MTD Target','Sales Mtd Achieved', 'Sales Emp MTD Variance','Sales Emp MTD per','Avg. Sales Emp Target','Mtd Achieved','Sales Emp  Percentage','Count of Loan Count','Sales emp Variance','LOAN_ID','Amount in Cr','Aum in lakhs']

    # Reorder the columns
    df = df[desired_order]

    # Save the modified DataFrame back to Excel
    output_file_path = 'Ordered_MTD.xlsx'
    df.to_excel(output_file_path, index=False)

    print('Columns reordered and saved to', output_file_path)
order_MTD()
def rename_MTD():
    import pandas as pd
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\renamedMTD_file.xlsx')
    # Read the Excel file
    df = pd.read_excel('Ordered_MTD.xlsx')

    # Rename the column names
    new_column_names = {'EXECUTIVE_NAME': 'NAME',
                    'EXECUTIVE_CODE': 'Employee Code',
                    'Sales Emp Daily Target': 'Daily Target',
                    'Today achieved':'Achieved',
                   'Sales Emp MTD Target':'MTD Target',
                    'Sales Mtd Achieved':'MTD Achieved' ,
                    'Sales Emp MTD Variance':'Variance',
                    'Sales Emp MTD per':'MTD %',
                    'Avg. Sales Emp Target':'Monthly Target',
                    'Mtd Achieved':'Achieved',
                    'Sales Emp  Percentage':'Achieved %',
                    'Sales Emp  Percentage':'Achieved %',
                    'Count of Loan Count':'Loan count',
                    'Sales emp Variance':'Variance',
                    'LOAN_ID':'Loan Count'







}

    df.rename(columns=new_column_names, inplace=True)

    # Save the modified DataFrame to a new Excel file
    df.to_excel('renamedMTD_file.xlsx', index=False)
rename_MTD()

def sorted_MTD():
    import pandas as pd
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\sorted_data_MTD.xlsx')

    # Read the Excel file into a pandas DataFrame
    df = pd.read_excel('renamedMTD_file.xlsx')

    # Sort the DataFrame based on the 'Sales Mtd Achieved' column in descending order
    df_sorted = df.sort_values(by='MTD Achieved', ascending=False)

    # Save the sorted DataFrame back to an Excel file
    df_sorted.to_excel(r'D:\MYCODE\power bi\powerbi\OUTPUT\new\sorted_data_MTD.xlsx',sheet_name='MTD' ,index=False)
sorted_MTD()
def report_daywise():
        from tableau_api_lib import TableauServerConnection
        from tableau_api_lib.utils import querying
        from tableau_api_lib.utils.common import flatten_dict_column
        import pandas as pd
        import xlrd
        from pandas import ExcelWriter
        import openpyxl
        from openpyxl.styles import PatternFill
        tableau_server_config = {
                        'my_env': {
                                'server': 'http://reports.manappuram.com',
                                'api_version': "3.17",
                                'username': 'tableauadministrator',
                                'password': 'M@fil@123',
                                'site_name': 'Default',
                                'site_url': ''
                        }
                }
        conn = TableauServerConnection(tableau_server_config, env='my_env',ssl_verify=False)
        conn.sign_in()
        site_views_df = querying.get_views_dataframe(conn)
        site_views_df
        site_views_detailed_df = flatten_dict_column(site_views_df, keys=['name', 'id'],col_name='workbook')
        site_views_detailed_df
        relevant_views_df = site_views_detailed_df[site_views_detailed_df['workbook_name'] == "Loan Disbursement Daily Report"]
        relevant_views_df
        day_wise='95acce13-582c-4ecb-93bd-309a8758f75c'
        view_data_day_wise= querying.get_view_data_dataframe(conn,day_wise)
        print(view_data_day_wise)
        Q=list(view_data_day_wise.columns)
        Q
        a5=view_data_day_wise.rename(columns={'HEADING':'PARTICULARS'},inplace=True)
        a5
        view_data_day_wise_a = view_data_day_wise.pivot(index=['BRANCH_NAME','EXECUTIVE_NAME'], columns=['Day of PAID_DATE','Measure Names'], values='Measure Values')
        view_data_day_wise_a 
        def shift_row_to_bottom(df,index_to_shift):
          idx = [i for i in df.index if i!= index_to_shift]
          return df.loc[idx+[index_to_shift]]
        ist = shift_row_to_bottom(view_data_day_wise_a,('All','All'))
        ist
        view_data_day_wise_a = ist.rename(index={'All': 'Grand Total'})
        view_data_day_wise_a

        excel_file_path = 'report_daywise.xlsx'
        with pd.ExcelWriter(excel_file_path, engine='openpyxl') as writer:
         view_data_day_wise_a.to_excel(writer, sheet_name='day_wise', index=True)
        worksheet = writer.sheets['day_wise']

        # Apply color to the first row
        fill = PatternFill(start_color="87CEEB", end_color="87CEEB", fill_type="solid")
        for row in worksheet.iter_rows(min_row=1, max_row=1):
                for cell in row:
                 cell.fill = fill

        # Adjust column width
        for merged_range in worksheet.merged_cells.ranges:
                min_col, min_row, max_col, max_row = merged_range.bounds
                max_length = max(len(str(cell.value)) for row in worksheet.iter_rows(min_row=min_row, max_row=max_row)
                                for cell in row[min_col - 1:max_col])
                adjusted_width = (max_length + 2) * 1.2  # Adjust multiplier as needed
                column_letter = worksheet.cell(min_row, min_col).column_letter
                worksheet.column_dimensions[column_letter].width = adjusted_width

        print(f"Data has been written to {excel_file_path}")
report_daywise()
def removing_daywise():
        from openpyxl import load_workbook

# Load the Excel file
        wb = load_workbook('report_daywise.xlsx')

        # Access the active worksheet
        ws = wb.active

        # Loop through all cells in the worksheet
        for row in ws.iter_rows():
         for cell in row:
                # Check if the cell contains 'Measure Names' or 'Month of LOAN_DT'
                if cell.value == 'Measure Names' or cell.value == 'Day of PAID_DATE'  or cell.value == 'Mtd Achieved' or cell.value  == 'Unnamed: 1':
                # Clear the cell content
                 cell.value = None

        # Save the modified Excel file
        wb.save('removed_daywise.xlsx')
removing_daywise()
def rename_daywise():
    import pandas as pd
    import os
    os.remove('renamed_daywise.xlsx')
    # Read the Excel file
    df = pd.read_excel('removed_daywise.xlsx')

    # Rename the column names
    new_column_names = {'All': 'Grand_Total'
                #     'EXECUTIVE_CODE': 'code',
                #     'Avg. Branch Manager Target': 'Target',
                #     'Mtd Achieved':' Achieved',
                #    'BRANCH MANAGER VARIANCE':'Variance',
                #     'BM PER':'Achieved %' ,
                    # 'Avg. Sales Emp Target':'Monthly Target',
                    # 'Sales Emp  Percentage':'Monthly achived %',
                    # # 'AUM':'AUM in CR',
                    # 'Sales emp Variance':'Monthly Variance',
                    # 'LOAN_ID':'Count',





}

    df.rename(columns=new_column_names, inplace=True)

    # Save the modified DataFrame to a new Excel file
    df.to_excel('renamed_daywise.xlsx', index=False)

rename_daywise()
def round_daywise():
    print("round")
    import pandas as pd
    import os
    # os.remove('rounded_data_daywise.xlsx')

    df=pd.read_excel('renamed_daywise.xlsx')
    df_rounded=df.round(1)
    df_rounded=df_rounded.fillna(df)
    df_rounded.to_excel('rounded_data_daywise.xlsx',sheet_name='daywise',index=False)

round_daywise()
def blank():
        from openpyxl import load_workbook

        workbook = load_workbook("D:rounded_data_daywise.xlsx")

        sheet_names = workbook.sheetnames

        for sheet_name in sheet_names:
        
                sheet = workbook[sheet_name]
                for row in sheet.iter_rows():
                        for cell in row:
                                if cell.value=='Unnamed: 1':
                                        cell.value = ' '
                                elif cell.value=='Unnamed: 0':
                                       cell.value = ' '
        workbook.save(r'D:\MYCODE\power bi\powerbi\OUTPUT\new\renamed_daywise_new.xlsx')
blank()

def report_AP():
    from tableau_api_lib import TableauServerConnection
    from tableau_api_lib.utils import querying
    from tableau_api_lib.utils.common import flatten_dict_column
    import pandas as pd
    import xlrd
    from pandas import ExcelWriter
    import openpyxl
    from openpyxl.styles import PatternFill
    tableau_server_config = {
                    'my_env': {
                            'server': 'http://reports.manappuram.com',
                            'api_version': "3.17",
                            'username': 'tableauadministrator',
                            'password': 'M@fil@123',
                            'site_name': 'Default',
                            'site_url': ''
                    }
            }
    conn = TableauServerConnection(tableau_server_config, env='my_env',ssl_verify=False)
    conn.sign_in()
    site_views_df = querying.get_views_dataframe(conn)
    site_views_df
    site_views_detailed_df = flatten_dict_column(site_views_df, keys=['name', 'id'],col_name='workbook')
    site_views_detailed_df
    relevant_views_df = site_views_detailed_df[site_views_detailed_df['workbook_name'] == "Loan Disbursement Daily Report"]
    relevant_views_df
    AP='a155a20f-ab01-4e7d-8a7d-a7a913c1f1ae'
    view_data_day_AP= querying.get_view_data_dataframe(conn,AP)
    print(view_data_day_AP)
    Q=list(view_data_day_AP.columns)
    Q
    a5=view_data_day_AP.rename(columns={'HEADING':'PARTICULARS'},inplace=True)
    a5
    view_data_AP_a = view_data_day_AP.pivot(index=('EXECUTIVE_CODE','EXECUTIVE_NAME'), columns=['Measure Names'], values='Measure Values')
    print(view_data_AP_a)

    view_data_BM_a_sorted = view_data_AP_a.sort_values(by='Monthly achieved', ascending=False)
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\REPORT_AP.xlsx')

    writer = pd.ExcelWriter('REPORT_AP.xlsx', engine="openpyxl")
            
    view_data_BM_a_sorted.to_excel(writer,sheet_name="AP", index=True)
    for sheet_name, df in zip(["AP"], [view_data_BM_a_sorted]):
        worksheet = writer.book[sheet_name]
        
        # Apply color to the first row
        fill = PatternFill(start_color="87CEEB", end_color="87CEEB", fill_type="solid")
        for col in worksheet.iter_cols(min_row=1, max_row=1):
                for cell in col:
                 cell.fill = fill
        
        # Adjust column width
        for col in worksheet.columns:
            max_length = 0
            column = col[0].column_letter  # Get the column name
            for cell in col:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = (max_length + 2) * 1.2  # Adjust multiplier as needed
            worksheet.column_dimensions[column].width = adjusted_width



    writer.close()



report_AP()
def round_AP():
    print("round")
    import pandas as pd
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\rounded_data_AP.xlsx')

    df=pd.read_excel('REPORT_AP.xlsx')
    df_rounded=df.round(1)
    df_rounded=df_rounded.fillna(df)
    df_rounded.to_excel('rounded_data_AP.xlsx',index=False)

round_AP()
def order_AP():
    import pandas as pd
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\Ordered_AP.xlsx')

    # Read the Excel file
    excel_file_path = 'rounded_data_AP.xlsx'
    df = pd.read_excel(excel_file_path)

    # Define the desired order of columns
    desired_order = ['EXECUTIVE_CODE','EXECUTIVE_NAME','Sales Emp MTD Target', 'Sales Mtd Achieved', 'Sales Emp MTD Variance','Sales Emp MTD per', 'Avg. Sales Emp Target','Monthly achieved','Sales Emp  Percentage','Count of Loan Count','Sales emp Variance','LOAN_ID','Amount in lakhs','Aum in lakhs']

    # Reorder the columns
    df = df[desired_order]

    # Save the modified DataFrame back to Excel
    output_file_path = 'Ordered_AP.xlsx'
    df.to_excel(output_file_path, index=False)

    print('Columns reordered and saved to', output_file_path)
order_AP()
def sorted_AP():
    import pandas as pd
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\sorted_data_AP.xlsx')

    # Read the Excel file into a pandas DataFrame
    df = pd.read_excel('Ordered_AP.xlsx')

    # Sort the DataFrame based on the 'Sales Mtd Achieved' column in descending order
    df_sorted = df.sort_values(by='Sales Mtd Achieved', ascending=False)

    # Save the sorted DataFrame back to an Excel file
    df_sorted.to_excel('sorted_data_AP.xlsx', index=False)
sorted_AP()
def sum_AP():
    import pandas as pd
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\sumAP.xlsx')
# Read the Excel file into a DataFrame
    df = pd.read_excel('sorted_data_AP.xlsx')

    # Select the columns for which you want to calculate the sum
    columns_to_sum = ['Sales Emp MTD Target', 'Sales Mtd Achieved', 'Sales emp Variance', 'Sales Emp MTD per','Avg. Sales Emp Target','Monthly achieved','Sales Emp  Percentage','Count of Loan Count','LOAN_ID','Amount in lakhs','Aum in lakhs']

    # columns_to_sum = ['Amount in lakhs', 'Aum in lakhs', 'Avg. Sales Emp Target', 'Count of Loan Count', 'LOAN_ID', 'Monthly achieved', 'Sales Emp  Percentage', 'Sales Emp MTD Target', 'Sales Emp MTD Variance', 'Sales Emp MTD per', 'Sales Mtd Achieved', 'Sales emp Variance']

    # Add a column named "Rank" as the first column and set the index starting from 1
    df.insert(0, 'Rank', range(1, len(df) + 1))
    # df.index = range(1, len(df) + 1)

    # Calculate the column-wise sum for the selected columns
    column_sums = df[columns_to_sum].sum()

    # Add the column sums as the last row with a name 'Grand Total'
    df.loc['Grand Total'] = column_sums

    # Save the updated DataFrame to a new Excel file
    df.to_excel('sumAP.xlsx',sheet_name='AP',index=False)
sum_AP()

def rename_AP():

    import pandas as pd
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\renamedAP_file.xlsx')
    # Read the Excel file
    df = pd.read_excel('sumAP.xlsx')

    # Rename the column names
    new_column_names = {'EXECUTIVE_NAME': 'Name',
                    'EXECUTIVE_CODE': 'code',
                    'Sales Emp MTD Target': 'MTD Target',
                    'Sales Mtd Achieved':'MTD Achieved',
                   'Sales Emp MTD Variance':'Variance',
                    'Sales Emp MTD per':'MTD %' ,
                    'Avg. Sales Emp Target':'Monthly Target',
                    'Sales Emp  Percentage':'Monthly achived %',
                    # 'AUM':'AUM in CR',
                    'Sales emp Variance':'Monthly Variance',
                    'LOAN_ID':'Count',



                    

}

    df.rename(columns=new_column_names, inplace=True)
    

    # Save the modified DataFrame to a new Excel file
    df.to_excel(r'D:\MYCODE\power bi\powerbi\OUTPUT\new\renamedAP_file.xlsx',sheet_name='AP', index=False)
   
    # Save the modified DataFrame to a new Excel file
    # df.to_excel('renamedAP_file.xlsx', index=False)

   
rename_AP()



def report_TN():
    from tableau_api_lib import TableauServerConnection
    from tableau_api_lib.utils import querying
    from tableau_api_lib.utils.common import flatten_dict_column
    import pandas as pd
    import xlrd
    from pandas import ExcelWriter
    import openpyxl
    from openpyxl.styles import PatternFill
    tableau_server_config = {
                    'my_env': {
                            'server': 'http://reports.manappuram.com',
                            'api_version': "3.17",
                            'username': 'tableauadministrator',
                            'password': 'M@fil@123',
                            'site_name': 'Default',
                            'site_url': ''
                    }
            }
    conn = TableauServerConnection(tableau_server_config, env='my_env',ssl_verify=False)
    conn.sign_in()
    site_views_df = querying.get_views_dataframe(conn)
    site_views_df
    site_views_detailed_df = flatten_dict_column(site_views_df, keys=['name', 'id'],col_name='workbook')
    relevant_views_df = site_views_detailed_df[site_views_detailed_df['workbook_name'] == "Loan Disbursement Daily Report"]
    relevant_views_df
    TN='8b956e4e-08e5-48ac-bcd7-72945b185fea'
    view_data_TN= querying.get_view_data_dataframe(conn,TN)
    print(view_data_TN)
    Q=list(view_data_TN.columns)
    Q
    a5=view_data_TN.rename(columns={'HEADING':'PARTICULARS'},inplace=True)
    a5
    view_data_TN_a = view_data_TN.pivot(index=('EXECUTIVE_NAME','EXECUTIVE_CODE'), columns=['Measure Names'], values='Measure Values')
    print(view_data_TN_a)
    view_data_BM_a_sorted = view_data_TN_a.sort_values(by='Monthly achieved', ascending=False)
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\REPORT_TN.xlsx')

    writer = pd.ExcelWriter('REPORT_TN.xlsx', engine="openpyxl")
            
    view_data_BM_a_sorted.to_excel(writer,sheet_name="AP", index=True)
    for sheet_name, df in zip(["AP"], [view_data_BM_a_sorted]):
        worksheet = writer.book[sheet_name]
        
        # Apply color to the first row
        fill = PatternFill(start_color="87CEEB", end_color="87CEEB", fill_type="solid")
        for col in worksheet.iter_cols(min_row=1, max_row=1):
                for cell in col:
                 cell.fill = fill
        
        # Adjust column width
        for col in worksheet.columns:
            max_length = 0
            column = col[0].column_letter  # Get the column name
            for cell in col:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = (max_length + 2) * 1.2  # Adjust multiplier as needed
            worksheet.column_dimensions[column].width = adjusted_width



    writer.close()


report_TN()
def round_TN():
    print("round")
    import pandas as pd
    import os
    # os.remove('rounded_data_TN.xlsx')
    df=pd.read_excel('REPORT_TN.xlsx')
    df_rounded=df.round(1)
    df_rounded=df_rounded.fillna(df)
    df_rounded.to_excel('rounded_data_TN.xlsx',index=False)

round_TN()

def sorted_TN():
    import pandas as pd
    import os
    # os.remove('sorted_data_TN.xlsx')

    # Read the Excel file into a pandas DataFrame
    df = pd.read_excel('rounded_data_TN.xlsx')

    # Sort the DataFrame based on the 'Sales Mtd Achieved' column in descending order
    df_sorted = df.sort_values(by='Sales Mtd Achieved', ascending=False)

    # Save the sorted DataFrame back to an Excel file
    df_sorted.to_excel('sorted_data_TN.xlsx', index=False)
sorted_TN()

def order_TN():
    import pandas as pd

    # Read the Excel file
    import os
    # os.remove('Ordered_TN.xlsx')
    excel_file_path = 'sorted_data_TN.xlsx'
    df = pd.read_excel(excel_file_path)

    # Define the desired order of columns
    desired_order = ['EXECUTIVE_NAME','EXECUTIVE_CODE','Sales Emp MTD Target', 'Sales Mtd Achieved', 'Sales Emp MTD Variance', 'Sales Emp MTD per','Avg. Sales Emp Target','Monthly achieved','Sales Emp  Percentage','Count of Loan Count','Sales emp Variance','LOAN_ID','Amount in lakhs','Aum in lakhs']

    # Reorder the columns
    df = df[desired_order]

    # Save the modified DataFrame back to Excel
    output_file_path = 'Ordered_TN.xlsx'
    df.to_excel(output_file_path, index=False)

    print('Columns reordered and saved to', output_file_path)
order_TN()

def sum_TN():
    import pandas as pd
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\sumTN.xlsx')
# Read the Excel file into a DataFrame
    df = pd.read_excel('Ordered_TN.xlsx')

    # Select the columns for which you want to calculate the sum
    columns_to_sum = ['Amount in lakhs', 'Aum in lakhs', 'Avg. Sales Emp Target', 'Count of Loan Count', 'LOAN_ID', 'Monthly achieved', 'Sales Emp  Percentage', 'Sales Emp MTD Target', 'Sales Emp MTD Variance', 'Sales Emp MTD per', 'Sales Mtd Achieved', 'Sales emp Variance']

    # Add a column named "Rank" as the first column and set the index starting from 1
    df.insert(0, 'Rank', range(1, len(df) + 1))
    # df.index = range(1, len(df) + 1)

    # Calculate the column-wise sum for the selected columns
    column_sums = df[columns_to_sum].sum()

    # Add the column sums as the last row with a name 'Grand Total'
    df.loc['Grand Total'] = column_sums

    # Save the updated DataFrame to a new Excel file
    df.to_excel('sumTN.xlsx',sheet_name='TN',index=False)
sum_TN()


def rename_TN():
    import pandas as pd
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\renamedTN_file.xlsx')

    # Read the Excel file
    df = pd.read_excel('sumTN.xlsx')

    # Rename the column names
    new_column_names = {'EXECUTIVE_NAME': 'Name',
                    'EXECUTIVE_CODE': 'code',
                    'Sales Emp MTD Target': 'MTD Target',
                    'Sales Mtd Achieved':'MTD Achieved',
                   'Sales Emp MTD Variance':'Variance',
                    'Sales Emp MTD per':'MTD %' ,
                    'Avg. Sales Emp Target':'Monthly Target',
                    'Sales Emp  Percentage':'Monthly achived %',
                    'AUM':'AUM in CR',
                    'Sales emp Variance':'Monthly Variance',
                    'LOAN_ID':'Count',





}

    df.rename(columns=new_column_names, inplace=True)

    # Save the modified DataFrame to a new Excel file
    df.to_excel(r'D:\MYCODE\power bi\powerbi\OUTPUT\new\renamedTN_file.xlsx',sheet_name='TN', index=False)

rename_TN()
def report_KA():
    from tableau_api_lib import TableauServerConnection
    from tableau_api_lib.utils import querying
    from tableau_api_lib.utils.common import flatten_dict_column
    import pandas as pd
    import xlrd
    from pandas import ExcelWriter
    import openpyxl
    from openpyxl.styles import PatternFill
    tableau_server_config = {
                    'my_env': {
                            'server': 'http://reports.manappuram.com',
                            'api_version': "3.17",
                            'username': 'tableauadministrator',
                            'password': 'M@fil@123',
                            'site_name': 'Default',
                            'site_url': ''
                    }
            }
    conn = TableauServerConnection(tableau_server_config, env='my_env',ssl_verify=False)
    conn.sign_in()
    site_views_df = querying.get_views_dataframe(conn)
    site_views_df
    site_views_detailed_df = flatten_dict_column(site_views_df, keys=['name', 'id'],col_name='workbook')
    site_views_detailed_df
    KAR='73199e18-115d-427c-aa6f-4620792ad554'
    view_data_KAR= querying.get_view_data_dataframe(conn,KAR)
    print(view_data_KAR)
    Q=list(view_data_KAR.columns)
    Q
    view_data_KAR_a = view_data_KAR.pivot(index=('EXECUTIVE_CODE','EXECUTIVE_NAME'), columns=['Measure Names'], values='Measure Values')
    print(view_data_KAR_a)
    view_data_BM_a_sorted = view_data_KAR_a.sort_values(by='Monthly achieved', ascending=False)
    import os
    # os.remove('REPORT_KAR.xlsx')

    writer = pd.ExcelWriter('REPORT_KAR.xlsx', engine="openpyxl")
            
    view_data_KAR_a.to_excel(writer,sheet_name="KA", index=True)
    for sheet_name, df in zip(["KA"], [view_data_KAR_a]):
        worksheet = writer.book[sheet_name]
        
        # Apply color to the first row
        fill = PatternFill(start_color="87CEEB", end_color="87CEEB", fill_type="solid")
        for col in worksheet.iter_cols(min_row=1, max_row=1):
                for cell in col:
                 cell.fill = fill
        
        # Adjust column width
        for col in worksheet.columns:
            max_length = 0
            column = col[0].column_letter  # Get the column name
            for cell in col:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = (max_length + 2) * 1.2  # Adjust multiplier as needed
            worksheet.column_dimensions[column].width = adjusted_width



    writer.close()
report_KA()

def round_KA():
    print("round")
    import pandas as pd
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\rounded_data_KAR.xlsx')

    df=pd.read_excel('REPORT_KAR.xlsx')
    df_rounded=df.round(1)
    df_rounded=df_rounded.fillna(df)
    df_rounded.to_excel('rounded_data_KAR.xlsx',index=False)

round_KA()
def sorted_KA():
    import pandas as pd
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\sorted_data_KAR.xlsx')

    # Read the Excel file into a pandas DataFrame
    df = pd.read_excel('rounded_data_KAR.xlsx')

    # Sort the DataFrame based on the 'Sales Mtd Achieved' column in descending order
    df_sorted = df.sort_values(by='Sales Mtd Achieved', ascending=False)

    # Save the sorted DataFrame back to an Excel file
    df_sorted.to_excel('sorted_data_KAR.xlsx', index=False)
sorted_KA()
def order_KA():
    import pandas as pd
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\Ordered_KAR.xlsx')

    # Read the Excel file
    excel_file_path = 'sorted_data_KAR.xlsx'
    df = pd.read_excel(excel_file_path)

    # Define the desired order of columns
    desired_order = ['EXECUTIVE_CODE','EXECUTIVE_NAME','Sales Emp MTD Target', 'Sales Mtd Achieved', 'Sales Emp MTD Variance','Sales Emp MTD per', 'Avg. Sales Emp Target','Monthly achieved','Sales Emp  Percentage','Count of Loan Count','Sales emp Variance','LOAN_ID','Amount in lakhs','Aum in lakhs']

    # Reorder the columns
    df = df[desired_order]

    # Save the modified DataFrame back to Excel
    output_file_path = 'Ordered_KAR.xlsx'
    df.to_excel(output_file_path, index=False)

    print('Columns reordered and saved to', output_file_path)
order_KA()

def sum_KA():
    import pandas as pd
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\sumKAR.xlsx')
# Read the Excel file into a DataFrame
    df = pd.read_excel('Ordered_KAR.xlsx')

    # Select the columns for which you want to calculate the sum
    columns_to_sum = ['Sales Emp MTD Target', 'Sales Mtd Achieved', 'Sales emp Variance', 'Sales Emp MTD per','Avg. Sales Emp Target','Monthly achieved','Sales Emp  Percentage','Count of Loan Count','LOAN_ID','Amount in lakhs','Aum in lakhs']

    # columns_to_sum = ['Amount in lakhs', 'Aum in lakhs', 'Avg. Sales Emp Target', 'Count of Loan Count', 'LOAN_ID', 'Monthly achieved', 'Sales Emp  Percentage', 'Sales Emp MTD Target', 'Sales Emp MTD Variance', 'Sales Emp MTD per', 'Sales Mtd Achieved', 'Sales emp Variance']

    # Add a column named "Rank" as the first column and set the index starting from 1
    df.insert(0, 'Rank', range(1, len(df) + 1))
    # df.index = range(1, len(df) + 1)

    # Calculate the column-wise sum for the selected columns
    column_sums = df[columns_to_sum].sum()

    # Add the column sums as the last row with a name 'Grand Total'
    df.loc['Grand Total'] = column_sums

    # Save the updated DataFrame to a new Excel file
    df.to_excel('sumKAR.xlsx',index=False)
sum_KA()

def rename_KA():
    import pandas as pd
    import os
    # os.remove(r'D:\MYCODE\power bi\powerbi\renamedKAR_file.xlsx')
    # Read the Excel file
    df = pd.read_excel('sumKAR.xlsx')

    # Rename the column names
    new_column_names = {'EXECUTIVE_NAME': 'Name',
                    'EXECUTIVE_CODE': 'code',
                    'Sales Emp MTD Target': 'MTD Target',
                    'Sales Mtd Achieved':'MTD Achieved',
                   'Sales Emp MTD Variance':'Variance',
                    'Sales Emp MTD per':'MTD %' ,
                    'Avg. Sales Emp Target':'Monthly Target',
                    'Sales Emp  Percentage':'Monthly achived %',
                    # 'AUM':'AUM in CR',
                    'Sales emp Variance':'Monthly Variance',
                    'LOAN_ID':'Count',





}

    df.rename(columns=new_column_names, inplace=True)

    # Save the modified DataFrame to a new Excel file
    df.to_excel(r'D:\MYCODE\power bi\powerbi\OUTPUT\new\renamedKAR_file.xlsx',sheet_name='KA', index=False)

rename_KA()
def report_branch_daywise():
    from tableau_api_lib import TableauServerConnection
    from tableau_api_lib.utils import querying
    from tableau_api_lib.utils.common import flatten_dict_column
    import pandas as pd
    import xlrd
    from pandas import ExcelWriter
    import openpyxl
    from openpyxl.styles import PatternFill
    tableau_server_config = {
                    'my_env': {
                            'server': 'http://reports.manappuram.com',
                            'api_version': "3.17",
                            'username': 'tableauadministrator',
                            'password': 'M@fil@123',
                            'site_name': 'Default',
                            'site_url': ''
                    }
            }
    conn = TableauServerConnection(tableau_server_config, env='my_env',ssl_verify=False)
    conn.sign_in()
    site_views_df = querying.get_views_dataframe(conn)
    site_views_df
    site_views_detailed_df = flatten_dict_column(site_views_df, keys=['name', 'id'],col_name='workbook')
    site_views_detailed_df
    relevant_views_df = site_views_detailed_df[site_views_detailed_df['workbook_name'] == "Loan Disbursement Daily Report"]
    relevant_views_df
    branch_day_wise='d3e70f2a-81d8-4932-a47d-eca03e740944'
    view_data_day_wise= querying.get_view_data_dataframe(conn,branch_day_wise)
    print(view_data_day_wise)
    Q=list(view_data_day_wise.columns)
    Q
    view_data_day_wise_a = view_data_day_wise.pivot(index=['BRANCH_NAME'], columns=['Day of PAID_DATE','Measure Names'], values='Measure Values')
    view_data_day_wise_a
    def shift_row_to_bottom(df,index_to_shift):
          idx = [i for i in df.index if i!= index_to_shift]
          return df.loc[idx+[index_to_shift]]
    ist = shift_row_to_bottom(view_data_day_wise_a,('All'))
    ist
    view_data_day_wise_a = ist.rename(index={'All': 'Grand Total'})
    view_data_day_wise_a
    excel_file_path = 'Branch_daywise.xlsx'
    with pd.ExcelWriter(excel_file_path, engine='openpyxl') as writer:
            view_data_day_wise_a.to_excel(writer, sheet_name='branch_daywise', index=True)
    worksheet = writer.sheets['branch_daywise']

            # Apply color to the first row
    fill = PatternFill(start_color="87CEEB", end_color="87CEEB", fill_type="solid")
    for row in worksheet.iter_rows(min_row=1, max_row=1):
                    for cell in row:
                     cell.fill = fill

            # Adjust column width
    for merged_range in worksheet.merged_cells.ranges:
                    min_col, min_row, max_col, max_row = merged_range.bounds
                    max_length = max(len(str(cell.value)) for row in worksheet.iter_rows(min_row=min_row, max_row=max_row)
                                    for cell in row[min_col - 1:max_col])
                    adjusted_width = (max_length + 2) * 1.2  # Adjust multiplier as needed
                    column_letter = worksheet.cell(min_row, min_col).column_letter
                    worksheet.column_dimensions[column_letter].width = adjusted_width

                    print(f"Data has been written to {excel_file_path}")
report_branch_daywise()
def removing_branch_daywise():
        from openpyxl import load_workbook
    
# Load the Excel file
        wb = load_workbook('Branch_daywise.xlsx')
        # wb = load_workbook('report_daywise.xlsx')
        # Access the active worksheet
        ws = wb.active

        # Loop through all cells in the worksheet
        for row in ws.iter_rows():
         for cell in row:
                # Check if the cell contains 'Measure Names' or 'Month of LOAN_DT'
                if cell.value == 'Measure Names' or cell.value == 'Day of PAID_DATE'  or cell.value == 'Mtd Achieved' or cell.value  == 'Unnamed: 1':
                # Clear the cell content
                 cell.value = None

        # Save the modified Excel file
        wb.save('removed_branch_daywise.xlsx')
removing_branch_daywise()
def rename_branch_wise():
    import pandas as pd
    import os
    # os.remove('renamed_daywise.xlsx')
    # Read the Excel file
    df = pd.read_excel('removed_daywise.xlsx')

    # Rename the column names
    new_column_names = {'All': 'Grand_Total'
                #     'EXECUTIVE_CODE': 'code',
                #     'Avg. Branch Manager Target': 'Target',
                #     'Mtd Achieved':' Achieved',
                #    'BRANCH MANAGER VARIANCE':'Variance',
                #     'BM PER':'Achieved %' ,
                    # 'Avg. Sales Emp Target':'Monthly Target',
                    # 'Sales Emp  Percentage':'Monthly achived %',
                    # # 'AUM':'AUM in CR',
                    # 'Sales emp Variance':'Monthly Variance',
                    # 'LOAN_ID':'Count',





}

    df.rename(columns=new_column_names, inplace=True)

    # Save the modified DataFrame to a new Excel file
    df.to_excel('renamed_daywise.xlsx', index=False)

rename_branch_wise()
def round_branch_daywise():
    print("round")
    import pandas as pd
    import os
    # os.remove('rounded_data_daywise.xlsx')

    df=pd.read_excel('renamed_daywise.xlsx')
    df_rounded=df.round(1)
    df_rounded=df_rounded.fillna(df)
    df_rounded.to_excel('rounded_data_daywise.xlsx',sheet_name='branch_daywise',index=False)

round_branch_daywise()
def blank():
        from openpyxl import load_workbook

        workbook = load_workbook("D:rounded_data_daywise.xlsx")

        sheet_names = workbook.sheetnames

        for sheet_name in sheet_names:
        
                sheet = workbook[sheet_name]
                for row in sheet.iter_rows():
                        for cell in row:
                                if cell.value=='Unnamed: 1':
                                        cell.value = ' '
                                elif cell.value=='Unnamed: 0':
                                       cell.value = ' '
        workbook.save(r'D:\MYCODE\power bi\powerbi\OUTPUT\new\branch_daywise_new.xlsx')
blank()
