DAILY REPORT FOR CUSTOMER MODIFICATION

This script automates the generation and distribution of a daily customer modification report via outlook mail.

Requirements:

    Python 3.x
    Libraries:
        xlsxwriter
        pandas
        cx_Oracle
        openpyxl
        tableau_api_lib 
    smtplib
    datetime
    time

Script Functionality:

    Database Connection: Establishes a connection to the Oracle database.
    Data Retrieval: Executes SQL queries to retrieve customer modification data from the database.
        If no data is found, a message is printed indicating this and the script exits.
    Excel Report Creation:
        Creates a new Excel workbook named "Customer_Modification_report.xlsx".
        Writes the retrieved data to the first sheet named "Customer_Modification_report".
        Formats the Excel sheet with headers, borders, alignment, and column widths.
    Email Preparation:
        If data exists:
            Attaches the generated Excel report to an email message.
            Creates an HTML table from a separate DataFrame containing additional information.
            Constructs the email body with text and the HTML table.
        Sends the email using the configured SMTP server details.
        Prints confirmation messages for successful email sending.

Running the Script:

    Run the script from your terminal using python app.py.

Notes:

    The script currently includes commented-out sections for Tableau server connection and image capture. These sections are not required for the core functionality and can be removed if not needed.
    Consider adding error handling for potential issues like database connection failures or email sending errors.

