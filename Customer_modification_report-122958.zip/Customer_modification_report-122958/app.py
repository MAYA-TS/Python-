import xlsxwriter
import os
import pandas as pd
import cx_Oracle
import openpyxl
from pandas import ExcelWriter
from openpyxl import Workbook
from email.message import EmailMessage
from email.utils import make_msgid
import mimetypes
from tableau_api_lib import TableauServerConnection
from tableau_api_lib.utils import querying
from tableau_api_lib.utils.common import flatten_dict_column
import pandas as pd
import xlrd
from pandas import ExcelWriter
from openpyxl import load_workbook
from openpyxl.styles import PatternFill,Font
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side
import smtplib
import datetime
import time
# import schedule
import time


# conn = cx_Oracle.connect("kpmg", "Asd$1234", "HISTDB1")
# tableau_server_config = {
#                 'my_env': {
#                         'server': 'https://reports.manappuram.com',
#                         'api_version': "3.17",
#                         'username': 'tableauadministrator',
#                         'password': 'M@fil@123',
#                         'site_name': 'Default',
#                         'site_url': ''
#                 }
#         }
# conn = TableauServerConnection(tableau_server_config, env='my_env',ssl_verify=False)
# conn.sign_in()
# site_views_df = querying.get_views_dataframe(conn)
# site_views_detailed_df = flatten_dict_column(site_views_df, keys=['name', 'id'], col_name='workbook')
# site_views_detailed_df.tail(60)
# relevant_views_df = site_views_detailed_df[site_views_detailed_df['workbook_name'] == 'Customer Modification Report']
# print(relevant_views_df)
# # relevant_views_df.refresh(workbook_id='949d788d-c89f-432d-8af2-c03990e149c5')

# fzm_data='4bb1459c-b3e6-4a5b-8b07-0eaf77f98a36'

# view_img = conn.query_view_image(view_id=fzm_data)
# print(view_img)
# with open(r"C:\\Users\\398504\\CRF\\crf26\\122958-Daily_report_for_customer_modification\\Customer_Modification_report.png","wb") as f:
   
#     f.write(view_img.content)
# print("Third section completed................")
conn = cx_Oracle.connect("kpmg", "Asd$1234", "HISTDB1")
print("Oracle database connected")
print("Tableau server connected")



df1=pd.read_sql("""
select e.*,g.fzm from (select x.* , trunc(y.reg_date) reg_date,z.outstanding ,
w.total_pledge_count yesterday_pledge_count ,
total_pledge_value yesterday_pledge_value, --w.last_pledge_date,
 g.post_name approved_post_name  
from (select a.cust_id, b.name,b.branch_id,
       a.recomm_by,
       a.aprvd_by,
       a.requested_by, 
     -- a.change_type,
       case
         when change_type = 1 then
          'Name Change'
         when change_type = 2 then
          'Address Change'
         when change_type = 3 then
          'Phone Number Change'
         when change_type = 4 then
          'Kyc ID Change'
         when change_type = 5 and kyc_photo is not null then
          'Kyc Photo Change'
         when change_type = 5 and cust_photo is not null then
          'Cust Photo Change'
         when change_type = 5 and cust_photo is  null and kyc_photo is  null 
          then 'kyc / customer photo change'
           end as changes
  from 
   dms.kyc_pre_auth@uatr_backup2 a left outer join 
  mana0809.customer@uatr_backup2 b
   on a.cust_id=b.cust_id
 where trunc(a.tra_dt) = trunc(sysdate - 1) and a.cust_id is not null
 and a.status_id =2
 
 union all
 
 select t.cust_id,
       s.name,
       t.branch_id,
       ah_user recomm_by,
       rm_user aprvd_by,
       t.user_id requested_by,
       'Ogl neft change ' changes
  from DMS.TBL_OGL_CUSt_NEFT_CHANGE@uatr_backup2 t,
       mana0809.branch_dtl_new@uatr_backup2      b,
       mana0809.customer@uatr_backup2 s
 where t.branch_id = b.BRANCH_ID
   and t.status = 5 and s.cust_id=t.cust_id
   and trunc(t.neft_updt_dt) = trunc(sysdate - 1)
   
   union all

  select t.cust_id,
         s.name,
         t.branch_id,
         ah_user recomm_by,
         rm_user aprvd_by,
         t.user_id requested_by,
         'Offline neft change ' changes
          from dms.TBL_OFFLN_CUST_NEFT_CHANGE@uatr_backup2 t,
         mana0809.branch_dtl_new@uatr_backup2        b ,
         mana0809.customer@uatr_backup2 s
         where t.branch_id = b.BRANCH_ID
           and t.status between 3 and 5 and  s.cust_id=t.cust_id
           and trunc(t.tra_dt) = trunc(sysdate - 1)
           
  union all
 select x.cust_id,
        z.cust_name,
        z.branch_id,
      to_number(REGEXP_SUBSTR(x.ah_empcode, '[0-9]+')) recomm_by,
       to_number(REGEXP_SUBSTR(x.verified_by, '[0-9]+')) aprvd_by,
       to_number(x.user_id) requested_by,
        'Pan Modified' changes
   from (select * from dms.deposit_pan_detail@uatr_backup2) x,
        (select distinct cust_id
           from dms.deposit_pan_detail_his@uatr_backup2) y,
        mana0809.customer@uatr_backup2 z,
        mana0809.branch_dtl_new@uatr_backup2 w
  where x.cust_id = y.cust_id
    and x.cust_id = z.cust_id
    and trunc(x.tra_dt) = trunc(sysdate - 1)
    and z.branch_id = w.branch_id

  ) x left outer join
 mana0809.customer_detail@uatr_backup2 y
 on x.cust_id=y.cust_id 
 left outer join ( select cust_id, sum(balance) Outstanding
                                     from kpmg.pledge_acrual@uatr_backup2
                                     where cust_id in (select cust_id from 
                                    dms.kyc_pre_auth@uatr_backup2 f 
                                    where trunc(f.tra_dt) = trunc(sysdate - 1) 
                                    and f.cust_id is not null and f.status_id =2 
                                     and f.change_type in (1,2,3,4,5)  
                                     union all  
                                     select cust_id from dms.TBL_OFFLN_CUST_NEFT_CHANGE@uatr_backup2 t
                                     where t.status between 3 and 5
                                      and trunc(t.tra_dt) = trunc(sysdate - 1) 
                                      union all
                                     select cust_id from DMS.TBL_OGL_CUSt_NEFT_CHANGE@uatr_backup2 r
                                     where   r.status = 5
                                     and trunc(r.neft_updt_dt) = trunc(sysdate - 1)
                                     union all 
                                     select distinct x.cust_id from  dms.deposit_pan_detail@uatr_backup2 x,
                                     dms.deposit_pan_detail_his@uatr_backup2 y
                                     where x.cust_id=y.cust_id and trunc(x.tra_dt) = trunc(sysdate - 1)
                                      )
                                    group by cust_id )z
                                    on x.cust_id= z.cust_id
  left outer join                                 
(select e.cust_id, count(e.pledge_no)total_pledge_count,
sum(e.pledge_val) total_pledge_value 
from mana0809.pledge_master@uatr_backup2 e,
mana0809.pledge_status@uatr_backup2 f
where e.cust_id in (select cust_id from 
                                    dms.kyc_pre_auth@uatr_backup2 f 
                                    where trunc(f.tra_dt) = trunc(sysdate - 1) 
                                    and f.cust_id is not null and f.status_id =2 
                                     and f.change_type in (1,2,3,4,5)  
                                     union all  
                                     select cust_id from dms.TBL_OFFLN_CUST_NEFT_CHANGE@uatr_backup2 t
                                     where t.status between 3 and 5
                                      and trunc(t.tra_dt) = trunc(sysdate - 1) 
                                      union all
                                     select cust_id from DMS.TBL_OGL_CUSt_NEFT_CHANGE@uatr_backup2 r
                                     where   r.status = 5
                                     and trunc(r.neft_updt_dt) = trunc(sysdate - 1)
                                     and trunc(tra_dt)=trunc(sysdate-1)
                                     union all 
                                     select distinct x.cust_id  from  dms.deposit_pan_detail@uatr_backup2 x,
                                     dms.deposit_pan_detail_his@uatr_backup2 y
                                     where x.cust_id=y.cust_id and trunc(x.tra_dt) = trunc(sysdate - 1) )
                                     and trunc(e.tra_dt) = trunc(sysdate-1) 
                                     and e.pledge_no =f.pledge_no and f.status_id!=0
                                     group by e.cust_id ) w
                                     on w.cust_id=x.cust_id
      
      left outer join mana0809.tableau_employ_dtl@uatr_backup2 g
      on x.aprvd_by=g.emp_code) e  left outer join
     mana0809.branch_dtl_new@uatr_backup2  f
     on e.branch_id = f.branch_id
     left outer join mana0809.tbl_fzm_master@uatr_backup2  g
     on g.region_id= f.reg_id
                                
""",con=conn)
#---------------------------------------------------------------------
df2=pd.read_sql("""
select fzm, count(distinct cust_id) As TOTAL_CUSTOMERS from (select e.*,g.fzm from (select x.* , trunc(y.reg_date) reg_date,z.outstanding ,
w.total_pledge_count yesterday_pledge_count ,
total_pledge_value yesterday_pledge_value, --w.last_pledge_date,
 g.post_name approved_post_name  
from (select a.cust_id, b.name,b.branch_id,
       a.recomm_by,
       a.aprvd_by,
       a.requested_by, 
     -- a.change_type,
       case
         when change_type = 1 then
          'Name Change'
         when change_type = 2 then
          'Address Change'
         when change_type = 3 then
          'Phone Number Change'
         when change_type = 4 then
          'Kyc ID Change'
         when change_type = 5 and kyc_photo is not null then
          'Kyc Photo Change'
         when change_type = 5 and cust_photo is not null then
          'Cust Photo Change'
         when change_type = 5 and cust_photo is  null and kyc_photo is  null 
          then 'kyc / customer photo change'
           end as changes
  from 
   dms.kyc_pre_auth@uatr_backup2 a left outer join 
  mana0809.customer@uatr_backup2 b
   on a.cust_id=b.cust_id
 where trunc(a.tra_dt) = trunc(sysdate - 1) and a.cust_id is not null
 and a.status_id =2
 
 union all
 
 select t.cust_id,
       s.name,
       t.branch_id,
       ah_user recomm_by,
       rm_user aprvd_by,
       t.user_id requested_by,
       'Ogl neft change ' changes
  from DMS.TBL_OGL_CUSt_NEFT_CHANGE@uatr_backup2 t,
       mana0809.branch_dtl_new@uatr_backup2      b,
       mana0809.customer@uatr_backup2 s
 where t.branch_id = b.BRANCH_ID
   and t.status = 5 and s.cust_id=t.cust_id
   and trunc(t.neft_updt_dt) = trunc(sysdate - 1)
   
   union all

  select t.cust_id,
         s.name,
         t.branch_id,
         ah_user recomm_by,
         rm_user aprvd_by,
         t.user_id requested_by,
         'Offline neft change ' changes
          from dms.TBL_OFFLN_CUST_NEFT_CHANGE@uatr_backup2 t,
         mana0809.branch_dtl_new@uatr_backup2        b ,
         mana0809.customer@uatr_backup2 s
         where t.branch_id = b.BRANCH_ID
           and t.status between 3 and 5 and  s.cust_id=t.cust_id
           and trunc(t.tra_dt) = trunc(sysdate - 1)
           
  union all
 select x.cust_id,
        z.cust_name,
        z.branch_id,
      to_number(REGEXP_SUBSTR(x.ah_empcode, '[0-9]+')) recomm_by,
       to_number(REGEXP_SUBSTR(x.verified_by, '[0-9]+')) aprvd_by,
       to_number(x.user_id) requested_by,
        'Pan Modified' changes
   from (select * from dms.deposit_pan_detail@uatr_backup2) x,
        (select distinct cust_id
           from dms.deposit_pan_detail_his@uatr_backup2) y,
        mana0809.customer@uatr_backup2 z,
        mana0809.branch_dtl_new@uatr_backup2 w
  where x.cust_id = y.cust_id
    and x.cust_id = z.cust_id
    and trunc(x.tra_dt) = trunc(sysdate - 1)
    and z.branch_id = w.branch_id

  ) x left outer join
 mana0809.customer_detail@uatr_backup2 y
 on x.cust_id=y.cust_id 
 left outer join ( select cust_id, sum(balance) Outstanding
                                     from kpmg.pledge_acrual@uatr_backup2
                                     where cust_id in (select cust_id from 
                                    dms.kyc_pre_auth@uatr_backup2 f 
                                    where trunc(f.tra_dt) = trunc(sysdate - 1) 
                                    and f.cust_id is not null and f.status_id =2 
                                     and f.change_type in (1,2,3,4,5)  
                                     union all  
                                     select cust_id from dms.TBL_OFFLN_CUST_NEFT_CHANGE@uatr_backup2 t
                                     where t.status between 3 and 5
                                      and trunc(t.tra_dt) = trunc(sysdate - 1) 
                                      union all
                                     select cust_id from DMS.TBL_OGL_CUSt_NEFT_CHANGE@uatr_backup2 r
                                     where   r.status = 5
                                     and trunc(r.neft_updt_dt) = trunc(sysdate - 1)
                                     union all 
                                     select distinct x.cust_id from  dms.deposit_pan_detail@uatr_backup2 x,
                                     dms.deposit_pan_detail_his@uatr_backup2 y
                                     where x.cust_id=y.cust_id and trunc(x.tra_dt) = trunc(sysdate - 1)
                                      )
                                    group by cust_id )z
                                    on x.cust_id= z.cust_id
  left outer join                                 
(select e.cust_id, count(e.pledge_no)total_pledge_count,
sum(e.pledge_val) total_pledge_value 
from mana0809.pledge_master@uatr_backup2 e,
mana0809.pledge_status@uatr_backup2 f
where e.cust_id in (select cust_id from 
                                    dms.kyc_pre_auth@uatr_backup2 f 
                                    where trunc(f.tra_dt) = trunc(sysdate - 1) 
                                    and f.cust_id is not null and f.status_id =2 
                                     and f.change_type in (1,2,3,4,5)  
                                     union all  
                                     select cust_id from dms.TBL_OFFLN_CUST_NEFT_CHANGE@uatr_backup2 t
                                     where t.status between 3 and 5
                                      and trunc(t.tra_dt) = trunc(sysdate - 1) 
                                      union all
                                     select cust_id from DMS.TBL_OGL_CUSt_NEFT_CHANGE@uatr_backup2 r
                                     where   r.status = 5
                                     and trunc(r.neft_updt_dt) = trunc(sysdate - 1)
                                     and trunc(tra_dt)=trunc(sysdate-1)
                                     union all 
                                     select distinct x.cust_id  from  dms.deposit_pan_detail@uatr_backup2 x,
                                     dms.deposit_pan_detail_his@uatr_backup2 y
                                     where x.cust_id=y.cust_id and trunc(x.tra_dt) = trunc(sysdate - 1) )
                                     and trunc(e.tra_dt) = trunc(sysdate-1) 
                                     and e.pledge_no =f.pledge_no and f.status_id!=0
                                     group by e.cust_id ) w
                                     on w.cust_id=x.cust_id
      
      left outer join mana0809.tableau_employ_dtl@uatr_backup2 g
      on x.aprvd_by=g.emp_code) e  left outer join
     mana0809.branch_dtl_new@uatr_backup2  f
     on e.branch_id = f.branch_id
     left outer join mana0809.tbl_fzm_master@uatr_backup2  g
     on g.region_id= f.reg_id) where fzm is not null
     group by fzm
                                
                                
""",con=conn)

print("Query section completed...........")



if not df1.empty:
    writer=pd.ExcelWriter("C:\\Users\\398504\\CRF\\crf26\\122958-Daily_report_for_customer_modification\\Customer_Modification_report.xlsx",engine="openpyxl")
    df1.to_excel(writer, sheet_name="Customer_Modification_report", index=False)
    # df2.to_excel(writer, sheet_name="Report", index=False)

    print("saved as excel")
    writer.save()
    print("Excel downloading section completed............")
    

    workbook = openpyxl.load_workbook('C:\\Users\\398504\\CRF\\crf26\\122958-Daily_report_for_customer_modification\\Customer_Modification_report.xlsx')
    print("wb open")
    ws = workbook['Customer_Modification_report']
    # ws.insert_rows(1,4)
    # .............................................................................................................................................................
    for row in ws.iter_rows():
        for cell in row:
            if cell.column_letter in ['H', 'L'] and isinstance(cell.value, datetime.datetime):
                cell.value = cell.value.strftime('%d-%m-%Y')
    sheet_names = workbook.sheetnames
    heading_color =  '34495e'    #'73BCC5'#'8080ff'  # Red color
    # body_color = 'F6E5F5'  # Green color
    border_style = Border(
        left=Side(border_style='thin'),
        right=Side(border_style='thin'),
        top=Side(border_style='thin'),
        bottom=Side(border_style='thin'))


    for sheet_name in sheet_names:
        sheet = workbook[sheet_name]
        header_font = Font(color="FFFFFF", bold=True)
        header_fill = PatternFill(start_color='34495e', end_color='34495e', fill_type='solid')
        for cell in sheet[1]:
            cell.fill = header_fill
            cell.font = header_font
        # body_fill = PatternFill(start_color=body_color, end_color=body_color, fill_type='solid')
        # for row in sheet.iter_rows(min_row=2):
        #     for cell in row:
        #         cell.fill = body_fill
                
        for column in sheet.columns:
            non_empty_values = [cell.value for cell in column if cell.value]
            if non_empty_values:
                max_length = max(len(str(value)) for value in non_empty_values)
                column_letter = get_column_letter(column[0].column)
                adjusted_width = (max_length + 2) * 1.2  # Adjust the width as desired
                sheet.column_dimensions[column_letter].width = adjusted_width
        for row in sheet.rows:
            max_height = max(str(cell.value).count('\n') + 1 for cell in row if cell.value)
            row_number = row[0].row
            adjusted_height = max_height * 17 # Adjust the height as desired
            sheet.row_dimensions[row_number].height = adjusted_height
        for row in sheet.iter_rows():
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
        for row in sheet.iter_rows():
            for cell in row:
                cell.border = border_style
        # for sheet_name in sheet_names:
        #     sheet = workbook[sheet_name]
        # for row in sheet.iter_rows():
        #     color1 = '73BCC5'
        #     color2 = 'F6E5F5' # Assuming you have 10 rows of data
        #     if row[0].value % 2 == 0:  # Access the value of the cell
        #         fill = PatternFill(start_color=color1, end_color=color1, fill_type="solid")
        #     else:
        #         fill = PatternFill(start_color=color2, end_color=color2, fill_type="solid")
        #     for col in range(1, 14):  # Assuming you have 5 columns of data
        #         sheet.cell(row=row, column=col).fill = fill


    workbook.save('C:\\Users\\398504\\CRF\\crf26\\122958-Daily_report_for_customer_modification\\Customer_Modification_report.xlsx')
    print("done")
    workbook = openpyxl.load_workbook('C:\\Users\\398504\\CRF\\crf26\\122958-Daily_report_for_customer_modification\\Customer_Modification_report.xlsx')

    # Access the specific worksheet
    worksheet = workbook['Customer_Modification_report']

    # Define alternate row colors
    # for row in worksheet.iter_rows(min_row=2, max_row=worksheet.max_row, min_col=1, max_col=worksheet.max_column):
    #     for cell in row:
    #         if cell.row % 3 == 0:
    #             cell.fill = PatternFill(start_color='DAC0A3', end_color='DAC0A3', fill_type='solid')
    #         elif cell.row % 2==0:
    #             cell.fill = PatternFill(start_color='EADBC8', end_color='EADBC8', fill_type='solid')
    #         else:
    #             cell.fill = PatternFill(start_color='F8F0E5', end_color='F8F0E5', fill_type='solid')


    # Save the workbook
    workbook.save('C:\\Users\\398504\\CRF\\crf26\\122958-Daily_report_for_customer_modification\\Customer_Modification_report.xlsx')
    workbook = openpyxl.load_workbook(r"C:\\Users\\398504\\CRF\\crf26\\122958-Daily_report_for_customer_modification\\Customer_Modification_report.xlsx")
    worksheet = workbook["Customer_Modification_report"]

    # if worksheet.max_row == 0:
    s = smtplib.SMTP(host='smtp.office365.com', port=587)
    s.starttls()
    # print("aaa")
    # s.login('398504@manappuram.com', 'pcdjnbgjdxvmdrkg')
    # s.login('iotautomation@manappuram.com','ybjmxbfdyzkdnjtw')
    
    s.login('internalaudit1@manappuram.com','AB@123ad')
    print("Login the mail address")
    msg = EmailMessage()
    print("Ready for mailing")

    msg['Subject'] = 'CUSTOMER MODIFICATION REPORT'
    # msg['From'] = '<iotautomation@manappuram.com>'
    # msg['From'] = '<398504@manappuram.com>'

   
    msg['From'] = '<internalaudit1@manappuram.com>'
    # msg['To']='<itsales@manappuram.com>'
    # msg['To']='<researchwing@manappuram.com>'


    msg['To']='Audit Research Wing<researchwing@manappuram.com>', 'RIJU P<gmaudit@manappuram.com>','LAXMAN TAGGINAVAR <headresearchwing@manappuram.com>'
  
    # msg['To']='<iotsupport15@manappuram.com>'
    # msg['Cc']='<dataservice25@manappuram.com>'

    msg['Cc']='<iotsupport7@manappuram.com>','<dataservice25@manappuram.com>','<iotsupport15@manappuram.com>'


   
    with open(r"C:\\Users\\398504\\CRF\\crf26\\122958-Daily_report_for_customer_modification\\Customer_Modification_report.xlsx", 'rb') as ra:
        attachment = ra.read()
    msg.add_related(attachment, maintype='application', subtype='xlsx', filename='Customer Modification Report.xlsx')
        # Sort the DataFrame in ascending order (default behavior)
    sorted_df = df2.sort_values(by=['FZM', 'TOTAL_CUSTOMERS'], ascending=True)  # Sorts by index by default
    html_table = sorted_df.to_html(index=False)

    # Create CSS class for centering (add this to a separate CSS file)
   

    # html_table = sorted_df.to_html(index=False)
    
    print(html_table)
    conn.close()
    html_content = f"""
<html>
    <head>
        <style>
            table {{
            margin-left: 20px
                color: #333; /* Lighten up font color */
                font-family: Helvetica, Arial, sans-serif; /* Nicer font */
                width: 500px;
                background: #eaebec; /* Lighter grey background */
                border-collapse: collapse; /* This will give the table a border */
                border: 1px solid black; /* This will give the table a border */
                position:margin-left;
            }}

            td, th {{
                border: 1px solid #ddd; /* This will give the cells a border */
                height: 20px; 
                transition: all 0.3s;  /* Simple transition for hover effect */
            }}

            th {{
                background: #D14836; /* Darken header a bit */
                color: white;
                text-align: center;
            }}

            td {{
                background: #FAFAFA; /* Lighter grey background */
                text-align: center; /* Center our text */
            }}
        </style>
    </head>
    <body>
        <p>Dear Sir,<br><p/> 
        <p>Please find the attachment. </p>
    
        {html_table} 
               
        <p> Thanks & Regards,<br>
            Internal Audit Department<br>
            Manappuram Finance Limited<br>
            A.O Valapad,Thrissur.<br>
            <br>
            <i>(Please do not reply to this email ID as this is an automatically generated email and reply to this ID is not being monitored).</i></p>
        
        </body>
    </html>
    """  



    # with open(r"C:\\Users\\398504\\CRF\\crf26\\122958-Daily_report_for_customer_modification\\Customer_Modification_report.png", 'rb') as img:
    #     maintype, subtype = mimetypes.guess_type(img.name)[0].split('/')
    #     msg.get_payload()[1].add_related(img.read(),
    #                                         maintype=maintype,
    #                                         subtype=subtype,
    #                                         cid=image_cid)


    msg.add_alternative(html_content, subtype='html')
    s.send_message(msg)
    s.quit()
    print("Mail sent")
    print("Final section completed successfully.............")
  
    
    print("final section completed sucessfully.............")

    print("Image removed")
else:
    print("                                                                     ")
    print("                                                                     ")
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!NO DATA IN DB TABLE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        
