from tableau_api_lib import TableauServerConnection
from tableau_api_lib.utils import querying
from tableau_api_lib.utils.common import flatten_dict_column
import pandas as pd
import xlrd
from pandas import ExcelWriter
import cx_Oracle
import openpyxl
from email.message import EmailMessage
from openpyxl.styles import PatternFill,Font
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side
from openpyxl import load_workbook
import smtplib
from datetime import datetime, timedelta
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.styles import Color
yesterday = datetime.now() - timedelta(days=1)
yesterday_date = yesterday.strftime('%d-%m-%Y')
tableau_server_config = {
        'my_env': {
            'server': 'https://reports.manappuram.com',
            'api_version': "3.17",
            'username': 'tableauadministrator',
            'password': 'M@fil@123',
            'site_name': 'Default',
            'site_url': ''
        }
    }
conn = TableauServerConnection(tableau_server_config, env='my_env',ssl_verify=False)
conn.sign_in()

site_views_df = querying.get_views_dataframe(conn)
site_views_df

site_views_detailed_df = flatten_dict_column(site_views_df, keys=['name', 'id'],col_name='workbook')
site_views_detailed_df

relevant_views_df = site_views_detailed_df[site_views_detailed_df['workbook_name'] == 'Collection Mis MSME']
relevant_views_df

relevant_views_df = site_views_detailed_df[site_views_detailed_df['workbook_name'] == 'Collection Mis MSME']['id']
relevant_views_df 

a1='3d72053d-8c9d-44d8-a19e-772ae0353c1f'
a1

view_data_raw_State_wise_Emi = querying.get_view_data_dataframe(conn,a1)
view_data_raw_State_wise_Emi

view_data_raw_State_wise_Emi = view_data_raw_State_wise_Emi.pivot(index=['MONTHS'], columns=['YEAR','Measure Names'], values='Measure Values')
view_data_raw_State_wise_Emi

def shift_row_to_bottom(df,index_to_shift):
    idx = [i for i in df.index if i!= index_to_shift]
    return df.loc[idx+[index_to_shift]]
ist = shift_row_to_bottom(view_data_raw_State_wise_Emi,('All'))
ist

a2='b50ebeda-ba59-4696-bcd2-b0501b057963'
a2

view_data_raw_State_wise_Emi1 = querying.get_view_data_dataframe(conn,a2)
view_data_raw_State_wise_Emi1

view_data_raw_State_wise_Emi1 = view_data_raw_State_wise_Emi1.pivot(index=['MONTHS'], columns=['YEAR','Measure Names'], values='Measure Values')
view_data_raw_State_wise_Emi1

def shift_row_to_bottom(df,index_to_shift):
    idx = [i for i in df.index if i!= index_to_shift]
    return df.loc[idx+[index_to_shift]]
ist1 = shift_row_to_bottom(view_data_raw_State_wise_Emi1,('All'))
ist1

a3="4669dc41-0351-4bdb-9678-4b5ea13cf737"
a3

view_data_raw_State_wise_Emi3 = querying.get_view_data_dataframe(conn,a3)
view_data_raw_State_wise_Emi3

view_data_raw_State_wise_Emi3 = view_data_raw_State_wise_Emi3.pivot(index=['MONTHS'], columns=['YEAR','Measure Names'], values='Measure Values')
view_data_raw_State_wise_Emi3

def shift_row_to_bottom(df,index_to_shift):
    idx = [i for i in df.index if i!= index_to_shift]
    return df.loc[idx+[index_to_shift]]
ist2 = shift_row_to_bottom(view_data_raw_State_wise_Emi3,('All'))
ist2

a4='5c2f1e39-932e-4aad-8b5b-f1a79ce03633'
a4

view_data_raw_State_wise_Emi4 = querying.get_view_data_dataframe(conn,a4)
view_data_raw_State_wise_Emi4

view_data_raw_State_wise_Emi4 = view_data_raw_State_wise_Emi4.pivot(index=['MONTHS'], columns=['YEAR','Measure Names'], values='Measure Values')
view_data_raw_State_wise_Emi4

def shift_row_to_bottom(df,index_to_shift):
    idx = [i for i in df.index if i!= index_to_shift]
    return df.loc[idx+[index_to_shift]]
ist3 = shift_row_to_bottom(view_data_raw_State_wise_Emi4,('All'))
ist3

a5='e3e1c7a6-bd44-4bde-8636-64e678d9b725'
a5

view_data_raw_State_wise_Emi5 = querying.get_view_data_dataframe(conn,a5)
view_data_raw_State_wise_Emi5

view_data_raw_State_wise_Emi5 = view_data_raw_State_wise_Emi5.pivot(index=['MONTHS'], columns=['YEAR','Measure Names'], values='Measure Values')
view_data_raw_State_wise_Emi5

def shift_row_to_bottom(df,index_to_shift):
    idx = [i for i in df.index if i!= index_to_shift]
    return df.loc[idx+[index_to_shift]]
ist4 = shift_row_to_bottom(view_data_raw_State_wise_Emi5,('All'))
ist4

a6='8282ad4e-46e9-4450-b366-a8aa7e82db0a'
a6

view_data_raw_State_wise_Emi6 = querying.get_view_data_dataframe(conn,a6)
view_data_raw_State_wise_Emi6


view_data_raw_State_wise_Emi6 = view_data_raw_State_wise_Emi6.pivot(index=['MONTHS'], columns=['YEAR','Measure Names'], values='Measure Values')
view_data_raw_State_wise_Emi6


def shift_row_to_bottom(df,index_to_shift):
    idx = [i for i in df.index if i!= index_to_shift]
    return df.loc[idx+[index_to_shift]]
ist5 = shift_row_to_bottom(view_data_raw_State_wise_Emi6,('All'))
ist5

a7='029e0d92-7c75-47ff-93f8-1c2a65c7c410'
a7

view_data_raw_State_wise_Emi7 = querying.get_view_data_dataframe(conn,a7)
view_data_raw_State_wise_Emi7


df_transposed = view_data_raw_State_wise_Emi7.transpose()
# or
df_transposed = view_data_raw_State_wise_Emi7.T
df_transposed


a8='2d002b48-0629-4e11-824c-7a9492ee3891'
a8

view_data_raw_State_wise_Emi8 = querying.get_view_data_dataframe(conn,a8)
view_data_raw_State_wise_Emi8

df_transposed1 = view_data_raw_State_wise_Emi8.transpose()
# or
df_transposed1 = view_data_raw_State_wise_Emi8.T
df_transposed1

# c1='5b4eb525-2ff3-48c5-8a58-73c179f0e08d'
# c1
# y1 = querying.get_view_data_dataframe(conn,c1)
# y1
# y1 = y1.pivot(index=['% on Dis'], columns=['YEAR','Measure Names'], values='Measure Values')
# y1

# c2='2d1b8b58-e85c-4b48-881d-ec7d963ae404'
# c2
# y2 = querying.get_view_data_dataframe(conn,c2)
# y2
# y2 = y2.pivot(index=['% on live'], columns=['YEAR','Measure Names'], values='Measure Values')
# y2

# c3='e910c734-e2ad-41c6-9787-4e5dacb5ab57'
# # c2
# y3 = querying.get_view_data_dataframe(conn,c3)
# # y3
# y3 = y3.pivot(index=['% on Dis'], columns=['YEAR','Measure Names'], values='Measure Values')
# y3

# c4='242750f8-cf17-43f8-9fed-8ce331bacf2d'
# # c2
# y4 = querying.get_view_data_dataframe(conn,c4)
# # y4
# y4 = y4.pivot(index=['% on live'], columns=['YEAR','Measure Names'], values='Measure Values')
# y4
a9='06fdeb3e-c2f9-4cdb-bf13-6e9152b0d8cf'
a9

view_data_raw_State_wise_Emi9 = querying.get_view_data_dataframe(conn,a9)
view_data_raw_State_wise_Emi9

df_transposed2 = view_data_raw_State_wise_Emi9.transpose()
# or
df_transposed2 = view_data_raw_State_wise_Emi9.T
df_transposed2

a10='00acfbb8-b5a9-4b5c-9461-ccb5cd39ca2b'
a10

view_data_raw_State_wise_Emi10 = querying.get_view_data_dataframe(conn,a10)
view_data_raw_State_wise_Emi10

df_transposed3 = view_data_raw_State_wise_Emi10.transpose()
# or
df_transposed3 = view_data_raw_State_wise_Emi10.T
df_transposed3

a11='5b4eb525-2ff3-48c5-8a58-73c179f0e08d'
a11


view_data_raw_State_wise_Emi11 = querying.get_view_data_dataframe(conn,a11)
view_data_raw_State_wise_Emi11


view_data_raw_State_wise_Emi11 = view_data_raw_State_wise_Emi11.pivot(index=['Percentage'], columns=['YEAR','Measure Names'], values='Measure Values')
view_data_raw_State_wise_Emi11


a12='e910c734-e2ad-41c6-9787-4e5dacb5ab57'
a12


view_data_raw_State_wise_Emi12 = querying.get_view_data_dataframe(conn,a12)
view_data_raw_State_wise_Emi12


view_data_raw_State_wise_Emi12 = view_data_raw_State_wise_Emi12.pivot(index=['Percentage'], columns=['YEAR','Measure Names'], values='Measure Values')
view_data_raw_State_wise_Emi12

a13='b52d49b7-4735-47d5-8815-263851eb0b23'
a13

view_data_raw_State_wise_Emi13 = querying.get_view_data_dataframe(conn,a13)
view_data_raw_State_wise_Emi13

a14='2d1b8b58-e85c-4b48-881d-ec7d963ae404'
a14


view_data_raw_State_wise_Emi14 = querying.get_view_data_dataframe(conn,a14)
view_data_raw_State_wise_Emi14


view_data_raw_State_wise_Emi14 = view_data_raw_State_wise_Emi14.pivot(index=['Live'], columns=['YEAR','Measure Names'], values='Measure Values')
view_data_raw_State_wise_Emi14


a15='242750f8-cf17-43f8-9fed-8ce331bacf2d'
a15


view_data_raw_State_wise_Emi15 = querying.get_view_data_dataframe(conn,a15)
view_data_raw_State_wise_Emi15


view_data_raw_State_wise_Emi15 = view_data_raw_State_wise_Emi15.pivot(index=['Live'], columns=['YEAR','Measure Names'], values='Measure Values')
view_data_raw_State_wise_Emi15




writer1 = pd.ExcelWriter(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx",engine="openpyxl")

ist2.to_excel(writer1,sheet_name="NPA",index=True)
ist4.to_excel(writer1,sheet_name="DELIN",index=True)
ist.to_excel(writer1,sheet_name="Bucket wise count",index=True)
ist1.to_excel(writer1,sheet_name="Bucket wise amt",index=True)
view_data_raw_State_wise_Emi13.to_excel(writer1,sheet_name="Disbursement",index=False)
writer1.save()
writer2 = pd.ExcelWriter(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Total.xlsx",engine="openpyxl")
df_transposed.to_excel(writer2,sheet_name="Total Count",index=False)
df_transposed1.to_excel(writer2,sheet_name="Total amt",index=False)
# y1.to_excel(writer2,sheet_name="per dis count",index=True)
# y2.to_excel(writer2,sheet_name="per live count",index=True)
# y3.to_excel(writer2,sheet_name="per dis amt",index=True)
# y4.to_excel(writer2,sheet_name="per live amt",index=True)
df_transposed2.to_excel(writer2,sheet_name="NPA TOTAL",index=False)
df_transposed3.to_excel(writer2,sheet_name="DELIN TOTAL",index=False)    

view_data_raw_State_wise_Emi11.to_excel(writer2,sheet_name="% on Count Disbursement",index=True)
view_data_raw_State_wise_Emi12.to_excel(writer2,sheet_name="% amount Disbursement",index=True)
view_data_raw_State_wise_Emi14.to_excel(writer2,sheet_name="%  on Count Live",index=True)
view_data_raw_State_wise_Emi15.to_excel(writer2,sheet_name="% on Amt Live",index=True)
writer2.save()


# PERCENTAGE
source_wb25 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Total.xlsx")
dest_wb25 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

# Get the source and destination sheets
source_sheet25 = source_wb25['% on Count Disbursement']
dest_sheet25 = dest_wb25['Bucket wise count']

# Copy the data from the source sheet
for row in source_sheet25.iter_rows(values_only=True):
    dest_sheet25.append(row)

dest_wb25.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

# PERCENTAGE
source_wb26 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Total.xlsx")
dest_wb26 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

# Get the source and destination sheets
source_sheet26 = source_wb26['%  on Count Live']
dest_sheet26 = dest_wb26['Bucket wise count']

# Copy the data from the source sheet
for row in source_sheet26.iter_rows(values_only=True):
    dest_sheet26.append(row)

dest_wb26.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

# PERCENTAGE
source_wb27 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Total.xlsx")
dest_wb27 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

# Get the source and destination sheets
source_sheet27 = source_wb27['% amount Disbursement']
dest_sheet27 = dest_wb27['Bucket wise amt']

# Copy the data from the source sheet
for row in source_sheet27.iter_rows(values_only=True):
    dest_sheet27.append(row)

dest_wb27.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

# PERCENTAGE
source_wb28 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Total.xlsx")
dest_wb28 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

# Get the source and destination sheets
source_sheet28 = source_wb28['% on Amt Live']
dest_sheet28 = dest_wb28['Bucket wise amt']

# Copy the data from the source sheet
for row in source_sheet28.iter_rows(values_only=True):
    dest_sheet28.append(row)

dest_wb28.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")
        
workbook = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))

sheet_names = workbook.sheetnames
sh_names1 = ['Bucket wise count','Bucket wise amt']
for sheet_name in sheet_names:
    if sheet_name in sh_names1:
        sheet = workbook[sheet_name]
        for row in sheet.iter_rows():
            for cell in row:
                  if cell.value=='YEAR':
                        cell.value = ' '
                  elif cell.value=='Measure Names':
                       cell.value = 'Months'
                  elif cell.value=='All':
                       cell.value = 'Total'
                       
        for row in sheet.iter_rows(min_row=3,max_row=3):
             sheet.delete_rows(row[0].row)
        for row in sheet.iter_rows(min_row=16,max_row=19):
             sheet.delete_rows(row[0].row)
        for row in sheet.iter_rows(min_row=16,max_row=16):
             sheet.delete_rows(row[0].row)
        for row in sheet.iter_rows(min_row=17,max_row=17):
             sheet.delete_rows(row[0].row)
        total_row_number = None
        for row in sheet.iter_rows():
            for cell in row:
                if cell.value == 'Total':
                    total_row_number = cell.row
                    for cell in sheet[total_row_number]:
                        font = Font(color="000000", bold=True)  # Set the font color to white
                        cell.font = font
                    # fill = openpyxl.styles.PatternFill(start_color="9A3B3B", end_color="9A3B3B", fill_type="solid") # Main heading
                    # row.fill = fill
                    break
            if total_row_number is not None:
                break
        for row in sheet.iter_rows(min_row=2, max_row=total_row_number):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(2, 11):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="d9e7fa", end_color="d9e7fa", fill_type="solid")

                for col in range(11, 20):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="f7dfe3", end_color="f7dfe3", fill_type="solid")

                for col in range(20, 29):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="d9e7fa", end_color="d9e7fa", fill_type="solid")

                for col in range(29, 38):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="f7dfe3", end_color="f7dfe3", fill_type="solid")

                for col in range(38, 47):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="d9e7fa", end_color="d9e7fa", fill_type="solid")
        for row in sheet.iter_rows(min_row=1, max_row=total_row_number):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
        for row in sheet.iter_rows(min_row=total_row_number, max_row=total_row_number):
            for cell in row:
                cell.fill = openpyxl.styles.PatternFill(start_color="0d0d3b", end_color="0d0d3b", fill_type="solid")
                font = Font(color="ffffff", bold=True)  # Set the font color to white
                cell.font = font
        for row in sheet.iter_rows(min_row=1, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
        
        for cell in sheet[2]:
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        for row in sheet.iter_rows(min_row=total_row_number+1, max_row=total_row_number+2):
            for cell in row:
                for col in range(1,1):
                    cell.fill = openpyxl.styles.PatternFill(start_color="e6edf7", end_color="e6edf7", fill_type="solid")

        merge_range6 = f"A{total_row_number+5}:I{total_row_number+5}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+5, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+5, column=1)
        merged_cell6.value = 'GRAND TOTAL'
        font = Font(color="ff0000", bold=True)  # Set the font color to white
        merged_cells6.font = font

        
        
workbook.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

# Load the source and destination workbooks
source_wb5 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Total.xlsx")
dest_wb5 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

# Get the source and destination sheets
source_sheet5 = source_wb5['Total Count']
dest_sheet5 = dest_wb5['Bucket wise count']

# Copy the data from the source sheet
for row in source_sheet5.iter_rows(values_only=True):
    dest_sheet5.append(row)
dest_wb5.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

source_wb4 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Total.xlsx")
dest_wb4 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")
# Get the source and destination sheets
source_sheet4 = source_wb4['Total amt']
dest_sheet4 = dest_wb4['Bucket wise amt']

# Copy the data from the source sheet
for row in source_sheet4.iter_rows(values_only=True):
    dest_sheet4.append(row)
            
#Save the destination workbook
dest_wb4.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

workbook = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))

sheet_names = workbook.sheetnames
sh_names1 = ['Bucket wise count','Bucket wise amt']
for sheet_name in sheet_names:
    if sheet_name in sh_names1:
        sheet = workbook[sheet_name]
        for row in sheet.iter_rows(min_row=total_row_number+5, max_row=total_row_number+8):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
        for row in sheet.iter_rows(min_row=total_row_number+6, max_row=total_row_number+6):
            sheet.delete_rows(row[0].row)
        for row in sheet.iter_rows(min_row=total_row_number+5, max_row=total_row_number+7):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 10):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.border = border_style
        for cell in sheet[total_row_number+6]:
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        for row in sheet.iter_rows(min_row=total_row_number+6, max_row=total_row_number+6):
            for col in range(1, 10):  # Specify the range of columns (A to I)
                cell = sheet.cell(row=cell.row, column=col)
                cell.fill = openpyxl.styles.PatternFill(start_color="ab620f", end_color="ab620f", fill_type="solid")
                font = Font(color="ffffff", bold=True)  # Set the font color to white
                cell.font = font
        for row in sheet.iter_rows():
            for cell in row:
                  if cell.value=='Percantage of loan amount(Delin)':
                        cell.value = '% on Loan amt'
                  else:
                      continue

        # adjusting column width
        for col in range(2, 47):
            column_letter = get_column_letter(col)
            sheet.column_dimensions[column_letter].width = 14
        for row in sheet.iter_rows(min_row=total_row_number+1, max_row=total_row_number+2):
            for cell in row:
                if cell.value is not None:
                    cell.value = str(cell.value) + '%'

        
workbook.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

################################################------NPA/DELIN------###################################################################




workbook = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))

sheet_names = workbook.sheetnames
sh_names1 = ['NPA','DELIN']
for sheet_name in sheet_names:
    if sheet_name in sh_names1:
        sheet = workbook[sheet_name]
        for row in sheet.iter_rows():
            for cell in row:
                if cell.value=='YEAR':
                    cell.value = ' '
                elif cell.value=='Measure Names':
                    cell.value = 'Months'
                elif cell.value=='All':
                    cell.value = 'Total'
                # # elif cell.value=='Percantage of loan amount(npa)':
                # #     cell.value = '% of Loan amount'
                # elif cell.value=='Percantage of loan amount(Delin)':
                #     cell.value = '% of Loan amount'
                else:
                    continue
                
                       
        for row in sheet.iter_rows(min_row=3,max_row=3):
             sheet.delete_rows(row[0].row)
        total_row_number = None
        for row in sheet.iter_rows():
            for cell in row:
                if cell.value == 'Total':
                    total_row_number = cell.row
                    ##_______Conditional formatting___________
                    # start_row = 4  # Assuming row 1 is the header
                    # end_row = total_row_number-1
                    # columns_to_format = ['D', 'H', 'L','P','T']  # Replace with the column letters you want to format

                    # for col in columns_to_format:
                    #     min_col = f"{col}{start_row}"
                    #     max_col = f"{col}{end_row}"

                    #     # Create a color scale rule
                    #     color_scale_rule = ColorScaleRule(start_type="min", start_color=Color(rgb="7ae67a"),
                    #                         mid_type="percentile", mid_value=50, mid_color=Color(rgb="ffd966"),
                    #                         end_type="max", end_color=Color(rgb="e56666"))

                    #     # Apply the color scale rule to the specified range
                    #     sheet.conditional_formatting.add(f"{min_col}:{max_col}", color_scale_rule)
                        ###########__________________________########################
                    for cell in sheet[total_row_number]:
                        font = Font(color="000000", bold=True)  # Set the font color to white
                        cell.font = font
                    # fill = openpyxl.styles.PatternFill(start_color="9A3B3B", end_color="9A3B3B", fill_type="solid") # Main heading
                    # row.fill = fill
                    break
            if total_row_number is not None:
                break
        for row in sheet.iter_rows(min_row=2, max_row=total_row_number):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(2, 5):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="d9e7fa", end_color="d9e7fa", fill_type="solid")

                for col in range(5, 8):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="f7dfe3", end_color="f7dfe3", fill_type="solid")

                for col in range(8, 11):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="d9e7fa", end_color="d9e7fa", fill_type="solid")

                for col in range(11, 14):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="f7dfe3", end_color="f7dfe3", fill_type="solid")

                for col in range(14, 17):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="d9e7fa", end_color="d9e7fa", fill_type="solid")
        for row in sheet.iter_rows(min_row=1, max_row=total_row_number):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
        for row in sheet.iter_rows(min_row=total_row_number, max_row=total_row_number):
            for cell in row:
                cell.fill = openpyxl.styles.PatternFill(start_color="0d0d3b", end_color="0d0d3b", fill_type="solid")
                font = Font(color="ffffff", bold=True)  # Set the font color to white
                cell.font = font
        for row in sheet.iter_rows(min_row=1, max_row=total_row_number):
            for cell in row:
                cell.border = border_style
        for cell in sheet[2]:
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        for col in range(2, 47):
            column_letter = get_column_letter(col)
            sheet.column_dimensions[column_letter].width = 14
        


        merge_range7 = f"A{total_row_number+5}:C{total_row_number+5}"
        sheet.merge_cells(merge_range7)
        merged_cells7 = sheet.cell(row=total_row_number+5, column=1)
        merged_cells7.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell7 = sheet.cell(row=total_row_number+5, column=1)
        merged_cell7.value = 'GRAND TOTAL'
        font = Font(color="ff0000", bold=True)  # Set the font color to white
        merged_cells7.font = font

        
        
workbook.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")


# Load the source and destination workbooks
source_wb15 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Total.xlsx")
dest_wb15 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

# Get the source and destination sheets
source_sheet15 = source_wb15['NPA TOTAL']
dest_sheet15 = dest_wb15['NPA']

# Copy the data from the source sheet
for row in source_sheet15.iter_rows(values_only=True):
    dest_sheet15.append(row)
dest_wb15.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

source_wb14 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Total.xlsx")
dest_wb14 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")
# Get the source and destination sheets
source_sheet14 = source_wb14['DELIN TOTAL']
dest_sheet14 = dest_wb14['DELIN']

# Copy the data from the source sheet
for row in source_sheet14.iter_rows(values_only=True):
    dest_sheet14.append(row)
            
#Save the destination workbook
dest_wb14.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

workbook = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))

sheet_names = workbook.sheetnames
sh_names1 = ['NPA','DELIN']
for sheet_name in sheet_names:
    if sheet_name in sh_names1:
        sheet = workbook[sheet_name]
        for row in sheet.iter_rows(min_row=total_row_number+5, max_row=total_row_number+9):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
        for row in sheet.iter_rows(min_row=total_row_number+6, max_row=total_row_number+6):
            sheet.delete_rows(row[0].row)
        for row in sheet.iter_rows(min_row=total_row_number+5, max_row=total_row_number+7):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 4):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.border = border_style
        for cell in sheet[total_row_number+6]:
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        for row in sheet.iter_rows(min_row=total_row_number+6, max_row=total_row_number+6):
            for col in range(1, 4):  # Specify the range of columns (A to I)
                cell = sheet.cell(row=cell.row, column=col)
                cell.fill = openpyxl.styles.PatternFill(start_color="ab620f", end_color="ab620f", fill_type="solid")     
                font = Font(color="ffffff", bold=True)  # Set the font color to white
                cell.font = font
        for row in sheet.iter_rows():
            for cell in row:
                  if cell.value=='Percantage of loan amount(npa)':
                        cell.value = '% on Loan amt'
                  elif cell.value=='Percantage of loan amount(Delin)':
                    cell.value = '% of Loan amount'
                  else:
                      continue
                #   elif cell.value=='Measure Names':
                #        cell.value = 'Months'
                #   elif cell.value=='All':
                #        cell.value = 'Total'
                #   elif cell.value=='Percantage of loan amount(npa)':
                #        cell.value = '% of Loan amount'
                #   elif cell.value=='Percantage of loan amount(Delin)':
                #        cell.value = '% of Loan amount'

        

workbook.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")


###############################-------------Disbursement---------------------############################
workbook = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))

sheet_names = workbook.sheetnames

for sheet_name in sheet_names:
    if sheet_name=='Disbursement':
        sheet = workbook[sheet_name]
        for cell in sheet[2]:
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 25):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="d9e7fa", end_color="d9e7fa", fill_type="solid")
                for col in range(2, 47):
                    column_letter = get_column_letter(col)
                    sheet.column_dimensions[column_letter].width = 14   
                for col in ['C','F']:
                    sheet.column_dimensions[col].width = 33
                for col in ['L','M','N','v','B','X']:
                    sheet.column_dimensions[col].width = 23
        for row in sheet.iter_rows():
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                cell.border = border_style
workbook.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")
#######################################----%%%%%%%%%%%%%%%---------


