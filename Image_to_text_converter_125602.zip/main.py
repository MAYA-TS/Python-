from PIL import Image
import pytesseract
import os
import fitz 






pytesseract.pytesseract.tesseract_cmd = r'C:\\Users\\359541\\AppData\\Local\\Programs\\Tesseract-OCR\\tesseract.exe'


input_dir = r'C:\\IMAGE TO TEST\\image\\'
output_dir = r'C:\\IMAGE TO TEST\\output\\'
os.makedirs(output_dir, exist_ok=True)


for filename in os.listdir(input_dir):
    file_path = os.path.join(input_dir, filename)
    
    if filename.endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp', '.gif')):
      
        image = Image.open(file_path)
        text = pytesseract.image_to_string(image)
        image.close()  
        
    elif filename.endswith('.pdf'):
       
        doc = fitz.open(file_path)
        text = ""
        for page_num in range(len(doc)):
            page = doc.load_page(page_num)
            text += page.get_text()
        doc.close()  
    
    else:
        
        continue


    file_name = os.path.splitext(filename)[0]


   
    output_file_path = os.path.join(output_dir, f'{file_name}.txt')


  
    with open(output_file_path, 'w', encoding='utf-8') as file:
        file.write(text)


    # os.remove(file_path)


    print(f'Text extracted and saved to: {output_file_path}')
    # print(f'Input file {file_path} has been removed.')


