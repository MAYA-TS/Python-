from email.message import EmailMessage
import os
import shutil
import time
import openpyxl
from openpyxl.styles import Border,Side,Font,PatternFill,Alignment
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from openpyxl.utils import get_column_letter

import pandas as pd
import pandas as pd
import smtplib

def data():
    driver = webdriver.Edge()  # Ensure you have the correct driver
    driver.maximize_window()

    # Navigate to the login page
    driver.get("https://reports.manappuram.com/#/workbooks/1944")

    time.sleep(35)
    wait = WebDriverWait(driver, 20)
    # Find the login form elements
    username_field = driver.find_element(By.NAME, 'username')
    password_field = driver.find_element(By.NAME, 'password')

    username_field.send_keys('357274')
    password_field.send_keys('May@123')

    # Submit the form
    password_field.send_keys(Keys.RETURN)
    time.sleep(40)

    def download_report(report_url):
        driver.get(report_url)
        time.sleep(45)  
       
        iframe_element = wait.until(EC.presence_of_element_located((By.TAG_NAME, "iframe")))
        driver.switch_to.frame(iframe_element)
       
        button_element = wait.until(EC.element_to_be_clickable((By.ID, "download")))
        button_element.click()
        time.sleep(45)
       
        # Select crosstab option
        element = wait.until(EC.element_to_be_clickable((By.XPATH, "//div[@data-tb-test-id='download-flyout-download-crosstab-MenuItem']")))
        element.click()

        # Select the download button
        time.sleep(45)
        element2 = wait.until(EC.element_to_be_clickable((By.XPATH, "//div[@class='fdr6v0d']//button")))
        element2.click()

        time.sleep(45)
        driver.switch_to.default_content()

    # # Download the first report
    download_report("http://reports.manappuram.com//#/redirect_to_view/12899")
    # Download the second report
    download_report("http://reports.manappuram.com//#/redirect_to_view/12901")
    # # Download the third report
    download_report("http://reports.manappuram.com//#/redirect_to_view/12903")
    # Download the fourth report
    download_report("http://reports.manappuram.com//#/redirect_to_view/12905")
    # # Download the fifth report
    download_report("http://reports.manappuram.com//#/redirect_to_view/12908")

data()
print("Excel downloaded 'OK'")
pass

def move_excel_files(source_folder, destination_folder, file_names):
    for file_name in file_names:
        source_file_path = os.path.join(source_folder, file_name)
        if os.path.isfile(source_file_path) and file_name.endswith('.xlsx'):
            destination_file_path = os.path.join(destination_folder, file_name)
            shutil.move(source_file_path, destination_file_path)
        else:
            print(f"File not found or not an Excel file: {file_name}")

source_folder = os.path.expanduser('~/Downloads')  
destination_folder = r'D:\CRF\Abnormal_growth_verification_124420'  
file_names = ["summary Report 1st Verification.xlsx","summary Report 2nd Verification.xlsx","summary Report 3rd  Verification.xlsx","summary Report  4th Verification.xlsx","summary Report  5th Verification.xlsx"]

if not os.path.exists(destination_folder):
    os.makedirs(destination_folder)  
move_excel_files(source_folder, destination_folder, file_names)
print("Excel moved 'OK'")

def merge_excels(file_names, output_file):
    writer = pd.ExcelWriter(output_file, engine='openpyxl')
   
    for file in file_names:
        df = pd.read_excel(file)
        sheet_name = os.path.splitext(os.path.basename(file))[0]
        df.to_excel(writer, sheet_name=sheet_name, index=False)
   
    writer.save()
    writer.close()

merged_file = r'D:\\CRF\\Abnormal_growth_verification_124420\\Abnormal_growth_Report.xlsx'
merge_excels([os.path.join(destination_folder, file_name) for file_name in file_names], merged_file)
print("Excel merged 'OK'")

#===============================Excel design============================================================

workbook = openpyxl.load_workbook("D:\\CRF\\Abnormal_growth_verification_124420\\Abnormal_growth_Report.xlsx")
sheet_names = workbook.sheetnames
heading_color =  '070F2B'    #'73BCC5'#'8080ff'  # Red color
body_color = 'FFFFFF'  # Green color
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
 
 
for sheet_name in sheet_names:
    sheet = workbook[sheet_name]
    header_font = Font(color="ffffff", bold=True)
    header_fill = PatternFill(start_color='070F2B', end_color='070F2B', fill_type='solid')
    for cell in sheet[1]:
        cell.fill = header_fill
        cell.font = header_font
    body_fill = PatternFill(start_color=body_color, end_color=body_color, fill_type='solid')
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            cell.fill = body_fill
           
    for column in sheet.columns:
        non_empty_values = [cell.value for cell in column if cell.value]
        if non_empty_values:
            max_length = max(len(str(value)) for value in non_empty_values)
            column_letter = get_column_letter(column[0].column)
            adjusted_width = (max_length + 2) * 1.1  # Adjust the width as desired
            sheet.column_dimensions[column_letter].width = adjusted_width
    for row in sheet.rows:
        max_height = max(str(cell.value).count('\n') + 1 for cell in row if cell.value)
        row_number = row[0].row
        adjusted_height = max_height * 17 # Adjust the height as desired
        sheet.row_dimensions[row_number].height = adjusted_height
    for row in sheet.iter_rows():
        for cell in row:
            cell.alignment = Alignment(horizontal='center', vertical='center')
    for row in sheet.iter_rows():
        for cell in row:
            cell.border = border_style
workbook.save("D:\\CRF\\Abnormal_growth_verification_124420\\Abnormal_growth_Report.xlsx")
print("Excel designed 'OK'")

# # =================================Email part===========================================================
s = smtplib.SMTP(host='smtp.office365.com', port=587)
s.starttls()

s.login('iotautomation@manappuram.com', 'ybjmxbfdyzkdnjtw')
msg = EmailMessage()

print("Ready for mailing")

msg['Subject'] = 'Abnormal growth verification report'
msg['From'] ='iot <iotautomation@manappuram.com>'

# msg['From'] ='INTERNAL AUDIT <internalaudit1@manappuram.com>'
# msg['To']='sravan<iotsupport12@manappuram.com>'
# msg['Cc'] ='sravan<iotsupport12@manappuram.com>'

msg['To']='megha<sm3operations@manappuram.com>'
msg['Cc'] ='sravan<iotsupport12@manappuram.com>','prajith<am7dataservice@manappuram.com>','maya<iotsupport7@manappuram.com>'


# msg['To']='Branch Audit <branchaudit@manappuram.com>','Audit Research Wing<researchwing@manappuram.com>','MAFIL BRANCH AUDIT<internalaudit@manappuram.com>','JAYESH S V<twaudit@manappuram.com>','MAFIL HO Audit<hoaudit@manappuram.com>',' G M AUDIT<gmaudit@manappuram.com>','HEAD RESEARCHWING<headresearchwing@manappuram.com>','G ALERT AUDIT<glalertsaudit@manappuram>','AGM <agmia@manappuram.com>','CM INTERNALAUDIT<cminternalaudit@manappuram>'
# msg['Cc'] ='RIJU P<gmaudit@manappuram.com>','MAYA T S<iotsupport7@manappuram.com>','SRAVAN T B<iotsupport12@manappuram.com>','Gopika V S<dataservice29@manappuram.com>'
with open(r"D:\\CRF\\Abnormal_growth_verification_124420\\Abnormal_growth_Report.xlsx", 'rb') as ra:
    attachment = ra.read()
msg.add_related(attachment, maintype='application', subtype='xlsx', filename='Abnormal_growth_Report.xlsx')



with open(r"D:\\CRF\\Abnormal_growth_verification_124420\\abnormal exsisting structure.xlsx", 'rb') as ra:
    attachment = ra.read()
msg.add_related(attachment, maintype='application', subtype='xlsx', filename='abnormal exsisting structure.xlsx')



# Modify the HTML content to include a link
msg.add_alternative("""\
    <html>
        <body>
            <p><i>Dear Madam/Sir,</i></p>
            <p> </p>
            <p><i>Please find the attachment</i></p>
            <p>For more details, please visit the following link: 
                <a href="https://reports.manappuram.com/#/workbooks/1944/views">Click here</a>
            </p>
            <p></p>
            <p><i>Thanks & Regards,<br>
                (This is an autogenerated mail)<br>
                R&D <br>
            </i></p>
        </body>
    </html>
    """, subtype='html')

# Send the email
s.send_message(msg)

print("Mail sent")

# Remove the files after sending the email
os.remove("D:\\CRF\\Abnormal_growth_verification_124420\\Abnormal_growth_Report.xlsx")
print("Set Set")
