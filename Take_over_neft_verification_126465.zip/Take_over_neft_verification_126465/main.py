import pandas as pd
import cx_Oracle
import openpyxl
from email.message import EmailMessage
from email.utils import make_msgid
import pandas as pd
from openpyxl.styles import PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side
import smtplib

conn = cx_Oracle.connect("", "", "")
print("Oracle database connected")

df1=pd.read_sql( """SELECT  aa. FZM,
    count(cust_id) total_count,
    COUNT(CASE WHEN verified_dt IS NULL AND reject_date IS NULL THEN cust_id END) pending,
    COUNT(CASE WHEN diff < 1 THEN cust_id END) AS less_than_1_min,
    COUNT(CASE WHEN diff >= 1 AND diff < 5 THEN cust_id END) AS between_1_5_min,
    COUNT(CASE WHEN diff >= 5 AND diff < 10 THEN cust_id END) AS between_5_10_min,
    COUNT(CASE WHEN diff >= 10 AND diff < 15 THEN cust_id END) AS between_10_15_min,
    COUNT(CASE WHEN diff >= 15 THEN cust_id END) AS above_15_min
   
FROM (
    SELECT distinct
        t.reject_date,
        t.verified_dt,
        b.zonal_name,
        C.FZM,
        t.cust_id,
        (nvl(t.reject_date , t.verified_dt)-h.insert_dt )* 24 * 60 AS diff
    FROM
        mana0809.neft_customer_history@uatr_backup2 t,
        mana0809.branch_detail@uatr_backup2 b,
        MANA0809.TBL_FZM_MASTER@UATR_BACKUP2 C,
        mana0809.tbl_takeover_neft_req@uatr_backup2 h
    WHERE
        t.moduleid = 141
        AND t.branch_id = b.branch_id
        AND h.to_cust_id = t.cust_id
        AND B.REG_ID=C.REGION_ID
        AND TO_DATE(t.tra_dt) = TO_DATE(SYSDATE)
) aa
GROUP BY
    aa.FZM""",con=conn)
print("df1 completed---------------------------------------------------")


df2=pd.read_sql("""select distinct t.cust_name,
        t.cust_id,
        b.branch_name,
        t.branch_id,
        b.area_name,
        b.zonal_name,
        b.reg_name,
        h.insert_dt     requested_date,
        T.VERIFIED_DT   APPROVED_DT,
        t.verify_status Approval_status ,
        t.reject_reason,
        t.remark,
        t.reject_user   approved_person_emp_code,
        d.emp_name      approved_person_name
   from mana0809.tbl_takeover_neft_req@uatr_backup2 h,
        mana0809.neft_customer_history@uatr_backup2 t,
        mana0809.branch_detail@uatr_backup2         b,
        mana0809.emp_master@uatr_backup2            d
  where t.branch_id = b.branch_id
    and d.emp_code = t.reject_user
    and t.moduleid = 141
    and h.to_cust_id = t.cust_id
    and to_date(t.tra_dt) = to_date(sysdate) """,con=conn)
        
print("df2 completed---------------------------------------------------")

   
print("Query section completed...........")


writer=pd.ExcelWriter("D:\\CRF\\Take_over_neft_verification_126465\\Take_over_neft_verification_report.xlsx",engine="openpyxl")
df1.to_excel(writer, sheet_name="COUNT", index=False)
df2.to_excel(writer, sheet_name="SUMMARY", index=False)



print("saved as excel")
writer.save()
print("Excel downloading section completed............")

workbook = openpyxl.load_workbook('D:\\CRF\\Take_over_neft_verification_126465\\Take_over_neft_verification_report.xlsx')
sheet_names = workbook.sheetnames
heading_color =  '4CC417'    #'73BCC5'#'8080ff'  # Red color
body_color = 'DADBDD'  # Green color
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))


for sheet_name in sheet_names:
    sheet = workbook[sheet_name]
    header_fill = PatternFill(start_color='4CC417', end_color='4CC417', fill_type='solid')
    for cell in sheet[1]:
        cell.fill = header_fill
    body_fill = PatternFill(start_color=body_color, end_color=body_color, fill_type='solid')
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            cell.fill = body_fill
    for column in sheet.columns:
        non_empty_values = [cell.value for cell in column if cell.value]
        if non_empty_values:
            max_length = max(len(str(value)) for value in non_empty_values)
            column_letter = get_column_letter(column[0].column)
            adjusted_width = (max_length + 2) * 1.2  # Adjust the width as desired
            sheet.column_dimensions[column_letter].width = adjusted_width
    for row in sheet.rows:
        max_height = max(str(cell.value).count('\n') + 1 for cell in row if cell.value)
        row_number = row[0].row
        adjusted_height = max_height * 17 # Adjust the height as desired
        sheet.row_dimensions[row_number].height = adjusted_height
    for row in sheet.iter_rows():
        for cell in row:
            cell.alignment = Alignment(horizontal='center', vertical='center')
    for row in sheet.iter_rows():
        for cell in row:
            cell.border = border_style
workbook.save('D:\\CRF\\Take_over_neft_verification_126465\\Take_over_neft_verification_report.xlsx')
workbook = openpyxl.load_workbook(r'D:\\CRF\\Take_over_neft_verification_126465\\Take_over_neft_verification_report.xlsx')
print("Excel designed")


excel_file_path = 'D:\\CRF\\Take_over_neft_verification_126465\\Take_over_neft_verification_report.xlsx'


s = smtplib.SMTP(host='smtp.office365.com', port=587)
s.starttls()
s.login(' ', '')

msg = EmailMessage()
print("Ready for mailing")

msg['Subject'] = 'Take over neft verification report'
msg['From'] = 'iot <iotautomation@manappuram.com>'
# msg['To'] ='vreesha<itcoordinatorkyc@manappuram.com>'
msg['To'] ='sravan<iotsupport12@manappuram.com>'


with open(r"D:\\CRF\\Take_over_neft_verification_126465\\Take_over_neft_verification_report.xlsx", 'rb') as ra:
    attachment = ra.read()
msg.add_related(attachment, maintype='application', subtype='xlsx', filename='Take_over_neft_verification_report.xlsx')
image_cid = make_msgid(domain='mandala.com')
msg.add_alternative("""\
<html>
    <body>
        <p>Dear Madam,<br><p/>
                    
                
        <p>
        Kindly  verify the Take over neft verification report.
            </p>

        <br>                
        <p> Thanks & Regards,<br>
            Team IoT <br>
            R & D New age technology <br>
            ( This is an autogenerated mail )
        </p>
    </body>
</html>
""",subtype='html')    
                                      

s.send_message(msg)
print("Mail send")
