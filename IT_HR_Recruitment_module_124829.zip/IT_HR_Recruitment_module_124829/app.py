import base64
from datetime import datetime
from flask import Flask, render_template, request
import cx_Oracle

app = Flask(__name__)
def get_db_connection():  
    connection = cx_Oracle.connect('mana0809','mana0809','MAFILUAT')
    return connection


@app.route('/', methods=['GET', 'POST'])
def index():
    from_date = request.form.get('from_date')
    to_date = request.form.get('to_date')
    search_query = request.form.get('search_query')

    query = "SELECT name, district, pg_course, trim(entry_date) FROM interviewtracker_module WHERE 1=1"
    params = {}

    if from_date and to_date:
        query += " AND trim(entry_date) BETWEEN TO_DATE(:from_date, 'YYYY-MM-DD') AND TO_DATE(:to_date, 'YYYY-MM-DD')"
        params['from_date'] = from_date
        params['to_date'] = to_date

    if search_query:
        query += " AND LOWER(pg_course) LIKE LOWER(:search_query)"
        params['search_query'] = f"%{search_query}%"



    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute(query, params)
    data = cursor.fetchall()
    cursor.close()
    connection.close()

    return render_template('index.html', data=data)


@app.route('/candidate/<string:name>', endpoint='candidate')
def candidate_detail(name):
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("SELECT name, email, phone_number,pin_code,address,state,district,gender,age,sslc_details,sslc_percentage,sslc_year,plus_two_details,plus_two_percentage,plus_two_year,ug_course,ug_details,ug_percentage,ug_year,pg_course,pg_details,pg_percentage,pg_year,work_experience,years_of_experience,programming_languages,position,upload_resume,upload_sslc_certificate,upload_plus_two_certificate,upload_ug_certificate,upload_pg_certificate,upload_other_certificates,trim(entry_date) FROM interviewtracker_module WHERE name = :name", {'name': name})
    candidate = cursor.fetchone()  
    if candidate is None:
        cursor.close()
        connection.close()
        return "Candidate not found", 404
    candidate_details = list(candidate)  
    clob_indices = [0, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25,26]  
    for i in clob_indices:
        if isinstance(candidate[i], cx_Oracle.LOB):
            candidate_details[i] = candidate[i].read()
    blob_indices = [ 27, 28, 29, 30, 31,32]  
    for i in blob_indices:
        if candidate[i] is not None:
            if hasattr(candidate[i], 'read'):
                candidate_details[i] = base64.b64encode(candidate[i].read()).decode('utf-8')
            else:
                candidate_details[i] = base64.b64encode(candidate[i].encode('utf-8')).decode('utf-8')
    cursor.close()
    connection.close()
    return render_template('candidate.html', candidate=candidate_details)

if __name__ == "__main__":
    app.run(debug=True)