import time
import os
import shutil
import pandas as pd
import mimetypes
import smtplib

from email.message import EmailMessage
from email.utils import make_msgid
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC

def Overall():
    driver = webdriver.Edge()

    # Navigate to the webpage
    driver.get("https://reports.manappuram.com/#/views/CrfdetailsofNGL/Overall?:iid=1")


    time.sleep(15)
    wait = WebDriverWait(driver, 20)
    # Find the login form elements
    username_field = driver.find_element(By.NAME, 'username')
    password_field = driver.find_element(By.NAME, 'password')

    # Enter the username and password
    username_field.send_keys('username')
    password_field.send_keys('password')

    # Submit the form
    password_field.send_keys(Keys.RETURN)

    time.sleep(30)
    iframe_element = driver.find_element(By.TAG_NAME, "iframe")

    # Switch to the iframe by passing the iframe element
    driver.switch_to.frame(iframe_element)
    #click download button
    # Locate and click the button element within the iframe
    button_element = driver.find_element(By.ID, "download")
    button_element.click()

    time.sleep(3)
    #select crosstab
    element = driver.find_element(By.XPATH, "//div[@data-tb-test-id='download-flyout-download-crosstab-MenuItem']")
    element.click()

    #select download button
    time.sleep(10)

    element2 = driver.find_element(By.XPATH, "//div[@class='fdr6v0d']//button")
    element2.click()

    time.sleep(30)

    # After interacting with elements within the iframe, switch back to the default content
    driver.switch_to.default_content()

    driver.close()

    file_path = "C://Users//412919//Downloads//Overall.xlsx"
    if os.path.exists(file_path):
        print("Overall excel downloaded")
    
        
    else:
        print("Overall excel not downloaded")

Overall()

#move

import os
import shutil

def move_excel_file(source_folder, destination_folder, file_name):
    source_file_path = os.path.join(source_folder, file_name)
    if os.path.isfile(source_file_path) and file_name.endswith('.xlsx'):
        destination_file_path = os.path.join(destination_folder, file_name)
        shutil.move(source_file_path, destination_file_path)

source_folder = 'C:\\Users\\412919\\Downloads\\'
destination_folder = 'D:\\CRF\\124859-CRF Status Report\\New folder'
file_name = "Overall.xlsx"  # Specify the name of the Excel file to move

move_excel_file(source_folder, destination_folder, file_name)

print("Moved")

