import os
import pandas as pd

# Get the list of Excel files in the downloads folder
download_folder = 'C:\\Users\\am5\\Desktop\\Collection report\\Reports'  # Replace with the actual path to your downloads folder
excel_files = [file for file in os.listdir(download_folder) if file.endswith('.xlsx')]

# Create a new Excel file for merging
merged_file = pd.ExcelWriter('C:\\Users\\am5\\Desktop\\Collection report\\Reports\\Collection_Report.xlsx', engine='xlsxwriter')  # Replace with the desired path and file name

# Merge the Excel files into different sheets
for idx, file in enumerate(excel_files):
    sheet_name = 'Sheet ' + str(idx + 1)
    if file == 'data.xlsx':
        sheet_name = 'Data'
    elif file == 'branch.xlsx':
        sheet_name = 'Branch'
    elif file == 'SO WISE.xlsx':
        sheet_name = 'So wise'
    elif file == 'RO Perfomance.xlsx':
        sheet_name = 'Ro Perfomance'
    elif file == 'RM perfomance.xlsx':
        sheet_name = 'Rm Perfomance'
    # elif file == 'Emp Data Mis.xlsx':
    #     sheet_name = 'Emp Data Mis'
    # elif file == "Zero SO's- Non Performers.xlsx":
    #     sheet_name = "Zero SO's- Non Performers"
    # elif file == 'Conf data.xlsx':
    #     sheet_name = 'Conf_data'
    # Disbursement report.xlsx", "conf data .xlsx", "BRANCH.xlsx", "STATE.xlsx", "REGION.xlsx", "Emp Data Mis.xlsx", "Zero SO's- Non Performers.xlsx", "Conf data.xlsx"
    data = pd.read_excel(os.path.join(download_folder, file), sheet_name='Sheet 1', engine='openpyxl')
    data.to_excel(merged_file, sheet_name=sheet_name, index=False)

# Save the merged Excel file
merged_file.save()
