import time
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from rep2 import branch

def data():
    driver = webdriver.Chrome()

    # Navigate to the webpage
    driver.get("http://reports.manappuram.com//#/redirect_to_view/12196")

    time.sleep(5)
    wait = WebDriverWait(driver, 10)
    # Find the login form elements
    username_field = driver.find_element(By.NAME, 'username')
    password_field = driver.find_element(By.NAME, 'password')

    # Enter the username and password
    username_field.send_keys('357274')
    password_field.send_keys('May@123')

    # Submit the form
    password_field.send_keys(Keys.RETURN)

    time.sleep(50)
    iframe_element = driver.find_element(By.TAG_NAME, "iframe")

    # Switch to the iframe by passing the iframe element
    driver.switch_to.frame(iframe_element)
    #click download button
    # Locate and click the button element within the iframe
    button_element = driver.find_element(By.ID, "download")
    button_element.click()

    time.sleep(3)
    #select crosstab
    element = driver.find_element(By.XPATH, "//div[@data-tb-test-id='download-flyout-download-crosstab-MenuItem']")
    element.click()

    #select download button
    time.sleep(10)

    element2 = driver.find_element(By.XPATH, "//div[@class='fdr6v0d']//button")
    element2.click()

    time.sleep(30)

    # After interacting with elements within the iframe, switch back to the default content
    driver.switch_to.default_content()

    driver.close()

    file_path = "C://Users//am5//Downloads//data.xlsx//"
    if os.path.exists(file_path):
        print("data excel downloaded")
        branch()
    else:
        print("back data loop")

data()

