import os
folder_path = "C:\\Users\\am5\\Desktop\\Collection report\\Reports"
print(folder_path)

for filename in os.listdir(folder_path):
    print(filename)
    os.remove(os.path.join(folder_path, filename))

