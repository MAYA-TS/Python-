import os
import shutil
def move_excel_files(source_folder, destination_folder, file_names):
    for file_name in file_names:
        source_file_path = os.path.join(source_folder, file_name)
        if os.path.isfile(source_file_path) and file_name.endswith('.xlsx'):
            destination_file_path = os.path.join(destination_folder, file_name)
            shutil.move(source_file_path, destination_file_path)
source_folder = 'C:\\Users\\am5\\Downloads\\'
destination_folder = 'C:\\Users\\am5\\Desktop\\Collection report\\Reports\\'
file_names = ["data.xlsx", "branch.xlsx", "SO WISE.xlsx", "RO Perfomance.xlsx", "RM perfomance.xlsx"]  # Specify the names of the Excel files to move
move_excel_files(source_folder, destination_folder, file_names)