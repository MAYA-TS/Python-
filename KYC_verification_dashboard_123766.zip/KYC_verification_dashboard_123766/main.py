import xlsxwriter
import os
import pandas as pd
import cx_Oracle
import openpyxl
from pandas import ExcelWriter
from openpyxl import Workbook
from email.message import EmailMessage
from email.utils import make_msgid
import mimetypes
from tableau_api_lib import TableauServerConnection
from tableau_api_lib.utils import querying
from tableau_api_lib.utils.common import flatten_dict_column
import pandas as pd
import xlrd
from pandas import ExcelWriter
from openpyxl import load_workbook
from openpyxl.styles import PatternFill,Font
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side
import smtplib
import datetime
import time
import schedule
import time
import tableauserverclient as TSC

# def task():

# while True:
tableau_server_config = {
                'my_env': {
                        'server': 'https://reports.manappuram.com',
                        'api_version': "3.17",
                        'username': 'tableauadministrator',
                        'password': 'M@fil@123',
                        'site_name': 'Default',
                        'site_url': ''
                }
        }
conn = TableauServerConnection(tableau_server_config, env='my_env',ssl_verify=False)
conn.sign_in()
print("Tableau server connected")


# site_views_df = querying.get_views_dataframe(conn)
# site_views_detailed_df = flatten_dict_column(site_views_df, keys=['name', 'id'], col_name='workbook')
# site_views_detailed_df.tail(60)
# relevant_views_df = site_views_detailed_df[site_views_detailed_df['workbook_name'] == 'GOLD LOAN IRREGULARITY ANALYSIS']
# print(relevant_views_df)
# relevant_views_df.refresh(workbook_id='949d788d-c89f-432d-8af2-c03990e149c5')

# fzm_data='0d19420f-d3b9-40c7-a24d-2577485f72e6'
# # reg_data='a8e2ec7a-b658-4065-b839-2a0154c380b4'
# view_img = conn.query_view_image(view_id=fzm_data)
# print(view_img)
# with open(r"D:\\CRF\\Gold_loan_irregularity_analysis_123348\\Gold_loan_irregularity_report1.png","wb") as f:
   
#     f.write(view_img.content)
# print("Third section completed................")
conn = cx_Oracle.connect("kpmg", "Asd$1234", "HISTDB")
print("Oracle database connected")



df1=pd.read_sql("""select distinct e.fzm,
                d.reg_name,
                d.area_name,
                m.branch_id,
                d.branch_name,
                (count(distinct case
                         when b.status = 1 then
                          m.cust_id
                       end) + count(distinct case
                                       when b.status = 0 then
                                        m.cust_id
                                     end) +
                count(distinct case
                         when trunc(b.verify_dt) is null then
                          m.cust_id
                       end)) requested_count,
                count(distinct case
                        when b.status = 1 then
                         m.cust_id
                      end) approved_count,
                count(distinct case
                        when b.status = 0 then
                         m.cust_id
                      end) rejected_count,
                count(distinct case
                        when trunc(b.verify_dt) is null then
                         m.cust_id
                      end) approval_pedning_count,
                count(distinct case
                        when (trunc(b.verify_dt) - req_dt) <= 1 then
                         m.cust_id
                      end) below_1_day,
                count(distinct case
                        when (trunc(b.verify_dt) - req_dt) between 1.1 and 2 then
                         m.cust_id
                      end) one_2_day,
                count(distinct case
                        when (trunc(b.verify_dt) - req_dt) between 2.1 and 3 then
                         m.cust_id
                      end) two_3_day,
                count(distinct case
                        when (trunc(b.verify_dt) - req_dt) >= 3.1 then
                         m.cust_id
                      end) above_3_day
  from (select branch_id, cust_id, trunc(tra_dt) req_dt
          from mana0809.tbl_kycverification_mst@uatr_backup2
         where status_id =2
           and kyc_sts = 1) m
  left outer join mana0809.tbl_kyc_dtl_check@uatr_backup2 b
    on m.cust_id = b.cust_id
  left outer join mana0809.customer@uatr_backup2 c
    on m.cust_id = c.cust_id
  left outer join mana0809.branch_dtl_new@uatr_backup2 d
    on m.branch_id = d.branch_id
  left outer join mana0809.tbl_fzm_master@uatr_backup2 e
    on d.reg_id = e.region_id
 where req_dt >= trunc(sysdate - 3)
 group by e.fzm, d.reg_name, d.area_name, m.branch_id, d.branch_name""",con=conn)
print("Kyc summary Report query executed---------------------------------------------------------df1")
df2=pd.read_sql("""select e.fzm,
       d.reg_name,
       d.area_name,
       m.branch_id,
       d.branch_name,
       m.cust_id,
       c.cust_name,
       m.req_dt,
       trunc(b.verify_dt) apr_rej_dt,
       case
         when b.status = 0 then
          b.remark
       end reject_reason
  from (select branch_id, cust_id, trunc(tra_dt) req_dt
          from mana0809.tbl_kycverification_mst@uatr_backup2
         where status_id = 2
           and kyc_sts = 1) m
  left outer join mana0809.tbl_kyc_dtl_check@uatr_backup2 b
    on m.cust_id = b.cust_id
  left outer join mana0809.customer@uatr_backup2 c
    on m.cust_id = c.cust_id
  left outer join mana0809.branch_dtl_new@uatr_backup2 d
    on m.branch_id = d.branch_id
  left outer join mana0809.tbl_fzm_master@uatr_backup2 e
    on d.reg_id = e.region_id
 where req_dt >= trunc(sysdate - 3)""",con=conn)
print("Kyc Detailed Report query executed--------------------------------------------------------df2")
writer=pd.ExcelWriter("D:\\CRF\\KYC_verification_dashboard_123766\\KYC_Verification_report.xlsx",engine="openpyxl")
df1.to_excel(writer, sheet_name="Kyc summary Report", index=False)
df2.to_excel(writer, sheet_name="Kyc Detailed Report", index=False)

print("saved as excel")
writer.save()
print("Excel downloading section completed............")

workbook = load_workbook('D:\\CRF\\KYC_verification_dashboard_123766\\KYC_Verification_report.xlsx')
sheet_names = workbook.sheetnames
heading_color = '008000'   #9999ff #  color
body_color =  '999999'            #d0d0e1  #  color
for sheet_name in sheet_names:
    sheet = workbook[sheet_name]
    header_fill = PatternFill(start_color=heading_color, end_color=heading_color, fill_type='solid')
    for cell in sheet[1]:
        cell.fill = header_fill
    body_fill = PatternFill(start_color=body_color, end_color=body_color, fill_type='solid')
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            cell.fill = body_fill
workbook.save('D:\\CRF\\KYC_verification_dashboard_123766\\KYC_Verification_report.xlsx')



workbook = openpyxl.load_workbook("D:\\CRF\\KYC_verification_dashboard_123766\\KYC_Verification_report.xlsx")
sheet_names = workbook.sheetnames
heading_color =  '070F2B'    #'73BCC5'#'8080ff'  # Red color
body_color = 'FFFFFF'  # Green color
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
 
 
for sheet_name in sheet_names:
    sheet = workbook[sheet_name]
    header_font = Font(color="ffffff", bold=True)
    header_fill = PatternFill(start_color='070F2B', end_color='070F2B', fill_type='solid')
    for cell in sheet[1]:
        cell.fill = header_fill
        cell.font = header_font
    body_fill = PatternFill(start_color=body_color, end_color=body_color, fill_type='solid')
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            cell.fill = body_fill
           
    max_height = 0
    for cell in row:
        if cell.value:
            height = str(cell.value).count('\n') + 1
            if height > max_height:
                max_height = height
    for column in sheet.columns:
        non_empty_values = [cell.value for cell in column if cell.value]
        if non_empty_values:
            max_length = max(len(str(value)) for value in non_empty_values)
            column_letter = get_column_letter(column[0].column)
            adjusted_width = (max_length + 2) * 1.2  # Adjust the width as desired
            sheet.column_dimensions[column_letter].width = adjusted_width

    for row in sheet.rows:
        non_empty_values = [cell.value for cell in row if cell.value]
        if non_empty_values:
            max_height = max(str(value).count('\n') + 1 for value in non_empty_values)
            row_number = row[0].row
            adjusted_height = max_height * 17  # Adjust the height as desired
            sheet.row_dimensions[row_number].height = adjusted_height


    for row in sheet.iter_rows():
        for cell in row:
            cell.alignment = Alignment(horizontal='center', vertical='center')
    for row in sheet.iter_rows():
        for cell in row:
            cell.border = border_style
workbook.save("D:\\CRF\\KYC_verification_dashboard_123766\\KYC_Verification_report.xlsx")
workbook = openpyxl.load_workbook(r'D:\\CRF\\KYC_verification_dashboard_123766\\KYC_Verification_report.xlsx')


excel_file_path = 'D:\\CRF\\KYC_verification_dashboard_123766\\KYC_Verification_report.xlsx'


s = smtplib.SMTP(host='smtp.office365.com', port=587)
s.starttls()

s.login('iotautomation@manappuram.com', 'ybjmxbfdyzkdnjtw')
msg = EmailMessage()

print("Ready for mailing")

msg['Subject'] = 'KYC Verification report'
msg['From'] ='iot <iotautomation@manappuram.com>'

# msg['From'] ='INTERNAL AUDIT <internalaudit1@manappuram.com>'
msg['To']='KARTHIKEYAN K<ittesting21@manappuram.com>'
# msg['Cc'] ='dhinesh<itprogramer40@manappuram.com>'

# msg['To']='Sravan TB<iotsupport12@manappuram.com>','dhinesh<itprogramer40@manappuram.com>'


# msg['To']='Branch Audit <branchaudit@manappuram.com>','Audit Research Wing<researchwing@manappuram.com>','MAFIL BRANCH AUDIT<internalaudit@manappuram.com>','JAYESH S V<twaudit@manappuram.com>','MAFIL HO Audit<hoaudit@manappuram.com>',' G M AUDIT<gmaudit@manappuram.com>','HEAD RESEARCHWING<headresearchwing@manappuram.com>','G ALERT AUDIT<glalertsaudit@manappuram>','AGM <agmia@manappuram.com>','CM INTERNALAUDIT<cminternalaudit@manappuram>'
# msg['Cc'] ='RIJU P<gmaudit@manappuram.com>','MAYA T S<iotsupport7@manappuram.com>','SRAVAN T B<iotsupport12@manappuram.com>','Gopika V S<dataservice29@manappuram.com>'
with open(r"D:\\CRF\\KYC_verification_dashboard_123766\\KYC_Verification_report.xlsx", 'rb') as ra:
    attachment = ra.read()

msg.add_related(attachment, maintype='application', subtype='xlsx', filename='KYC_Verification_report.xlsx')
msg.add_alternative("""\
    <html>
        <body>
            <p><i>Dear Sir,</i></p>
            <p> </p>
            <p><i> Please find the attachment</i></p>
                    
            <p></p>
            <p> <i>Thanks & Regards,<br>
                ( This is an autogenerated mail )<br>
        R&D <br>
            </i></p>
        </body>
    </html>
    """,subtype='html')
# with open(r"D:\\CRF\\Daily Alert efficiency summary report_122055\\Alert_report.png", 'rb') as img:
#         maintype, subtype = mimetypes.guess_type(img.name)[0].split('/')
#         msg.get_payload()[1].add_related(img.read(),
#                                             maintype=maintype,
#                                             subtype=subtype,
#                                             cid=image_cid)


# msg.add_alternative(html_table,subtype='html')
s.send_message(msg)

print("Mail sent")
