
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import cx_Oracle  # Assuming you're using Oracle DB

# Database connection details
conn = cx_Oracle.connect('')
cursor = conn.cursor()

# SQL query to fetch approved leave details
query = """select m.emp_code,e.emp_name,d.Dep_name,m.Leave_frdate,m.Leave_todate,m.Leave_days,'Rejected' Status
          from mana0809.hrm_emp_leave_application@uatr_backup2 m,
mana0809.tbl_hrm_approval_level@uatr_backup2 l,
mana0809.emp_master@uatr_backup2 e,
mana0809.department_mst@uatr_backup2 d
          where  l.seq_code=Leave_SEQ and module_id=2 and app_status=3
          and trunc(Approved_date)=trunc(sysdate)
          and e.emp_code=m.emp_code
          and d.dep_id=e.department_id
          and d.major_dep_id=74"""

# Function to send email
def send_email(to_email, subject, body):
    from_email = "iotautomation@manappuram.com"
    password = ""

    msg = MIMEMultipart()
    msg['From'] = from_email
    msg['To'] = to_email
    msg['Subject'] = subject

    msg.attach(MIMEText(body, 'plain'))

    with smtplib.SMTP('smtp.office365.com', 587) as server:
        server.starttls()
        server.login(from_email, password)
        server.send_message(msg)

# Execute the query and send emails
try:
    cursor.execute(query)
    for row in cursor.fetchall():
        emp_code,emp_name, dep_name, leave_frdate, leave_todate, leave_days, status = row
        
        # Convert emp_code to string for email address
        emp_code_str = str(emp_code)
        to_email = f"{emp_code_str}@manappuram.com"  # Ensure this is a valid email format
        
        # Prepare email details
        subject = "Leave Approved Notification"
        body = (f"Dear {emp_name},\n\n"
                f"Your leave from {leave_frdate} to {leave_todate} has been Rejected.\n"
                f"Leave Days: {leave_days}\n"
                f"Status: {status}\n\n"
                "Best Regards,\nHR Team")

        # Send email
        try:
            send_email(to_email, subject, body)
            print(f"Email sent to {to_email}")
        except Exception as e:
            print(f"Failed to send email to {to_email}: {e}")

except cx_Oracle.DatabaseError as e:
    print(f"Error executing query: {e}")

finally:
    # Close the database connection
    cursor.close()
    conn.close()

