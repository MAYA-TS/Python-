
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import cx_Oracle

# Database connection
conn = cx_Oracle.connect('')
cursor = conn.cursor()  # Corrected this line

query = """select k.emp_code, e.emp_name, d.dep_name, k.Leave_frDate, k.Leave_reason
  from mana0809.employ_leave_dtl@uatr_backup2 k,
       mana0809.emp_master@uatr_backup2       e,
       mana0809.department_mst@uatr_backup2   d
 where leave_id = 4
   and leave_process_id = 1
   and e.emp_code = k.emp_code and e.status_id=1 and e.emp_type<>4
   and e.department_id = d.dep_id
   and major_dep_id = 74
   and not exists (select *
          from mana0809.hrm_emp_leave_application@uatr_backup2 o
         where o.emp_code = k.emp_code
           and o.leave_frdate = k.leave_frdate)
   and k.leave_frdate >= trunc(sysdate) - 11
   and k.leave_frdate <= trunc(sysdate) - 3

"""

try:
    cursor.execute(query)
    results = cursor.fetchall()
except cx_Oracle.DatabaseError as e:
    print(f"Query execution error: {e}")
    cursor.close()
    conn.close()
    exit()              

# Group leaves by employee
leave_notifications = {}
for emp_code, emp_name, dep_name, leave_date, leave_reason in results:
    if emp_code not in leave_notifications:
        leave_notifications[emp_code] = {
            'name': emp_name,
            'department': dep_name,
            'leaves': []
        }
    leave_notifications[emp_code]['leaves'].append((leave_date, leave_reason))

# Email configuration
smtp_server = 'smtp.office365.com'
smtp_port = 587
smtp_user = 'iotautomation@manappuram.com'
smtp_password = ''

# Function to send email
def send_email(to_address, subject, body):
    msg = MIMEMultipart()
    msg['From'] = smtp_user
    msg['To'] = to_address
    # msg['Bcc']='Sravan<iotsupport12@manappuram.com>'
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    try:
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(smtp_user, smtp_password)
            server.send_message(msg)
    except Exception as e:
        print(f"Failed to send email to {to_address}: {e}")

# Sending notifications
for emp_code, details in leave_notifications.items():
    leaves_info = "\n".join([f"Date: {leave[0]}, Reason: {leave[1]}" for leave in details['leaves']])
    email_body = f"""
    Dear {details['name']},

    This is a reminder that you have taken the following leaves without applying:

    {leaves_info}

    Please ensure to apply for your leaves in the future.

    Best regards,
    R&D Department
    """
    send_email(f"{emp_code}@manappuram.com", "Leave Application Reminder", email_body)

# Close the database connection
cursor.close()
conn.close()



