import xlsxwriter
import os
import pandas as pd
import cx_Oracle
import openpyxl
from pandas import ExcelWriter
from openpyxl import Workbook
from sqlalchemy import create_engine

from email.message import EmailMessage
from email.utils import make_msgid
import mimetypes
import smtplib


conn = cx_Oracle.connect("kpmg", "Asd$1234", "HISTDB")
print("Oracle database connected")

#customer modification detailed report

df1=pd.read_sql("""select d.fzm,
       c.reg_name,
       c.area_name,
       b.branch_id,
       c.branch_name,
       a.cust_id,
       b.name,
       a.req_dt,
       aprvd_date,
       rejected_date,
       a.rejection_reason,a.status_id,
       case
         when a.status_id = 2 then
          'Approved'
         when a.status_id = 6 then
          'rejected'
         when a.status_id = 3 then
          'recomanded'
         else
          'Approval pending'
       end Approval_status
  from dms.kyc_pre_auth@uatr_backup2        a,
       mana0809.customer@uatr_backup2       b,
       mana0809.branch_dtl_new@uatr_backup2 c,
       mana0809.tbl_fzm_master@uatr_backup2 d
 where a.cust_id = b.cust_id
   and b.branch_id = c.branch_id
   and c.reg_id = d.region_id
   and trunc(a.req_dt) = trunc(sysdate) """,con=conn)

#customer modification summary

df2=pd.read_sql("""select distinct d.fzm,
       c.reg_name,
       c.area_name,
       b.branch_id,
       c.branch_name,
       count(case
               when a.req_dt is not null then
                a.cust_id
             end) requested_count,
       count(case
               when a.aprvd_date is not null then
                a.cust_id
             end) approved_count,
       count(case
               when a.rejected_date is not null then
                a.cust_id
             end) rejected_count,
       count(case
               when a.req_dt is not null then
                a.cust_id
             end) - (count(case
                             when a.aprvd_date is not null then
                              a.cust_id
                           end) + count(case
                                          when a.rejected_date is not null then
                                           a.cust_id
                                        end)) Approval_pending_Count,
       count(case
               when round(((NVL(nvl(aprvd_date,rejected_date),sysdate+1) -req_dt))*24/60,2) < 5 then
                a.cust_id
             end) one_to_5_mins,
       count(case
               when round(((NVL(nvl(aprvd_date,rejected_date),sysdate+1) -req_dt))*24/60,2) between 6 and 10 then
                a.cust_id
             end) five_to_10_mins,
       count(case
               when round(((NVL(nvl(aprvd_date,rejected_date),sysdate+1) -req_dt))*24/60,2) between 11 and 15 then
                a.cust_id
             end) ten_to_15_mins,
       count(case
               when round(((NVL(nvl(aprvd_date,rejected_date),sysdate+1) -req_dt))*24/60,2) > 15 then
                a.cust_id
             end) Above_15_mins

--a.rejection_reason
  from dms.kyc_pre_auth@uatr_backup2        a,
       mana0809.customer@uatr_backup2       b,
       mana0809.branch_dtl_new@uatr_backup2 c,
       mana0809.tbl_fzm_master@uatr_backup2 d
 where a.cust_id = b.cust_id
   and b.branch_id = c.branch_id
   and c.reg_id = d.region_id
   and trunc(req_dt) = trunc(sysdate)
 group by d.fzm, c.reg_name, c.area_name, b.branch_id, c.branch_name
""",con=conn)




print("Excel downloaded")
writer = pd.ExcelWriter("Customer_Modification_New_Dashboard.xlsx", engine="openpyxl")
# writer = pd.ExcelWriter("C:/mail_crf/mail/operation_report.xlsx", engine="openpyxl")
# writer = pd.ExcelWriter("C:/Users/357274/Downloads/repot/Phase1.xlsx", engine="openpyxl")
#writer = pd.ExcelWriter("operation_report111.CSV")
df1.to_excel(writer, sheet_name="Detailed Report", index=False)
df2.to_excel(writer, sheet_name="Summary Report", index=False)

writer.close()

#mail

s = smtplib.SMTP(host='smtp.office365.com', port=587)
s.starttls()

s.login('iotautomation@manappuram.com', 'ybjmxbfdyzkdnjtw')
# s.login('internalaudit1@manappuram.com','AB@123ad')
msg = EmailMessage()

print("Ready for mailing")
subject = f'Customer Modification New Dashboard'
msg['Subject'] = subject

        
msg['From'] = 'IOT <iotautomation@manappuram.com>'
#msg['To'] ='DIBIN T R<iotsupport14@manappuram.com>'
#msg['To']='SAJITH PS<smkyc@manappuram.com>','SUGANYA DHANASEKARAN<ittesting16@manappuram.com>'
msg['To']='SUGANYA DHANASEKARAN<ittesting16@manappuram.com>'
#msg['Cc']='VREESHA E P<itcoordinatorkyc@manappuram.com>','MAYA T S<iotsupport7@manappuram.com>','DIBIN T R<iotsupport14@manappuram.com>','DINESH<itprogramer40@manappuram.com>','MILKA MARIA GEORGE<dataservice31@manappuram.com>'
msg['Cc']='MAYA T S<iotsupport7@manappuram.com>','DIBIN T R<iotsupport14@manappuram.com>','DINESH<itprogramer40@manappuram.com>'

#C:\Users\412919\Desktop\CRF\123803-CRF FOR CUSTOMER MODIFICATION NEW DASHBOARD\Customer_Modification_New_Dashboard.xlsx
with open(r"C:\\Users\\412919\\Desktop\\CRF\\123803-CRF FOR CUSTOMER MODIFICATION NEW DASHBOARD\\Customer_Modification_New_Dashboard.xlsx", 'rb') as ra:
        attachment = ra.read()
             
msg.add_related(attachment, maintype='application', subtype='xlsx', filename='Customer_Modification_New_Dashboard.xlsx')  

msg.add_alternative("""   
                            <html>
        <body>
            <p><i>Dear Sir/Madam,</i></p>
            <p> </p>
            <p><i> Kindly find the attachment for CRF Customer Modification New Dashboard (CRF Id:123803).Please check and verify. </i></p>
            <p></p>
            <p> <i>Thanks & Regards,<br>
                ( This is an autogenerated mail )<br>
        R&D <br>
            </i></p>
        </body>
    </html>
    """ ,subtype='html')
        
s.send_message(msg)

print("Mail sent")
