import os
import pandas as pd

# Get the list of Excel files in the downloads folder
download_folder = 'C:\\Users\\am5\\Desktop\\Expense_Type_Analysis_Report\\Reports\\'  # Replace with the actual path to your downloads folder
excel_files = [file for file in os.listdir(download_folder) if file.endswith('.xlsx')]

# Create a new Excel file for merging
merged_file = pd.ExcelWriter('C:\\Users\\am5\\Desktop\\Expense_Type_Analysis_Report\\Reports\\Expense_Type_Analysis_Report.xlsx', engine='xlsxwriter')  # Replace with the desired path and file name

# Merge the Excel files into different sheets
for idx, file in enumerate(excel_files):
    sheet_name = 'Sheet ' + str(idx + 1)
    if file == 'Summary Dashboard HO.xlsx':
        sheet_name = 'Summary Dashboard HO'
    elif file == 'Summary Dashboard Branch.xlsx':
        sheet_name = 'Summary Dashboard Branch'
    elif file == 'Payment With PO.xlsx':
        sheet_name = 'Payment With PO'
    elif file == 'Payment Without PO.xlsx':
        sheet_name = 'Payment Without PO'
    elif file == 'BRANCH MAINTENANCE.xlsx':
         sheet_name = 'BRANCH MAINTENANCE'
    elif file == 'MISCELLANEOUS.xlsx':
         sheet_name = 'MISCELLANEOUS'
    # elif file == "billing.xlsx":
    #     sheet_name = "billing"
    # elif file == 'up to date billing.xlsx':
    #     sheet_name = 'up to date billing'
    # Disbursement report.xlsx", "conf data .xlsx", "BRANCH.xlsx", "STATE.xlsx", "REGION.xlsx", "Emp Data Mis.xlsx", "Zero SO's- Non Performers.xlsx", "Conf data.xlsx"
    data = pd.read_excel(os.path.join(download_folder, file), sheet_name='Sheet 1', engine='openpyxl')
    data.to_excel(merged_file, sheet_name=sheet_name, index=False)

# Save the merged Excel file
merged_file.save()
