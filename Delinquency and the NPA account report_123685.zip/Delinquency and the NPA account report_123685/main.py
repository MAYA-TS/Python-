from email.message import EmailMessage
import os
import shutil
import smtplib
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.edge.service import Service
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font
from openpyxl.utils import get_column_letter
from tableau_api_lib import TableauServerConnection
from tableau_api_lib.utils import querying
from tableau_api_lib.utils.common import flatten_dict_column
import pandas as pd
import xlrd
from pandas import ExcelWriter
import cx_Oracle
import openpyxl
from email.message import EmailMessage
from openpyxl.styles import PatternFill,Font
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side,Alignment
from openpyxl import load_workbook
import smtplib
from datetime import datetime, timedelta
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.styles import Color

def data():
    driver = webdriver.Edge()  # Ensure you have the correct driver
    driver.maximize_window()

    # Navigate to the login page
    driver.get("https://reports.manappuram.com/#/projects/70")

    time.sleep(10)
    wait = WebDriverWait(driver, 15)
    # Find the login form elements
    username_field = driver.find_element(By.NAME, 'username')
    password_field = driver.find_element(By.NAME, 'password')

    username_field.send_keys('357274')
    password_field.send_keys('May@123')

    # Submit the form
    password_field.send_keys(Keys.RETURN)
    time.sleep(15)

    def download_report(report_url):
        driver.get(report_url)
        time.sleep(10)  
       
        iframe_element = wait.until(EC.presence_of_element_located((By.TAG_NAME, "iframe")))
        driver.switch_to.frame(iframe_element)
       
        button_element = wait.until(EC.element_to_be_clickable((By.ID, "download")))
        button_element.click()
        time.sleep(10)
       
        # Select crosstab option
        element = wait.until(EC.element_to_be_clickable((By.XPATH, "//div[@data-tb-test-id='download-flyout-download-crosstab-MenuItem']")))
        element.click()

        # Select the download button
        time.sleep(10)
        element2 = wait.until(EC.element_to_be_clickable((By.XPATH, "//div[@class='fdr6v0d']//button")))
        element2.click()

        time.sleep(10)
        driver.switch_to.default_content()

    # Download the first report
    download_report("http://reports.manappuram.com//#/redirect_to_view/12622")
    # Download the second report
    download_report("http://reports.manappuram.com//#/redirect_to_view/12623")

data()
print("Excel downloaded 'OK'")
pass

def move_excel_files(source_folder, destination_folder, file_names):
    for file_name in file_names:
        source_file_path = os.path.join(source_folder, file_name)
        if os.path.isfile(source_file_path) and file_name.endswith('.xlsx'):
            destination_file_path = os.path.join(destination_folder, file_name)
            shutil.move(source_file_path, destination_file_path)
        else:
            print(f"File not found or not an Excel file: {file_name}")

source_folder = os.path.expanduser('~/Downloads')  
destination_folder = r'D:\CRF\Delinquency and the NPA account report_123685'  
file_names = ["Deliquency and npa.xlsx", "Reduction Deliquency and npa.xlsx"]

if not os.path.exists(destination_folder):
    os.makedirs(destination_folder)  
move_excel_files(source_folder, destination_folder, file_names)
print("Excel moved 'OK'")

def merge_excels(file_names, output_file):
    writer = pd.ExcelWriter(output_file, engine='openpyxl')
   
    for file in file_names:
        df = pd.read_excel(file)
        sheet_name = os.path.splitext(os.path.basename(file))[0]
        df.to_excel(writer, sheet_name=sheet_name, index=False)
   
    writer.save()
    writer.close()

merged_file = r'D:\\CRF\\Delinquency and the NPA account report_123685\\Delinquency_and_NPA_account_Report.xlsx'
merge_excels([os.path.join(destination_folder, file_name) for file_name in file_names], merged_file)
print("Excel merged 'OK'")



workbook = load_workbook(r"D:\\CRF\\Delinquency and the NPA account report_123685\\Delinquency_and_NPA_account_Report.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))

sheet_names = workbook.sheetnames
sh_names1 = ["Deliquency and npa","Reduction Deliquency and npa"]
for sheet_name in sheet_names:
    if sheet_name in sh_names1:
        sheet = workbook[sheet_name]
        x = ['Unnamed: 0','Unnamed: 1','Unnamed: 3','Unnamed: 4','Unnamed: 5','Unnamed: 6','Unnamed: 7','Unnamed: 8','Unnamed: 9']
        for row in sheet.iter_rows():
            for cell in row:
                if cell.value in x:
                    cell.value = ""
        for col in range(1, 11):
            column_letter = get_column_letter(col)
            sheet.column_dimensions[column_letter].width = 20

        merge_range6 = f"A1:A3"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=1, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=1, column=1)
        merged_cell6.value = 'REG NAME'
        font = Font(color="ff0000", bold=True)  # Set the font color to white
        merged_cells6.font = font

        merge_range6 = f"B1:B3"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=1, column=2)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=1, column=2)
        merged_cell6.value = 'AUM'
        font = Font(color="ff0000", bold=True)  # Set the font color to white
        merged_cells6.font = font

        merge_range6 = f"C1:J1"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=1, column=3)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=1, column=3)
        merged_cell6.value = 'CATEGORY'
        font = Font(color="ff0000", bold=True)  # Set the font color to white
        merged_cells6.font = font

        merge_range6 = f"C2:D2"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=2, column=3)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=2, column=3)
        merged_cell6.value = 'SMA 0'
        font = Font(color="ff0000", bold=True)  # Set the font color to white
        merged_cells6.font = font

        merge_range6 = f"E2:F2"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=2, column=5)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=2, column=5)
        merged_cell6.value = 'SMA 1'
        font = Font(color="ff0000", bold=True)  # Set the font color to white
        merged_cells6.font = font

        merge_range6 = f"G2:H2"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=2, column=7)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=2, column=7)
        merged_cell6.value = 'SMA 2'
        font = Font(color="ff0000", bold=True)  # Set the font color to white
        merged_cells6.font = font

        merge_range6 = f"I2:J2"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=2, column=9)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=2, column=9)
        merged_cell6.value = 'NPA'
        font = Font(color="ff0000", bold=True)  # Set the font color to white
        merged_cells6.font = font

        for row in sheet.iter_rows():
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
        for row in sheet.iter_rows():
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                cell.border = border_style
print("Excel designing completed")

workbook.save(r"D:\\CRF\\Delinquency and the NPA account report_123685\\Delinquency_and_NPA_account_Report.xlsx")

# def style_excel(file_path):
#     wb = load_workbook(file_path)
#     for sheet in wb.sheetnames:
#         ws = wb[sheet]
#         # Style the header
#         header_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
#         header_font = Font(bold=True)
       
#         for cell in ws[1]:
#             cell.fill = header_fill
#             cell.font = header_font

#         # Adjust column width based on data
#         for column in ws.columns:
#             max_length = 0
#             column_letter = get_column_letter(column[0].column)
#             for cell in column:
#                 try:
#                     if len(str(cell.value)) > max_length:
#                         max_length = len(cell.value)
#                 except:
#                     pass
#             adjusted_width = (max_length + 2) * 1.2
#             ws.column_dimensions[column_letter].width = adjusted_width

#     wb.save(file_path)

# style_excel(merged_file)
# print("Excel styled 'OK'")

# Email part
s = smtplib.SMTP(host='smtp.office365.com', port=587)
s.starttls()

s.login('iotautomation@manappuram.com', 'ybjmxbfdyzkdnjtw')
msg = EmailMessage()

print("Ready for mailing")

msg['Subject'] = 'Delinquency and the NPA account report'
msg['From'] ='iot <iotautomation@manappuram.com>'

# msg['From'] ='INTERNAL AUDIT <internalaudit1@manappuram.com>'
msg['To']='Karthi G<splitc@manappuram.com>'
msg['Cc'] ='dhinesh<itprogramer40@manappuram.com>'

# msg['To']='Sravan TB<iotsupport12@manappuram.com>','dhinesh<itprogramer40@manappuram.com>'


# msg['To']='Branch Audit <branchaudit@manappuram.com>','Audit Research Wing<researchwing@manappuram.com>','MAFIL BRANCH AUDIT<internalaudit@manappuram.com>','JAYESH S V<twaudit@manappuram.com>','MAFIL HO Audit<hoaudit@manappuram.com>',' G M AUDIT<gmaudit@manappuram.com>','HEAD RESEARCHWING<headresearchwing@manappuram.com>','G ALERT AUDIT<glalertsaudit@manappuram>','AGM <agmia@manappuram.com>','CM INTERNALAUDIT<cminternalaudit@manappuram>'
# msg['Cc'] ='RIJU P<gmaudit@manappuram.com>','MAYA T S<iotsupport7@manappuram.com>','SRAVAN T B<iotsupport12@manappuram.com>','Gopika V S<dataservice29@manappuram.com>'
with open(r"D:\\CRF\\Delinquency and the NPA account report_123685\\Delinquency_and_NPA_account_Report.xlsx", 'rb') as ra:
    attachment = ra.read()

msg.add_related(attachment, maintype='application', subtype='xlsx', filename='Delinquency_and_NPA_account_Report.xlsx')
msg.add_alternative("""\
    <html>
        <body>
            <p><i>Dear Sir,</i></p>
            <p> </p>
            <p><i> Please find the attachment</i></p>
                    
            <p></p>
            <p> <i>Thanks & Regards,<br>
                ( This is an autogenerated mail )<br>
        R&D <br>
            </i></p>
        </body>
    </html>
    """,subtype='html')
# with open(r"D:\\CRF\\Daily Alert efficiency summary report_122055\\Alert_report.png", 'rb') as img:
#         maintype, subtype = mimetypes.guess_type(img.name)[0].split('/')
#         msg.get_payload()[1].add_related(img.read(),
#                                             maintype=maintype,
#                                             subtype=subtype,
#                                             cid=image_cid)


# msg.add_alternative(html_table,subtype='html')
s.send_message(msg)

print("Mail sent")
# os.remove("D:\\auto mails\\msme auto\\summary.csv")
# os.remove("D:\\CRF\\Delinquency and the NPA account report_123685\\Delinquency_and_NPA_account_Report.xlsx")
os.remove("D:\\CRF\\Delinquency and the NPA account report_123685\\Deliquency and npa.xlsx")
os.remove("D:\\CRF\\Delinquency and the NPA account report_123685\\Reduction Deliquency and npa.xlsx")

