from tableau_api_lib import TableauServerConnection
from tableau_api_lib.utils import querying
from tableau_api_lib.utils.common import flatten_dict_column
import pandas as pd
import xlrd
from pandas import ExcelWriter
import cx_Oracle
import openpyxl
from email.message import EmailMessage
from openpyxl.styles import PatternFill,Font
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side
from openpyxl import load_workbook
import smtplib
from datetime import datetime, timedelta
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.styles import Color

workbook = load_workbook(r"D:\\CRF\\Delinquency and the NPA account report_123685\\Delinquency_and_NPA_account_Report.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))

sheet_names = workbook.sheetnames
sh_names1 = ["Deliquency and npa"]
for sheet_name in sheet_names:
    if sheet_name in sh_names1:
        sheet = workbook[sheet_name]
        x = ['Unnamed: 0','Unnamed: 1','Unnamed: 3','Unnamed: 4','Unnamed: 5','Unnamed: 6','Unnamed: 7','Unnamed: 8','Unnamed: 9']
        for row in sheet.iter_rows():
            for cell in row:
                if cell.value in x:
                    cell.value = ""
        for col in range(1, 11):
            column_letter = get_column_letter(col)
            sheet.column_dimensions[column_letter].width = 20

        merge_range6 = f"A1:A3"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=1, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=1, column=1)
        merged_cell6.value = 'REG NAME'
        font = Font(color="ff0000", bold=True)  # Set the font color to white
        merged_cells6.font = font

        merge_range6 = f"B1:B3"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=1, column=2)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=1, column=2)
        merged_cell6.value = 'AUM'
        font = Font(color="ff0000", bold=True)  # Set the font color to white
        merged_cells6.font = font

        merge_range6 = f"C1:J1"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=1, column=3)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=1, column=3)
        merged_cell6.value = 'CATEGORY'
        font = Font(color="ff0000", bold=True)  # Set the font color to white
        merged_cells6.font = font

        merge_range6 = f"C2:D2"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=2, column=3)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=2, column=3)
        merged_cell6.value = 'SMA 0'
        font = Font(color="ff0000", bold=True)  # Set the font color to white
        merged_cells6.font = font

        merge_range6 = f"E2:F2"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=2, column=5)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=2, column=5)
        merged_cell6.value = 'SMA 1'
        font = Font(color="ff0000", bold=True)  # Set the font color to white
        merged_cells6.font = font

        merge_range6 = f"G2:H2"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=2, column=7)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=2, column=7)
        merged_cell6.value = 'SMA 2'
        font = Font(color="ff0000", bold=True)  # Set the font color to white
        merged_cells6.font = font

        merge_range6 = f"I2:J2"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=2, column=9)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=2, column=9)
        merged_cell6.value = 'NPA'
        font = Font(color="ff0000", bold=True)  # Set the font color to white
        merged_cells6.font = font

        

        for row in sheet.iter_rows():
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')

workbook.save(r"D:\\CRF\\Delinquency and the NPA account report_123685\\Delinquency_and_NPA_account_Report_style.xlsx")