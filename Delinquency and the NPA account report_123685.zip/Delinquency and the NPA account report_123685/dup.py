from msilib.schema import Font
from openpyxl import load_workbook
import openpyxl


workbook = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))

sheet_names = workbook.sheetnames
sh_names1 = ['Bucket wise count','Bucket wise amt']
for sheet_name in sheet_names:
    if sheet_name in sh_names1:
        sheet = workbook[sheet_name]
        for row in sheet.iter_rows():
            for cell in row:
                  if cell.value=='YEAR':
                        cell.value = ' '
                  elif cell.value=='Measure Names':
                       cell.value = 'Months'
                  elif cell.value=='All':
                       cell.value = 'Total'
                       
        for row in sheet.iter_rows(min_row=3,max_row=3):
             sheet.delete_rows(row[0].row)
        for row in sheet.iter_rows(min_row=16,max_row=19):
             sheet.delete_rows(row[0].row)
        for row in sheet.iter_rows(min_row=16,max_row=16):
             sheet.delete_rows(row[0].row)
        for row in sheet.iter_rows(min_row=17,max_row=17):
             sheet.delete_rows(row[0].row)
        total_row_number = None
        for row in sheet.iter_rows():
            for cell in row:
                if cell.value == 'Total':
                    total_row_number = cell.row
                    for cell in sheet[total_row_number]:
                        font = Font(color="000000", bold=True)  # Set the font color to white
                        cell.font = font
                    # fill = openpyxl.styles.PatternFill(start_color="9A3B3B", end_color="9A3B3B", fill_type="solid") # Main heading
                    # row.fill = fill
                    break
            if total_row_number is not None:
                break
        for row in sheet.iter_rows(min_row=2, max_row=total_row_number):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(2, 11):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="d9e7fa", end_color="d9e7fa", fill_type="solid")

                for col in range(11, 20):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="f7dfe3", end_color="f7dfe3", fill_type="solid")

                for col in range(20, 29):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="d9e7fa", end_color="d9e7fa", fill_type="solid")

                for col in range(29, 38):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="f7dfe3", end_color="f7dfe3", fill_type="solid")

                for col in range(38, 47):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="d9e7fa", end_color="d9e7fa", fill_type="solid")
        for row in sheet.iter_rows(min_row=1, max_row=total_row_number):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
        for row in sheet.iter_rows(min_row=total_row_number, max_row=total_row_number):
            for cell in row:
                cell.fill = openpyxl.styles.PatternFill(start_color="0d0d3b", end_color="0d0d3b", fill_type="solid")
                font = Font(color="ffffff", bold=True)  # Set the font color to white
                cell.font = font
        for row in sheet.iter_rows(min_row=1, max_row=total_row_number+2):
            for cell in row:
                cell.border = border_style
        
        for cell in sheet[2]:
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        for row in sheet.iter_rows(min_row=total_row_number+1, max_row=total_row_number+2):
            for cell in row:
                for col in range(1,1):
                    cell.fill = openpyxl.styles.PatternFill(start_color="e6edf7", end_color="e6edf7", fill_type="solid")

        merge_range6 = f"A{total_row_number+5}:I{total_row_number+5}"
        sheet.merge_cells(merge_range6)
        merged_cells6 = sheet.cell(row=total_row_number+5, column=1)
        merged_cells6.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell6 = sheet.cell(row=total_row_number+5, column=1)
        merged_cell6.value = 'GRAND TOTAL'
        font = Font(color="ff0000", bold=True)  # Set the font color to white
        merged_cells6.font = font

        
        
workbook.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

# Load the source and destination workbooks
source_wb5 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Total.xlsx")
dest_wb5 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

# Get the source and destination sheets
source_sheet5 = source_wb5['Total Count']
dest_sheet5 = dest_wb5['Bucket wise count']

# Copy the data from the source sheet
for row in source_sheet5.iter_rows(values_only=True):
    dest_sheet5.append(row)
dest_wb5.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

source_wb4 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Total.xlsx")
dest_wb4 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")
# Get the source and destination sheets
source_sheet4 = source_wb4['Total amt']
dest_sheet4 = dest_wb4['Bucket wise amt']

# Copy the data from the source sheet
for row in source_sheet4.iter_rows(values_only=True):
    dest_sheet4.append(row)
            
#Save the destination workbook
dest_wb4.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

workbook = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))

sheet_names = workbook.sheetnames
sh_names1 = ['Bucket wise count','Bucket wise amt']
for sheet_name in sheet_names:
    if sheet_name in sh_names1:
        sheet = workbook[sheet_name]
        for row in sheet.iter_rows(min_row=total_row_number+5, max_row=total_row_number+8):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
        for row in sheet.iter_rows(min_row=total_row_number+6, max_row=total_row_number+6):
            sheet.delete_rows(row[0].row)
        for row in sheet.iter_rows(min_row=total_row_number+5, max_row=total_row_number+7):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 10):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.border = border_style
        for cell in sheet[total_row_number+6]:
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        for row in sheet.iter_rows(min_row=total_row_number+6, max_row=total_row_number+6):
            for col in range(1, 10):  # Specify the range of columns (A to I)
                cell = sheet.cell(row=cell.row, column=col)
                cell.fill = openpyxl.styles.PatternFill(start_color="ab620f", end_color="ab620f", fill_type="solid")
                font = Font(color="ffffff", bold=True)  # Set the font color to white
                cell.font = font
        for row in sheet.iter_rows():
            for cell in row:
                  if cell.value=='Percantage of loan amount(Delin)':
                        cell.value = '% on Loan amt'
                  else:
                      continue

        # adjusting column width
        for col in range(2, 47):
            column_letter = get_column_letter(col)
            sheet.column_dimensions[column_letter].width = 14
        for row in sheet.iter_rows(min_row=total_row_number+1, max_row=total_row_number+2):
            for cell in row:
                if cell.value is not None:
                    cell.value = str(cell.value) + '%'

        
workbook.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

################################################------NPA/DELIN------###################################################################




workbook = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))

sheet_names = workbook.sheetnames
sh_names1 = ['NPA','DELIN']
for sheet_name in sheet_names:
    if sheet_name in sh_names1:
        sheet = workbook[sheet_name]
        for row in sheet.iter_rows():
            for cell in row:
                if cell.value=='YEAR':
                    cell.value = ' '
                elif cell.value=='Measure Names':
                    cell.value = 'Months'
                elif cell.value=='All':
                    cell.value = 'Total'
                # # elif cell.value=='Percantage of loan amount(npa)':
                # #     cell.value = '% of Loan amount'
                # elif cell.value=='Percantage of loan amount(Delin)':
                #     cell.value = '% of Loan amount'
                else:
                    continue
                
                       
        for row in sheet.iter_rows(min_row=3,max_row=3):
             sheet.delete_rows(row[0].row)
        total_row_number = None
        for row in sheet.iter_rows():
            for cell in row:
                if cell.value == 'Total':
                    total_row_number = cell.row
                    ##_______Conditional formatting___________
                    # start_row = 4  # Assuming row 1 is the header
                    # end_row = total_row_number-1
                    # columns_to_format = ['D', 'H', 'L','P','T']  # Replace with the column letters you want to format

                    # for col in columns_to_format:
                    #     min_col = f"{col}{start_row}"
                    #     max_col = f"{col}{end_row}"

                    #     # Create a color scale rule
                    #     color_scale_rule = ColorScaleRule(start_type="min", start_color=Color(rgb="7ae67a"),
                    #                         mid_type="percentile", mid_value=50, mid_color=Color(rgb="ffd966"),
                    #                         end_type="max", end_color=Color(rgb="e56666"))

                    #     # Apply the color scale rule to the specified range
                    #     sheet.conditional_formatting.add(f"{min_col}:{max_col}", color_scale_rule)
                        ###########__________________________########################
                    for cell in sheet[total_row_number]:
                        font = Font(color="000000", bold=True)  # Set the font color to white
                        cell.font = font
                    # fill = openpyxl.styles.PatternFill(start_color="9A3B3B", end_color="9A3B3B", fill_type="solid") # Main heading
                    # row.fill = fill
                    break
            if total_row_number is not None:
                break
        for row in sheet.iter_rows(min_row=2, max_row=total_row_number):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(2, 5):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="d9e7fa", end_color="d9e7fa", fill_type="solid")

                for col in range(5, 8):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="f7dfe3", end_color="f7dfe3", fill_type="solid")

                for col in range(8, 11):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="d9e7fa", end_color="d9e7fa", fill_type="solid")

                for col in range(11, 14):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="f7dfe3", end_color="f7dfe3", fill_type="solid")

                for col in range(14, 17):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="d9e7fa", end_color="d9e7fa", fill_type="solid")
        for row in sheet.iter_rows(min_row=1, max_row=total_row_number):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
        for row in sheet.iter_rows(min_row=total_row_number, max_row=total_row_number):
            for cell in row:
                cell.fill = openpyxl.styles.PatternFill(start_color="0d0d3b", end_color="0d0d3b", fill_type="solid")
                font = Font(color="ffffff", bold=True)  # Set the font color to white
                cell.font = font
        for row in sheet.iter_rows(min_row=1, max_row=total_row_number):
            for cell in row:
                cell.border = border_style
        for cell in sheet[2]:
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        for col in range(2, 47):
            column_letter = get_column_letter(col)
            sheet.column_dimensions[column_letter].width = 14
        


        merge_range7 = f"A{total_row_number+5}:C{total_row_number+5}"
        sheet.merge_cells(merge_range7)
        merged_cells7 = sheet.cell(row=total_row_number+5, column=1)
        merged_cells7.alignment = openpyxl.styles.Alignment(horizontal='center', vertical='center')
        merged_cell7 = sheet.cell(row=total_row_number+5, column=1)
        merged_cell7.value = 'GRAND TOTAL'
        font = Font(color="ff0000", bold=True)  # Set the font color to white
        merged_cells7.font = font

        
        
workbook.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")


# Load the source and destination workbooks
source_wb15 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Total.xlsx")
dest_wb15 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

# Get the source and destination sheets
source_sheet15 = source_wb15['NPA TOTAL']
dest_sheet15 = dest_wb15['NPA']

# Copy the data from the source sheet
for row in source_sheet15.iter_rows(values_only=True):
    dest_sheet15.append(row)
dest_wb15.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

source_wb14 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Total.xlsx")
dest_wb14 = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")
# Get the source and destination sheets
source_sheet14 = source_wb14['DELIN TOTAL']
dest_sheet14 = dest_wb14['DELIN']

# Copy the data from the source sheet
for row in source_sheet14.iter_rows(values_only=True):
    dest_sheet14.append(row)
            
#Save the destination workbook
dest_wb14.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")

workbook = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))

sheet_names = workbook.sheetnames
sh_names1 = ['NPA','DELIN']
for sheet_name in sheet_names:
    if sheet_name in sh_names1:
        sheet = workbook[sheet_name]
        for row in sheet.iter_rows(min_row=total_row_number+5, max_row=total_row_number+9):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
        for row in sheet.iter_rows(min_row=total_row_number+6, max_row=total_row_number+6):
            sheet.delete_rows(row[0].row)
        for row in sheet.iter_rows(min_row=total_row_number+5, max_row=total_row_number+7):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 4):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.border = border_style
        for cell in sheet[total_row_number+6]:
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        for row in sheet.iter_rows(min_row=total_row_number+6, max_row=total_row_number+6):
            for col in range(1, 4):  # Specify the range of columns (A to I)
                cell = sheet.cell(row=cell.row, column=col)
                cell.fill = openpyxl.styles.PatternFill(start_color="ab620f", end_color="ab620f", fill_type="solid")     
                font = Font(color="ffffff", bold=True)  # Set the font color to white
                cell.font = font
        for row in sheet.iter_rows():
            for cell in row:
                  if cell.value=='Percantage of loan amount(npa)':
                        cell.value = '% on Loan amt'
                  elif cell.value=='Percantage of loan amount(Delin)':
                    cell.value = '% of Loan amount'
                  else:
                      continue
                #   elif cell.value=='Measure Names':
                #        cell.value = 'Months'
                #   elif cell.value=='All':
                #        cell.value = 'Total'
                #   elif cell.value=='Percantage of loan amount(npa)':
                #        cell.value = '% of Loan amount'
                #   elif cell.value=='Percantage of loan amount(Delin)':
                #        cell.value = '% of Loan amount'

        

workbook.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")


###############################-------------Disbursement---------------------############################
workbook = load_workbook(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))

sheet_names = workbook.sheetnames

for sheet_name in sheet_names:
    if sheet_name=='Disbursement':
        sheet = workbook[sheet_name]
        for cell in sheet[2]:
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        for row in sheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                for col in range(1, 25):  # Specify the range of columns (A to I)
                    cell = sheet.cell(row=cell.row, column=col)
                    cell.fill = openpyxl.styles.PatternFill(start_color="d9e7fa", end_color="d9e7fa", fill_type="solid")
                for col in range(2, 47):
                    column_letter = get_column_letter(col)
                    sheet.column_dimensions[column_letter].width = 14   
                for col in ['C','F']:
                    sheet.column_dimensions[col].width = 33
                for col in ['L','M','N','v','B','X']:
                    sheet.column_dimensions[col].width = 23
        for row in sheet.iter_rows():
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
                cell.border = border_style
workbook.save(r"C:\Users\399674\Music\CRF\122792 MSME Collection report\122792 MSME Collection Report\Collection Mis MSME report.xlsx")