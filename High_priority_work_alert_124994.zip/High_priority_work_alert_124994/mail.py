import xlsxwriter
import os
import pandas as pd
import cx_Oracle
import openpyxl
from pandas import ExcelWriter
from openpyxl import Workbook
from email.message import EmailMessage
from email.utils import make_msgid
import mimetypes
from tableau_api_lib import TableauServerConnection
from tableau_api_lib.utils import querying
from tableau_api_lib.utils.common import flatten_dict_column
import pandas as pd
import xlrd
from pandas import ExcelWriter
from openpyxl import load_workbook
from openpyxl.styles import PatternFill,Font
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side
import smtplib
import datetime
import time
import time

conn = cx_Oracle.connect("kpmg", "Asd$1234", "HISTDB")

df1=pd.read_sql("""select w.*,'Fake Images' Status from form60_verification w 
where w.customer_id in (select cust_id from TBL_FORM60_FAKE_RPT where  created_dt = trunc(sysdate-1) and status =0)
union all
select q.*,'Fake Images' Status from form60_verification q
left outer join dms.Tbl_Customer_Form60@uatr_backup2 w
on (w.cust_id = q.Customer_ID)
where w.form_60 is null""",con=conn)
#---------------------------------------------------------------------


print("Query section completed...........")



if not df1.empty:
    writer=pd.ExcelWriter("D:\\CRF\\High_priority_work_alert_124994\\Form60_Verification_Report.xlsx",engine="openpyxl")
    df1.to_excel(writer, sheet_name="Form60_Verification_Report", index=False)


    print("saved as excel")
    writer.save()
    print("Excel downloading section completed............")


    workbook = openpyxl.load_workbook('D:\\CRF\\High_priority_work_alert_124994\\Form60_Verification_Report.xlsx')
    print("wb open")
    sheet_names = workbook.sheetnames
    heading_color =  'E2BCB7'    #'73BCC5'#'8080ff'  # Red color
    # body_color = 'F6E5F5'  # Green color
    border_style = Border(
        left=Side(border_style='thin'),
        right=Side(border_style='thin'),
        top=Side(border_style='thin'),
        bottom=Side(border_style='thin'))


    for sheet_name in sheet_names:
        sheet = workbook[sheet_name]
        header_font = Font(color="000000", bold=True)
        header_fill = PatternFill(start_color='E2BCB7', end_color='E2BCB7', fill_type='solid')
        for cell in sheet[1]:
            cell.fill = header_fill
            cell.font = header_font
        # body_fill = PatternFill(start_color=body_color, end_color=body_color, fill_type='solid')
        # for row in sheet.iter_rows(min_row=2):
        #     for cell in row:
        #         cell.fill = body_fill
                
        for column in sheet.columns:
            non_empty_values = [cell.value for cell in column if cell.value]
            if non_empty_values:
                max_length = max(len(str(value)) for value in non_empty_values)
                column_letter = get_column_letter(column[0].column)
                adjusted_width = (max_length + 2) * 1.2  # Adjust the width as desired
                sheet.column_dimensions[column_letter].width = adjusted_width
        for row in sheet.rows:
            max_height = max(str(cell.value).count('\n') + 1 for cell in row if cell.value)
            row_number = row[0].row
            adjusted_height = max_height * 17 # Adjust the height as desired
            sheet.row_dimensions[row_number].height = adjusted_height
        for row in sheet.iter_rows():
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
        for row in sheet.iter_rows():
            for cell in row:
                cell.border = border_style
    workbook.save('D:\\CRF\\High_priority_work_alert_124994\\Form60_Verification_Report.xlsx')
    print("done")
    # workbook = openpyxl.load_workbook(r'C:\\Users\\398504\\CRF\\crf16\\120437-CRF FOR MODIFICATION IN SHOPVISIT AND CUSTOMER REFERENCE AUTOMATION MAIL\\Shopvisit_report.xlsx')


    # excel_file_path = 'C:\\Users\\398504\\CRF\\crf16\\120437-CRF FOR MODIFICATION IN SHOPVISIT AND CUSTOMER REFERENCE AUTOMATION MAIL\\Shopvisit_report.xlsx'

    workbook = openpyxl.load_workbook(r"D:\\CRF\\High_priority_work_alert_124994\\Form60_Verification_Report.xlsx")
    worksheet = workbook["Form60_Verification_Report"]

    # if worksheet.max_row == 0:
    s = smtplib.SMTP(host='smtp.office365.com', port=587)
    s.starttls()
    # print("aaa")
  
    s.login('iotautomation@manappuram.com','ybjmxbfdyzkdnjtw')
    
 
    print("Login the mail address")
    msg = EmailMessage()
    print("Ready for mailing")

    msg['Subject'] = 'Form 60 Verification Report'
    

   

    msg['From']='<iotautomation@manappuram.com>'
    # msg['To']='<glalertsaudit@manappuram.com>'
    msg['To']='<ittesting25@manappuram.com>'
    msg['Cc']='<iotsupport12@manappuram.com>'



    with open(r"D:\\CRF\\High_priority_work_alert_124994\\Form60_Verification_Report.xlsx", 'rb') as ra:
        attachment = ra.read()
    msg.add_related(attachment, maintype='application', subtype='xlsx', filename='Form 60_Verification_Report.xlsx')
    image_cid = make_msgid(domain='mandala.com')
    msg.add_alternative("""\
    <html>
        <body>
            <p>Dear Sir,<br><p/>      
            <p>Please find the attachment. </p>
                        <p>
                        <p>
            
            <p>
            <p> 
            <p>
                Thanks & Regards,<br>
                R & D New age technology <br>
                ( This is an autogenerated mail )
            </p>
        </body>
    </html>
    """,subtype='html')    



    # with open(r"C:\\Users\\398504\\CRF\\crf34\\Form_60_verification_report_124396\\Form60_Verification_Report.png", 'rb') as img:
    #     maintype, subtype = mimetypes.guess_type(img.name)[0].split('/')
    #     msg.get_payload()[1].add_related(img.read(),
    #                                         maintype=maintype,
    #                                         subtype=subtype,
    #                                         cid=image_cid)


    s.send_message(msg)
    s.quit()
    print("Mail send")
    print("final section completed sucessfully.............")
    # os.remove(r"C:\\Users\\398504\\CRF\\crf22\\Fake_NEFT_Verification-121681\\fake_NEFT_report.png")
    print("Image removed")
else:
    print("                                                                     ")
    print("                                                                     ")
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!NO DATA IN DB TABLE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        