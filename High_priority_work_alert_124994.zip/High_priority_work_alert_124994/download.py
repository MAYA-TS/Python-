import os
import cx_Oracle
def save_document(user_id, document, download_dir):
    document_content = document.read() 
    file_extension = None
    
    if document_content.startswith(b'%PDF'):
        file_extension = 'pdf'  
    elif document_content.startswith(b'PNG'):
        file_extension = 'png'  
    elif document_content.startswith(b'tiff'):
        file_extension = 'tiff'  
    elif document_content.startswith(b'bmp'):
        file_extension = 'bmp'
    elif document_content.startswith(b'TXT'):
        file_extension = 'txt' 
    elif document_content.startswith(b'GIF'):
        file_extension = 'gif'
    elif document_content.startswith(b'JPEG'):
        file_extension = 'jpeg' 
    else:
        if b'Word.Document' in document_content or b'word/document.xml' in document_content:
            file_extension = 'docx'
        else:
            file_extension = 'jpg'
 
    # Create a filename based on user_id and file extension
    filename = f"{str(user_id).replace(':', '_').replace('-', '_')}.{file_extension}"
    file_path = os.path.join(download_dir, filename)

    # Ensure the filename is unique by appending a number if it already exists
    counter = 1
    while os.path.exists(file_path):
        filename = f"{str(user_id).replace(':', '_').replace('-', '_')}_{counter}.{file_extension}"
        file_path = os.path.join(download_dir, filename)
        counter += 1

    with open(file_path, 'wb') as document_file:
        document_file.write(document_content)

    print(f"Downloaded: {file_path}")

def download_all_documents():
    sql="""select q.customer_id,w.form_60 from form60_verification q
        left outer join dms.Tbl_Customer_Form60@uatr_backup2 w
        on (w.cust_id = q.Customer_ID) where w.form_60 is not null order by q.customer_id  asc"""

#     sql="""select q.customer_id,w.form_60 from form60_verification q
# left outer join dms.Tbl_Customer_Form60@uatr_backup2 w
# on (w.cust_id = q.Customer_ID) where w.form_60 is not null and q.customer_id between '07030010502207' and '39470021305499' order by q.customer_id  asc"""
    conn = cx_Oracle.connect("kpmg", "Asd$1234", "HISTDB")
    cursor = conn.cursor()
    cursor.execute(sql)

    download_dir ='D:\\CRF\\High_priority_work_alert_124994\\downloads'
    os.makedirs(download_dir, exist_ok=True)

    for row in cursor.fetchall():
        cust_id = row[0]
        document = row[1]
        save_document(cust_id, document, download_dir)

    cursor.close()
    conn.close()

download_all_documents()