import os
import cx_Oracle
import datetime
import os
import shutil
import zipfile
from datetime import datetime, timedelta


connection1 = cx_Oracle.connect("kpmg", "Asd$1234", "HISTDB")
# connection1.open()
cursor = connection1.cursor()

path_images="D:\\CRF\\High_priority_work_alert_124994\\fake\\"
count=0
for filename in os.listdir(path_images):
        if filename.endswith('.JPEG') or filename.endswith('.jpg'):
            CUST_ID = filename.split('.')[0]
            print(CUST_ID ," ")
          
            # print(pledge_no)
         
            # print(pledge_no,"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!") 
            current_date1 = datetime.now() - timedelta(days=1)
            current_date = datetime.strftime(current_date1, '%d-%m-%Y')

            status = 0
            connection = cx_Oracle.connect("kpmg", "Asd$1234", "HISTDB")
            cursor = connection.cursor()


            cursor.execute("INSERT INTO TBL_FORM60_FAKE_RPT(cust_id,CREATED_DT, STATUS) VALUES (:cust_id,TO_DATE(:1, 'DD-MM-YYYY'),:status)",
                        (CUST_ID,current_date,status))
            cursor.close()
            print(CUST_ID, "inserted")
            count = count+1
            print(count)
          
            connection.commit() 
            # print("fake")  


connection1.commit()
connection1.close() 

