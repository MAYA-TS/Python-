import os
import cv2
import numpy as np
from PIL import Image
import shutil

def is_black_image(image_path):
    """Check if the image is completely black."""
    image = cv2.imread(image_path)
    if image is None:
        return False
    return np.all(image == 0)

# def is_blank_white_image(image_path):
#     """Check if the image is completely white."""
#     image = cv2.imread(image_path)
#     if image is None:
#         return False
#     return np.all(image == 255)
def is_blank_white_image(image_path):
    """Check if the image is completely white or has only scratches."""
    try:
        image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
        if image is None:
            return False
        
        # Apply threshold to remove light scratches
        _, thresh = cv2.threshold(image, 200, 255, cv2.THRESH_BINARY)
        
        # Check if the image is mostly white (allowing for some scratches)
        white_pixel_ratio = np.sum(thresh == 255) / thresh.size
        return white_pixel_ratio > 0.99  # Adjust this threshold as needed
    except Exception as e:
        print(f"Error processing image {image_path}: {e}")
        return False

def is_blank_black_image(image_path):
    """Check if the image is completely black (using PIL)."""
    try:
        img = Image.open(image_path).convert('L')  # Convert to grayscale
        extrema = img.getextrema()
        return extrema == (0, 0)  # Check if min and max are both 0
    except OSError as e:
        print(f"Error opening image {image_path}: {e}")
        return False

def is_blank_pdf(pdf_path):
    """Checks if a PDF file is blank (white pages)."""
    try:
        with Image.open(pdf_path) as img:
            img = img.convert('L')  # Convert to grayscale
            if np.all(np.array(img) == 255):  # Check if all pixels are white
                return True
    except Exception as e:
        print(f"Error processing PDF {pdf_path}: {e}")
    return False

def is_fake(file_path):
    """Determine if the file is fake based on its content."""
    if file_path.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
        if is_black_image(file_path) or is_blank_white_image(file_path) or is_blank_black_image(file_path):
            return True  # Consider black and white images as fake
        else:
            return False  # Assume other images are real
    elif file_path.lower().endswith('.pdf'):
        if is_blank_pdf(file_path):
            return True  # Consider blank PDFs as fake
        else:
            return False  # Assume other PDFs are real
    return False  # Not a supported file type

def move_files(source_folder, fake_folder, real_folder):
    """Move files to fake or real folders based on their classification."""
    os.makedirs(fake_folder, exist_ok=True)
    os.makedirs(real_folder, exist_ok=True)

    for filename in os.listdir(source_folder):
        file_path = os.path.join(source_folder, filename)
        if os.path.isfile(file_path):  # Ensure it's a file
            if is_fake(file_path):
                shutil.move(file_path, os.path.join(fake_folder, filename))
                print(f"Moved {filename} to fake folder.")
            else:
                shutil.move(file_path, os.path.join(real_folder, filename))
                print(f"Moved {filename} to real folder.")

# Example usage
source_folder = 'D:\\CRF\\High_priority_work_alert_124994\\downloads'  # Replace with your folder path
fake_folder = 'D:\\CRF\\High_priority_work_alert_124994\\fake'  # Replace with your fake folder path
real_folder = 'D:\\CRF\\High_priority_work_alert_124994\\real'  # Replace with your real folder path

move_files(source_folder, fake_folder, real_folder)

