import xlsxwriter
import os
import pandas as pd
import cx_Oracle
import openpyxl
from pandas import ExcelWriter
from openpyxl import Workbook
from email.message import EmailMessage
from email.utils import make_msgid
import mimetypes
from tableau_api_lib import TableauServerConnection
from tableau_api_lib.utils import querying
from tableau_api_lib.utils.common import flatten_dict_column
import pandas as pd
import xlrd
from pandas import ExcelWriter
from openpyxl import load_workbook
from openpyxl.styles import PatternFill,Font
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side
import smtplib
import datetime
import time
import schedule
import time
import tableauserverclient as TSC

# def task():

# while True:
tableau_server_config = {
                'my_env': {
                        'server': 'https://reports.manappuram.com',
                        'api_version': "3.17",
                        'username': 'tableauadministrator',
                        'password': 'M@fil@123',
                        'site_name': 'Default',
                        'site_url': ''
                }
        }
conn = TableauServerConnection(tableau_server_config, env='my_env',ssl_verify=False)
conn.sign_in()
print("Tableau server connected")


site_views_df = querying.get_views_dataframe(conn)
site_views_detailed_df = flatten_dict_column(site_views_df, keys=['name', 'id'], col_name='workbook')
site_views_detailed_df.tail(60)
relevant_views_df = site_views_detailed_df[site_views_detailed_df['workbook_name'] == 'GOLD LOAN IRREGULARITY ANALYSIS']
print(relevant_views_df)
# relevant_views_df.refresh(workbook_id='949d788d-c89f-432d-8af2-c03990e149c5')

fzm_data='0d19420f-d3b9-40c7-a24d-2577485f72e6'
# reg_data='a8e2ec7a-b658-4065-b839-2a0154c380b4'
view_img = conn.query_view_image(view_id=fzm_data)
print(view_img)
with open(r"D:\\CRF\\Gold_loan_irregularity_analysis_123348\\Gold_loan_irregularity_report1.png","wb") as f:
   
    f.write(view_img.content)
print("Third section completed................")
conn = cx_Oracle.connect("kpmg", "Asd$1234", "HISTDB")
print("Oracle database connected")



df1=pd.read_sql("""select * from No_of_pkts_verfd1 order by fzm asc""",con=conn)
print("VERIFIED FILES SUMMARY REPORT query executed---------------------------------------------------------df1")
df2=pd.read_sql("""SELECT * FROM No_of_irr_rpts1""",con=conn)
print("IRREGULARITY REPORT query executed")
df3=pd.read_sql("""select x.fzm, --trunc(tra_dt) tra_dt,
       sum(case
             when x.status_id in ('1', '2', '29') then
              weightloss
           end) Spurious,
      NVL( sum(case
             when x.status_id in ('36', '37', '38') then
              weightloss
           end),0) zeropurity,
      NVL( sum(case
             when x.status_id in ('5', '6', '30') then
              weightloss
           end),0) Lowquality,
      NVL( sum(case
             when x.status_id in ('9') then
              weightloss
           end),0) Understone_deduction,
      NVL( sum(case
             when x.status_id in ('27', '28', '31') then
              weightloss
           end),0) AverageTouch,
      NVL( sum(case
             when x.status_id in ('12', '13', '25', '19', '26', '24') then
              weightloss
           end),0) Others,
       NVL(sum(case
             when x.status_id in ('7', '40') then
              weightloss
           end),0) StolenCheating,
       NVL(sum(case
             when x.status_id in ('3', '4') then
              weightloss
           end),0) Goldmissing,
       NVL(sum(case
             when x.status_id in ('23') then
              weightloss
           end),0) Weightdifference
  from (select t.*,
               mana0809.getweightloss@uatr_backup2(t.pledge_no, t.irr_code) as weightloss,
               f.fzm
          from mana0809.irregularity_status@uatr_backup2 i
          left outer join dms.tbl_audit_irregularity@uatr_backup2 t
            on i.status_id = t.status_id
              /*and trunc(TRA_DT) >= TRUNC(SYSDATE, 'MM')
              and trunc(TRA_DT) <= TRUNC(SYSDATE)*/
           and trunc(TRA_DT) >= trunc(ADD_MONTHS(sysdate, -1), 'MONTH')
           and trunc(TRA_DT) <= trunc(sysdate, 'mm') - 1
        
          left outer join mana0809.branch_master@uatr_backup2 b
            on b.BRANCH_ID = t.branch_id
          left outer join mana0809.tbl_fzm_master@uatr_backup2 f
            on f.region_id = b.region_id) x

 group by x.fzm""",con=conn)
print("CLASSIFICATION REPORT QUERY EXECUTED ")
writer=pd.ExcelWriter("D:\\CRF\\Gold_loan_irregularity_analysis_123348\\Gold_loan_irregularity_report.xlsx",engine="openpyxl")
df1.to_excel(writer, sheet_name="VERIFIED FILES SUMMARY REPORT", index=False)
df2.to_excel(writer, sheet_name="IRREGULARITY REPORT", index=False)
df3.to_excel(writer, sheet_name="CLASSIFICATION REPORT", index=False)

print("saved as excel")
writer.save()
print("Excel downloading section completed............")

workbook = load_workbook('D:\\CRF\\Gold_loan_irregularity_analysis_123348\\Gold_loan_irregularity_report.xlsx')
sheet_names = workbook.sheetnames
heading_color = '008000'   #9999ff #  color
body_color =  '999999'            #d0d0e1  #  color
for sheet_name in sheet_names:
    sheet = workbook[sheet_name]
    header_fill = PatternFill(start_color=heading_color, end_color=heading_color, fill_type='solid')
    for cell in sheet[1]:
        cell.fill = header_fill
    body_fill = PatternFill(start_color=body_color, end_color=body_color, fill_type='solid')
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            cell.fill = body_fill
workbook.save('D:\\CRF\\Gold_loan_irregularity_analysis_123348\\Gold_loan_irregularity_report.xlsx')



workbook = openpyxl.load_workbook("D:\\CRF\\Gold_loan_irregularity_analysis_123348\\Gold_loan_irregularity_report.xlsx")
sheet_names = workbook.sheetnames
heading_color =  '070F2B'    #'73BCC5'#'8080ff'  # Red color
body_color = 'FFFFFF'  # Green color
border_style = Border(
    left=Side(border_style='thin'),
    right=Side(border_style='thin'),
    top=Side(border_style='thin'),
    bottom=Side(border_style='thin'))
 
 
for sheet_name in sheet_names:
    sheet = workbook[sheet_name]
    header_font = Font(color="ffffff", bold=True)
    header_fill = PatternFill(start_color='070F2B', end_color='070F2B', fill_type='solid')
    for cell in sheet[1]:
        cell.fill = header_fill
        cell.font = header_font
    body_fill = PatternFill(start_color=body_color, end_color=body_color, fill_type='solid')
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            cell.fill = body_fill
           
    max_height = 0
    for cell in row:
        if cell.value:
            height = str(cell.value).count('\n') + 1
            if height > max_height:
                max_height = height
    for column in sheet.columns:
        non_empty_values = [cell.value for cell in column if cell.value]
        if non_empty_values:
            max_length = max(len(str(value)) for value in non_empty_values)
            column_letter = get_column_letter(column[0].column)
            adjusted_width = (max_length + 2) * 1.2  # Adjust the width as desired
            sheet.column_dimensions[column_letter].width = adjusted_width

    for row in sheet.rows:
        non_empty_values = [cell.value for cell in row if cell.value]
        if non_empty_values:
            max_height = max(str(value).count('\n') + 1 for value in non_empty_values)
            row_number = row[0].row
            adjusted_height = max_height * 17  # Adjust the height as desired
            sheet.row_dimensions[row_number].height = adjusted_height


    for row in sheet.iter_rows():
        for cell in row:
            cell.alignment = Alignment(horizontal='center', vertical='center')
    for row in sheet.iter_rows():
        for cell in row:
            cell.border = border_style
workbook.save("D:\\CRF\\Gold_loan_irregularity_analysis_123348\\Gold_loan_irregularity_report.xlsx")
workbook = openpyxl.load_workbook(r'D:\\CRF\\Gold_loan_irregularity_analysis_123348\\Gold_loan_irregularity_report.xlsx')


excel_file_path = 'D:\\CRF\\Gold_loan_irregularity_analysis_123348\\Gold_loan_irregularity_report.xlsx'


s = smtplib.SMTP(host='smtp.office365.com', port=587)
s.starttls()
# print("aaa")

s.login('iotautomation@manappuram.com','ybjmxbfdyzkdnjtw')
# s.login('internalaudit1@manappuram.com','AB@123ad')

print("xx")
msg = EmailMessage()
print("Ready for mailing")
msg['Subject'] = 'GOLD LOAN IRREGULARITY REPORT'
msg['FROM']='IOT <iotautomation@manappuram.com>'
msg['To']='Sravan T B <iotsupport12@manappuram.com>'

# msg['To']='GL AUDIT MIS <glauditmis@manappuram.com>'
msg['Cc']='Sravan T B <iotsupport12@manappuram.com>','Gopika V S<dataservice29@manappuram.com>','Maya T S<iotsupport7@manappuram.com>'

#    msg['From'] = '<internalaudit1@manappuram.com>'

with open(r"D:\\CRF\\Gold_loan_irregularity_analysis_123348\\Gold_loan_irregularity_report.xlsx", 'rb') as ra:
    attachment = ra.read()
msg.add_related(attachment, maintype='application', subtype='xlsx', filename='Gold_loan_irregularity_report.xlsx')
image_cid = make_msgid(domain='mandala.com')
msg.add_alternative("""\
  
<html>
    <body>
        <p>Dear Sir,<br><p/>
                   
               
        <p>
        Kindly  find the Gold loan irregularity report.
            </p>
       
        <p>
            <img src="cid:{image_cid}">
        </p>
   
        <br>                
       <p> Thanks & Regards,<br>
            Manappuram Finance Limited<br>
            A.O Valapad,Thrissur.<br>
            <br>
            <i>(Please do not reply to this email ID as this is an automatically generated email and reply to this ID is not being monitored).</i></p>
       
    </body>
</html>
""".format(image_cid=image_cid[1:-1]),subtype='html')    


with open(r"D:\\CRF\\Gold_loan_irregularity_analysis_123348\\Gold_loan_irregularity_report1.png", 'rb') as img:
    maintype, subtype = mimetypes.guess_type(img.name)[0].split('/')
    msg.get_payload()[1].add_related(img.read(),
                                        maintype=maintype,
                                        subtype=subtype,
                                        cid=image_cid)

s.send_message(msg)
print("Mail send")
print("final section completed sucessfully.............")
os.remove(r"D:\\CRF\\Gold_loan_irregularity_analysis_123348\\Gold_loan_irregularity_report1.png")
print("Image removed")